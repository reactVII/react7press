<?php

/**
 * The plugin bootstrap file
 *
 * This file is read by WordPress to generate the plugin information in the plugin
 * admin area. This file also includes all of the dependencies used by the plugin,
 * registers the activation and deactivation functions, and defines a function
 * that starts the plugin.
 *
 * @link              https://makewebbetter.com
 * @since             1.0.0
 * @package           Wordpress_Crypto_Watcher
 *
 * @wordpress-plugin
 * Plugin Name:       WordPress Crypto Watcher - Realtime Cryptocurrency Prices, Charts with Mutiple Currencies
 * Plugin URI:        https://makewebbetter.com
 * Description:       WordPress Crypto Watcher - Realtime Cryptocurrency Prices, Charts with Mutiple Currencies to list the CryptoCurrency using Shortcode where you want to list.
 * Version:           1.0.0
 * Author:            MakeWebBetter
 * Author URI:        https://makewebbetter.com
 * Requires at least: 3.5
 * Tested up to: 4.9.4
 * WC requires at least: 3.0.0
 * WC tested up to: 3.3.3
 * Text Domain:       wordpress-crypto-watcher
 * Domain Path:       /languages
 */

// If this file is called directly, abort.
if ( ! defined( 'WPINC' ) ) {
	die;
}

//Define Constant

if( !defined( 'MWB_WCW_PATH' ) )
{
	define('MWB_WCW_PATH', plugin_dir_path(__FILE__));
}

if( !defined('MWB_WCW_URL') )
{
	define('MWB_WCW_URL', plugin_dir_url(__FILE__));
}

if( !defined('MWB_WCW_BASENAME') )
{
	define('MWB_WCW_BASENAME', plugin_basename ( __FILE__ ));
}

/**
 * Currently plugin version.
 * Start at version 1.0.0 and use SemVer - https://semver.org
 * Rename this for your plugin and update it as you release new versions.
 */
define( 'PLUGIN_NAME_VERSION', '1.0.0' );

/**
 * The code that runs during plugin activation.
 * This action is documented in includes/class-wordpress-crypto-watcher-activator.php
 */
function activate_wordpress_crypto_watcher() {
	require_once plugin_dir_path( __FILE__ ) . 'includes/class-wordpress-crypto-watcher-activator.php';
	Wordpress_Crypto_Watcher_Activator::activate();
}

/**
 * The code that runs during plugin deactivation.
 * This action is documented in includes/class-wordpress-crypto-watcher-deactivator.php
 */
function deactivate_wordpress_crypto_watcher() {
	require_once plugin_dir_path( __FILE__ ) . 'includes/class-wordpress-crypto-watcher-deactivator.php';
	Wordpress_Crypto_Watcher_Deactivator::deactivate();
}

register_activation_hook( __FILE__, 'activate_wordpress_crypto_watcher' );
register_deactivation_hook( __FILE__, 'deactivate_wordpress_crypto_watcher' );

/**
 * The core plugin class that is used to define internationalization,
 * admin-specific hooks, and public-facing site hooks.
 */
require plugin_dir_path( __FILE__ ) . 'includes/class-wordpress-crypto-watcher.php';

/**
 * Begins execution of the plugin.
 *
 * Since everything within the plugin is registered via hooks,
 * then kicking off the plugin from this point in the file does
 * not affect the page life cycle.
 *
 * @since    1.0.0
 */
function run_wordpress_crypto_watcher() {

	$plugin = new Wordpress_Crypto_Watcher();
	$plugin->run();

}
run_wordpress_crypto_watcher();
