<?php

/**
 * Provide a admin area view for the plugin
 *
 * This file is used to markup the admin-facing aspects of the plugin.
 *
 * @link       https://makewebbetter.com
 * @since      1.0.0
 *
 * @package    Wordpress_Crypto_Watcher
 * @subpackage Wordpress_Crypto_Watcher/admin/partials
 */

$enable = get_option("wp_crypto_watcher_enable", false);
$enablechecked = "";
if($enable == 1){
	$enablechecked = "checked = 'checked'";
}
$enablenews = get_option("wp_crypto_watcher_news_enable", false);
$enablenewschecked = "";
if($enablenews == 1){
	$enablenewschecked = "checked = 'checked'";
}

$enablecurrencyswitch = get_option("wp_crypto_watcher_currency_switch_enable", false);
$enablecurrencyswitchchecked = "";
if($enablecurrencyswitch == 1){
	$enablecurrencyswitchchecked = "checked = 'checked'";
}

$newscount = get_option("wp_crypto_watcher_news_count", false);
$cryptocurrency = get_option("wp_crypto_watcher_currency", false);
$cryptocurrencysymbol = get_option("wp_crypto_watcher_currency_symbol", false);
$cryptocurrencycss = get_option("wp_crypto_watcher_custom_css", false);

$exchage_res = wp_remote_get('https://coincap.io/exchange_rates', array('timeout' => 20, 'sslverify' => false));
if(!is_wp_error( $exchage_res )){
	$exchage_arrs = json_decode($exchage_res['body'], true);
	$exchage_arrs['symbols']['USD'] = "$";	
}else{
	$exchage_arrs = array();
}
$exchage_arrs = $exchage_arrs['symbols'];
ksort($exchage_arrs);
?>
<div class="wrap">
	<h1 class="wp-heading-inline"><?php _e("WP Crypto Watcher", "wordpress-crypto-watcher");?></h1>
	<?php
	if(isset($_POST['wp_crypto_watcher_news_count'])){

		?>
		<div class="notice notice-success is-dismissible">
	        <p><?php _e( "Settings saved Successfully!", "wordpress-crypto-watcher");?></p>
	    </div>
		<?php
	}
	?>
	<form method="post" id="mainform" action="" enctype="multipart/form-data">
		<table class="form-table">
			<tr valign="top">
				<th><?php _e("Enable", "wordpress-crypto-watcher");?></th>
				<td>
					<input type="checkbox" value="1" name="wp_crypto_watcher_enable" <?php echo $enablechecked;?>>
					<i><?php _e("Check the field to enable the plugin.", "wordpress-crypto-watcher");?></i>
				</td>
			</tr>
			<tr valign="top">
				<th><?php _e("Enable News", "wordpress-crypto-watcher");?></th>
				<td>
					<input type="checkbox" value="1" name="wp_crypto_watcher_news_enable" <?php echo $enablenewschecked;?>>
					<i><?php _e("Check the field to enable the news to listing.", "wordpress-crypto-watcher");?></i>
				</td>
			</tr>
			<tr valign="top">
				<th><?php _e("No of News to Display", "wordpress-crypto-watcher");?></th>
				<td>
					<input type="number" min="0" name="wp_crypto_watcher_news_count" value="<?php echo $newscount;?>">
					<p><i><?php _e("Enter the number of news post to list under news tab.", "wordpress-crypto-watcher");?></i></p>
				</td>
			</tr>
			<tr valign="top">
				<th><?php _e("Select the Coins", "wordpress-crypto-watcher");?></th>
				<td>
					<?php
					$symbols= array(
						"Ƀ" => "Bitcoin (BTC)",
						"Ξ" => "Ethereum (ETH)",
						"Ł" => "Litecoin (LTC)",
						"DASH" => "DigitalCash (DASH)",
						"XMR" => "Monero (XMR)",
						"NXT" => "Nxt (NXT)",
						"ETC" => "Ethereum Classic (ETC)",
						"DOGE" => "Dogecoin (DOGE)",
						"ZEC" => "ZCash (ZEC)",
						"BTS" => "Bitshares (BTS)",
						"DGB" => "DigiByte (DGB)",
						"XRP" => "Ripple (XRP)",
						"BTCD" => "BitcoinDark (BTCD)",
						"PPC" => "PeerCoin (PPC)",
						"CRAIG" => "CraigsCoin (CRAIG)",
						"XBS" => "Bitstake (XBS)",
						"XPY" => "PayCoin (XPY)",
						"PRC" => "ProsperCoin (PRC)",
						"YBC" => "YbCoin (YBC)",
						"DANK" => "DarkKush (DANK)",
						"GIVE" => "GiveCoin (GIVE)",
						"KOBO" => "KoboCoin (KOBO)",
						"DT" => "DarkToken (DT)",
						"CETI" => "CETUS Coin (CETI)",
						"SUP" => "Supcoin (SUP)",
						"XPD" => "PetroDollar (XPD)",
						"GEO" => "GeoCoin (GEO)",
						"CHASH" => "CleverHash (CHASH)",
						"SPR" => "Spreadcoin (SPR)",
						"NXTI" => "NXTI (NXTI)",
					);
					?>

					<select name="wp_crypto_watcher_currency[]" id="wp_crypto_watcher_currency" multiple="multiple">
						<?php
						foreach ($symbols as $key => $symbol) {
							$selected = "";
							if(in_array($key, $cryptocurrency)){
								$selected = "selected = 'selected'";
							}
							?>
							<option value="<?php echo $key;?>" <?php echo $selected;?>><?php echo $symbol;?></option>
							<?php
						}
						?>
					</select>
					<p><i><?php _e("Select the coins you want to list. Keep Blank to list all coins.", "wordpress-crypto-watcher");?></i></p>	
				</td>
			</tr>
			<tr valign="top">
				<th><?php _e("Enable Currency Switcher", "wordpress-crypto-watcher");?></th>
				<td>
					<input type="checkbox" value="1" name="wp_crypto_watcher_currency_switch_enable" <?php echo $enablecurrencyswitchchecked;?>>
					<i><?php _e("Check the field to enable the Currency Switcher for listing.", "wordpress-crypto-watcher");?></i>
				</td>
			</tr>
			<tr valign="top">
				<th><?php _e("Select the Currency for Currency Switcher", "wordpress-crypto-watcher");?></th>
				<td>
					<select name="wp_crypto_watcher_currency_symbol[]" id="wp_crypto_watcher_currency_symbol" multiple="multiple">
						<?php
						foreach ($exchage_arrs as $key => $exchage_arr) {
							$selected = "";
							if(in_array($key, $cryptocurrencysymbol)){
								$selected = "selected = 'selected'";
							}
							?>
							<option value="<?php echo $key;?>" <?php echo $selected;?>><?php echo $key;?> (<?php echo $exchage_arr;?>)</option>
							<?php
						}
						?>
					</select>
					<p><i><?php _e("Select the currency symbol you want to list for currency switch. Default (USD) is autoselect.", "wordpress-crypto-watcher");?></i></p>		
				</td>
			</tr>	
			<tr valign="top">
				<th><?php _e("How to use", "wordpress-crypto-watcher");?></th>
				<td>
					<p>
						<strong>
						<?php _e("Instruction", "wordpress-crypto-watcher");?>: 
						</strong>
						<?php _e("You can use that shortcode where you want to list the cyptocurrency.", "wordpress-crypto-watcher");?>
					</p>
					<p>
					<strong>
					<?php _e("How to use", "wordpress-crypto-watcher");?>:
					</strong>
					</p>
					<p>
						<strong>
						<?php _e("In Admin", "wordpress-crypto-watcher");?>-
						</strong>
					</p>
					<?php _e("Use", "wordpress-crypto-watcher");?>
					<strong>[mwb_wcw_crypto]</strong> 
					<?php _e("shortcode where you want to list the table.", "wordpress-crypto-watcher");?>
					<p>
					<strong>
						<?php _e("Using Code", "wordpress-crypto-watcher");?>-
					</strong>
					</p>
					<?php _e("Use", "wordpress-crypto-watcher");?> 
					<strong> do_shortcode("[mwb_wcw_crypto]");</strong> 
					<?php _e("in files where you want to list the table.", "wordpress-crypto-watcher");?>
				</td>
			</tr>
			<tr valign="top">
				<th><?php _e("Custom CSS", "wordpress-crypto-watcher");?></th>
				<td>
					<textarea name="wp_crypto_watcher_custom_css" class="wp_crypto_watcher_custom_css" rows=8> <?php echo $cryptocurrencycss;?></textarea>
					<p><i><?php _e("Write your css here.", "wordpress-crypto-watcher");?></i></p>
				</td>
			</tr>
		</table>
		<p class="submit">
			<input name="wp_crypto_save" class="button-primary woocommerce-save-button" type="submit" value="Save changes">
		</p>
	</form>	
</div>	