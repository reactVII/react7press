<?php

/**
 * The admin-specific functionality of the plugin.
 *
 * @link       https://makewebbetter.com
 * @since      1.0.0
 *
 * @package    Wordpress_Crypto_Watcher
 * @subpackage Wordpress_Crypto_Watcher/admin
 */

/**
 * The admin-specific functionality of the plugin.
 *
 * Defines the plugin name, version, and two examples hooks for how to
 * enqueue the admin-specific stylesheet and JavaScript.
 *
 * @package    Wordpress_Crypto_Watcher
 * @subpackage Wordpress_Crypto_Watcher/admin
 * @author     MakeWebBetter <support@makewebbetter.com>
 */
class Wordpress_Crypto_Watcher_Admin {

	/**
	 * The ID of this plugin.
	 *
	 * @since    1.0.0
	 * @access   private
	 * @var      string    $plugin_name    The ID of this plugin.
	 */
	private $plugin_name;

	/**
	 * The version of this plugin.
	 *
	 * @since    1.0.0
	 * @access   private
	 * @var      string    $version    The current version of this plugin.
	 */
	private $version;

	/**
	 * Initialize the class and set its properties.
	 *
	 * @since    1.0.0
	 * @param      string    $plugin_name       The name of this plugin.
	 * @param      string    $version    The version of this plugin.
	 */
	public function __construct( $plugin_name, $version ) {

		$this->plugin_name = $plugin_name;
		$this->version = $version;

	}

	/**
	 * Register the stylesheets for the admin area.
	 *
	 * @since    1.0.0
	 */
	public function enqueue_styles() {

		/**
		 * This function is provided for demonstration purposes only.
		 *
		 * An instance of this class should be passed to the run() function
		 * defined in Wordpress_Crypto_Watcher_Loader as all of the hooks are defined
		 * in that particular class.
		 *
		 * The Wordpress_Crypto_Watcher_Loader will then create the relationship
		 * between the defined hooks and the functions defined in this
		 * class.
		 */

		wp_enqueue_style( $this->plugin_name, plugin_dir_url( __FILE__ ) . 'css/wordpress-crypto-watcher-admin.css', array(), $this->version, 'all' );

	}

	/**
	 * Register the JavaScript for the admin area.
	 *
	 * @since    1.0.0
	 */
	public function enqueue_scripts() {

		/**
		 * This function is provided for demonstration purposes only.
		 *
		 * An instance of this class should be passed to the run() function
		 * defined in Wordpress_Crypto_Watcher_Loader as all of the hooks are defined
		 * in that particular class.
		 *
		 * The Wordpress_Crypto_Watcher_Loader will then create the relationship
		 * between the defined hooks and the functions defined in this
		 * class.
		 */

		wp_register_script( $this->plugin_name, plugin_dir_url( __FILE__ ) . 'js/wordpress-crypto-watcher-admin.js', array( 'jquery', 'select2' ), $this->version, false );

		$mwb_local_arr = array(
        	'ajax_url'=>admin_url( 'admin-ajax.php' ),
        	'mwb_wpcw_nonce'=>wp_create_nonce( "mwb-wpcw-verify-nonce" )
        );

        wp_register_script( $this->plugin_name, plugin_dir_url( __FILE__ ) . 'js/wordpress-crypto-watcher-admin.js', array( 'jquery', 'select2' ), $this->version, false );
		wp_localize_script($this->plugin_name,'mwb_wpcw_js_obj',$mwb_local_arr);
		wp_enqueue_script( $this->plugin_name );
		
		wp_enqueue_style('select2', 'https://cdnjs.cloudflare.com/ajax/libs/select2/4.0.3/css/select2.min.css' );

	}

	/**
	 * This function is used to set url in of setting in plugin row meta
	 * @name mwb_wppe_admin_settings
	 * @param $actions, $plugin_file
	 * @author makewebbetter<webmaster@makewebbetter.com>
	 * @link http://www.makewebbetter.com/
	 */
	public function mwb_wpcw_admin_settings($actions, $plugin_file) 
	{
		static $plugin;

		if (! isset ( $plugin )) {
	
			$plugin = MWB_WCW_BASENAME;
		}
		if ($plugin == $plugin_file) {
			$settings = array (
					'settings' => '<a href="' . home_url ( '/wp-admin/admin.php?page=wp-crypto-watcher' ) . '">' . __ ( 'Settings', 'wordpress-crypto-watcher' ) . '</a>',
			);
			$actions = array_merge ( $settings, $actions );
		}
		return $actions;
	}
}
