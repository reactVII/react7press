jQuery(document).ready(function() {
	//alert("checkk");

	console.log(mwb_wpcw_js_obj);

    jQuery('#wp_crypto_watcher_currency').select2();
    jQuery('#wp_crypto_watcher_currency_symbol').select2();


    jQuery('#mwb_wpcw_license_save').on('click',function(){

    	jQuery('.licennse_notification').html('');
		var mwb_license = jQuery('#mwb_wpcw_license_key').val();
		if( mwb_license == '' )
		{
			jQuery('#mwb_wpcw_license_key').css('border','1px solid red');
			return false;
		}
		else
		{
			jQuery('#mwb_wpcw_license_key').css('border','none');
		}
		jQuery('.loading_image').show();
		jQuery.post(
			mwb_wpcw_js_obj.ajax_url,
			{
				'action':'mwb_wpcw_register_license',
				'mwb_nonce':mwb_wpcw_js_obj.mwb_wpcw_nonce,
				'license_key':mwb_license
			},
			function(response)
			{
				alert("test");
				if( response.msg == '' )
				{
					response.msg = 'Something Went Wrong! Please try again';
				}
				jQuery('.loading_image').hide();
				if(response.status == true )
				{
					jQuery('.licennse_notification').css('color','green')
					jQuery('.licennse_notification').html(response.msg);
					window.location.href = '';
				}
				else
				{
					jQuery('.licennse_notification').html(response.msg);
				}
			},'json'
		);
	});
});