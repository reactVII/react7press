<?php

/**
 * Fired during plugin activation
 *
 * @link       https://makewebbetter.com
 * @since      1.0.0
 *
 * @package    Wordpress_Crypto_Watcher
 * @subpackage Wordpress_Crypto_Watcher/includes
 */

/**
 * Fired during plugin activation.
 *
 * This class defines all code necessary to run during the plugin's activation.
 *
 * @since      1.0.0
 * @package    Wordpress_Crypto_Watcher
 * @subpackage Wordpress_Crypto_Watcher/includes
 * @author     MakeWebBetter <support@makewebbetter.com>
 */
class Wordpress_Crypto_Watcher_Activator {

	/**
	 * Short Description. (use period)
	 *
	 * Long Description.
	 *
	 * @since    1.0.0
	 */
	public static function activate() {

	}

}
