<?php

/**
 * Fired during plugin deactivation
 *
 * @link       https://makewebbetter.com
 * @since      1.0.0
 *
 * @package    Wordpress_Crypto_Watcher
 * @subpackage Wordpress_Crypto_Watcher/includes
 */

/**
 * Fired during plugin deactivation.
 *
 * This class defines all code necessary to run during the plugin's deactivation.
 *
 * @since      1.0.0
 * @package    Wordpress_Crypto_Watcher
 * @subpackage Wordpress_Crypto_Watcher/includes
 * @author     MakeWebBetter <support@makewebbetter.com>
 */
class Wordpress_Crypto_Watcher_Deactivator {

	/**
	 * Short Description. (use period)
	 *
	 * Long Description.
	 *
	 * @since    1.0.0
	 */
	public static function deactivate() {

	}

}
