'use strict';

window.chartColors = {
	red: 'rgb(255, 99, 132)',
	orange: 'rgb(255, 159, 64)',
	yellow: 'rgb(255, 205, 86)',
	green: 'rgb(75, 192, 192)',
	blue: 'rgb(54, 162, 235)',
	purple: 'rgb(153, 102, 255)',
	grey: 'rgb(201, 203, 207)'
};

(function(global) {
	var Months = [
		'January',
		'February',
		'March',
		'April',
		'May',
		'June',
		'July',
		'August',
		'September',
		'October',
		'November',
		'December'
	];

	var COLORS = [
		'#4dc9f6',
		'#f67019',
		'#f53794',
		'#537bc4',
		'#acc236',
		'#166a8f',
		'#00a950',
		'#58595b',
		'#8549ba'
	];

	var Samples = global.Samples || (global.Samples = {});
	var Color = global.Color;

	Samples.utils = {
		// Adapted from http://indiegamr.com/generate-repeatable-random-numbers-in-js/
		srand: function(seed) {
			this._seed = seed;
		},

		rand: function(min, max) {
			var seed = this._seed;
			min = min === undefined ? 0 : min;
			max = max === undefined ? 1 : max;
			this._seed = (seed * 9301 + 49297) % 233280;
			return min + (this._seed / 233280) * (max - min);
		},

		numbers: function(config) {
			var cfg = config || {};
			var min = cfg.min || 0;
			var max = cfg.max || 1;
			var from = cfg.from || [];
			var count = cfg.count || 8;
			var decimals = cfg.decimals || 8;
			var continuity = cfg.continuity || 1;
			var dfactor = Math.pow(10, decimals) || 0;
			var data = [];
			var i, value;

			for (i = 0; i < count; ++i) {
				value = (from[i] || 0) + this.rand(min, max);
				if (this.rand() <= continuity) {
					data.push(Math.round(dfactor * value) / dfactor);
				} else {
					data.push(null);
				}
			}

			return data;
		},

		labels: function(config) {
			var cfg = config || {};
			var min = cfg.min || 0;
			var max = cfg.max || 100;
			var count = cfg.count || 8;
			var step = (max - min) / count;
			var decimals = cfg.decimals || 8;
			var dfactor = Math.pow(10, decimals) || 0;
			var prefix = cfg.prefix || '';
			var values = [];
			var i;

			for (i = min; i < max; i += step) {
				values.push(prefix + Math.round(dfactor * i) / dfactor);
			}

			return values;
		},

		months: function(config) {
			var cfg = config || {};
			var count = cfg.count || 12;
			var section = cfg.section;
			var values = [];
			var i, value;

			for (i = 0; i < count; ++i) {
				value = Months[Math.ceil(i) % 12];
				values.push(value.substring(0, section));
			}

			return values;
		},

		color: function(index) {
			return COLORS[index % COLORS.length];
		},

		transparentize: function(color, opacity) {
			var alpha = opacity === undefined ? 0.5 : 1 - opacity;
			return Color(color).alpha(alpha).rgbString();
		}
	};



	Samples.utils.srand(Date.now());

}(this));

(function( $ ) {
	'use strict';

	/**
	 * All of the code for your public-facing JavaScript source
	 * should reside in this file.
	 *
	 * Note: It has been assumed you will write jQuery code here, so the
	 * $ function reference has been prepared for usage within the scope
	 * of this function.
	 *
	 * This enables you to define handlers, for when the DOM is ready:
	 *
	 * $(function() {
	 *
	 * });
	 *
	 * When the window is loaded:
	 *
	 * $( window ).load(function() {
	 *
	 * });
	 *
	 * ...and/or other possibilities.
	 *
	 * Ideally, it is not considered best practise to attach more than a
	 * single DOM-ready or window-load handler for a particular page.
	 * Although scripts in the WordPress core, Plugins and Themes may be
	 * practising this, we should strive to set a better example in our own work.
	 */

	var mwb_exchange_rates;
	var mwb_current_curr = 'USD';
	var mwb_myChart;
	var mwb_news_status = false;
	$(document).ready(function(){
		var mwb_prev_curr;
		setInterval(function(){ 
			$(document).find('.mwb-coin-price-down').removeClass('mwb-coin-price-down');
			$(document).find('.mwb-coin-price-up').removeClass('mwb-coin-price-up');
			$(document).find('.mwb-coin-down').removeClass('mwb-coin-down');
			$(document).find('.mwb-coin-up').removeClass('mwb-coin-up');

		 }, 2000);
		mwb_wcw_coin_list('USD');
		var mwb_curr_graph;
		$(document).on('click', '.mwb-cryptocurrency-coin', function(){
			mwb_curr_graph = $(this).find('a').attr('data-symbol');
			$('.mwb-col--logo__wrapper img').attr('src',$(this).find('img').attr('src'));
			$('#mwb-main-content').show();
			$('.mwb_mcw_grap_price').addClass('PRICE_'+mwb_curr_graph);
			$('.mwb_mcw_grap_vol_24h').addClass('VOLUME24HOUR_'+mwb_curr_graph);
			$('.mwb_mcw_grap_open24h').addClass('OPEN24HOUR_'+mwb_curr_graph);
			$('.mwb_mcw_grap_low').addClass('LOW24HOUR_'+mwb_curr_graph);
			$('.mwb_mcw_grap_high').addClass('HIGH24HOUR_'+mwb_curr_graph);
			$('.mwb_mcw_grap_mkt_cap').addClass('MKTCAP_'+mwb_curr_graph);
			$('.mwb_mcw_grap_change').addClass('CHANGE24HOUR_'+mwb_curr_graph);
			$('.mwb_mcw_grap_change_pct').addClass('CHANGE24HOURPCT_'+mwb_curr_graph);
			mwb_wcw_render_graph('1day', mwb_curr_graph, 1);
		});

		$('.mwb_wcw_1d').on('click', function(){
			mwb_wcw_render_graph('1day', mwb_curr_graph);
		});

		$('.mwb_wcw_1w').on('click', function(){
			mwb_wcw_render_graph('7day', mwb_curr_graph);
		});
		$('.mwb_wcw_1m').on('click', function(){
			mwb_wcw_render_graph('30day', mwb_curr_graph);
		});

		$('.mwb_wcw_3m').on('click', function(){
			mwb_wcw_render_graph('90day', mwb_curr_graph);
		});

		$('.mwb_wcw_6m').on('click', function(){
			mwb_wcw_render_graph('180day', mwb_curr_graph);
		});

		$('.mwb_wcw_1y').on('click', function(){
			mwb_wcw_render_graph('365day', mwb_curr_graph);
		});
		$('.mwb_wcw_curr_wrap').on('click', function(){
			$('.mwb_wcw_select_curr').slideToggle();
			mwb_prev_curr = $('.mwb_wcw_curr_wrap a').text();
		});
		$('.mwb_close').on('click', function(){
			$('#mwb-main-content').hide();
		});
		$('.mwb_wcw_curr').on('click',function(){
			mwb_current_curr = $(this).find('.mwb_wcw_curr_val').text();
			mwb_current_curr = mwb_current_curr.trim();
			mwb_prev_curr = $('.mwb_wcw_curr_wrap > a').text();
			$('.mwb_wcw_curr_wrap a').text(mwb_current_curr);
			$('.mwb_wcw_select_curr').hide();
			
			if( mwb_prev_curr == mwb_current_curr )
			{
				return false;
			}

			if(mwb_current_curr == 'USD' || mwb_current_curr == 'EUR')
			{
				mwb_wcw_coin_list(mwb_current_curr);
			}
			else
			{
				mwb_wcw_coin_list('USD');
			}
			
		});
		$(document).on("click", ".mwb-cryptocurrency .mwb-cryptocurrency__tabs li", function() {
			var mwb_current = $(this).attr('data-current');
			$(this).addClass('active');
			$(this).siblings().removeClass('active');
			if( mwb_current == 1 )
			{
				$('.mwb-cryptocurrency-table-content').addClass('active');
				$('.mwb-cryptocurrency-news-wrapper').removeClass('active');
			}
			else
			{
				$('.mwb-cryptocurrency-table-content').removeClass('active');
				$('.mwb-cryptocurrency-news-wrapper').addClass('active');
				if( mwb_news_status == false )
				{
					$('.mwb_wcw_news_load').show();
					$.post(
						mwb_wcw_obj.ajax_url,
						{
							action:'mwb_wcw_news_list'
						},
						function(response)
						{
							$('.mwb_wcw_news_load').hide();
							if( response.length > 0 )
							{
								response.length = mwb_crypto_data.count;
								mwb_news_status = true;
								var mwb_news_html = '';
								for (var i = 0; i < response.length; i++) 
								{
									var date = new Date(response[i].published_on*1000);
									var hours = date.getHours();
									var minutes = "0" + date.getMinutes();
									var seconds = "0" + date.getSeconds();
									var ampm = hours >= 12 ? 'PM' : 'AM';
									var formattedTime = hours + ':' + minutes.substr(-2) + ':' + seconds.substr(-2)+' '+ampm;
									mwb_news_html += '<div class="mwb-cryptocurrency-item-news">\
										<div class="mwb-cryptocurrency-col-thumb">\
											<img  src="'+response[i].imageurl+'">\
										</div>\
										<div class="mwb-cryptocurrency-col-body">\
											<div class="mwb-cryptocurrency-news-data">\
												<div class="mwb-cryptocurrency-news-source">\
													'+response[i].source_info.name+'\
												</div>\
												<div class="mwb-cryptocurrency-news-date">\
													'+formattedTime+'\
												</div>\
											</div>\
											<h3>\
												<a target="_blank" class="" href="'+response[i].url+'">'+response[i].title+'</a>\
											</h3>\
											<div class="mwb-cryptocurrency-news-body">'+response[i].body+'</div>\
											<div class="mwb-cryptocurrency-news-footer">\
												<div class="mwb-cryptocurrency-news-tags">\
													'+response[i].tags+'\
												</div>\
											</div>\
										</div>\
									</div><!--mwb-cryptocurrency-item-news-->';
								}
								$('.mwb-cryptocurrency-news-wrapper').html(mwb_news_html);
							}
						},'json'
					);
				}
			}
		});
	});
	var mwb_subscription = [];
	var socket = io.connect('https://streamer.cryptocompare.com/');
	function mwb_wcw_coin_list( mwb_curr )
	{
		$('.mwb_wcw_select_curr').hide();

		mwb_curr = mwb_curr.trim();
		if(mwb_subscription.length != 0 )
		{
			socket.emit('SubRemove', { subs: mwb_subscription });
		}

		mwb_subscription = [];
		$('.mwb_wcw_loader').show();
		$('.mwb-cryptocurrency-table').hide();
		$('.mwb_wcw_loader').show();
		$.ajax({
			type:'POST',
			url:mwb_wcw_obj.ajax_url,
			data:
			{
				action: 'mwb_wcw_coin_list',
				current_currency: mwb_curr,
				mwb_wcw_nonce: mwb_wcw_obj.mwb_wcw_nonce
			},
			success:function(response)
			{
				var mwb_table_html = '';
				if(response.Response != undefined && response.Response == 'Error')
				{
					mwb_table_html = '<tr><td colspan="9" style="color:red;">'+response.Message+'</td></tr>';
				}
				else
				{
					var mwb_wcw_imgurl = response.BaseImageUrl;
					var mwb_wcw_data = response.RAW;
					var mwb_i = 1;
					var display_status = true;
					mwb_exchange_rates = response.exchange_rates;
					if(mwb_current_curr == 'USD' || mwb_current_curr == 'EUR')
					{
						var mwb_wcw_data = response.DISPLAY;
					}
					else
					{
						var mwb_wcw_data = response.RAW;
						display_status = false;
					}

					var mwb_crypto_currency = mwb_crypto_data.currency;

					for(var key in mwb_wcw_data) 
					{
						//jQuery.inArray( "John", mwb_crypto_currency )
						console.log(mwb_wcw_data[key]);


						if( display_status == false )
						{
							var mwb_tot_24h = mwb_wcw_data[key][mwb_curr].TOTALVOLUME24H * mwb_exchange_rates[mwb_current_curr];
							mwb_tot_24h = CCC.convertValueToDisplay('', mwb_tot_24h);
							var mwb_tot_24h_to = mwb_wcw_data[key][mwb_curr].TOTALVOLUME24HTO * mwb_exchange_rates[mwb_current_curr];
							mwb_tot_24h_to = CCC.convertValueToDisplay('', mwb_tot_24h_to);
							var mwb_mkt_cap = mwb_wcw_data[key][mwb_curr].MKTCAP * mwb_exchange_rates[mwb_current_curr];
							mwb_mkt_cap = CCC.convertValueToDisplay('', mwb_mkt_cap);
							var mwb_curr_sym = response.symbols[mwb_current_curr] || mwb_current_curr;
							mwb_wcw_data[key][mwb_curr].PRICE = mwb_curr_sym+' '+mwb_wcw_data[key][mwb_curr].PRICE * mwb_exchange_rates[mwb_current_curr];
							mwb_wcw_data[key][mwb_curr].LOW24HOUR = mwb_curr_sym+' '+mwb_wcw_data[key][mwb_curr].LOW24HOUR * mwb_exchange_rates[mwb_current_curr];
							mwb_wcw_data[key][mwb_curr].HIGH24HOUR = mwb_curr_sym+' '+mwb_wcw_data[key][mwb_curr].HIGH24HOUR * mwb_exchange_rates[mwb_current_curr];
							mwb_wcw_data[key][mwb_curr].VOLUME24HOURTO = mwb_curr_sym+' '+mwb_wcw_data[key][mwb_curr].VOLUME24HOURTO * mwb_exchange_rates[mwb_current_curr];
							mwb_wcw_data[key][mwb_curr].TOTALVOLUME24HTO = mwb_curr_sym+' '+mwb_tot_24h_to;
							mwb_wcw_data[key][mwb_curr].MKTCAP = mwb_curr_sym+' '+mwb_mkt_cap;
							mwb_wcw_data[key][mwb_curr].VOLUME24HOUR = CCC.STATIC.CURRENCY.getSymbol(key)+' '+mwb_wcw_data[key][mwb_curr].VOLUME24HOUR * mwb_exchange_rates[mwb_current_curr];
							mwb_wcw_data[key][mwb_curr].TOTALVOLUME24H = CCC.STATIC.CURRENCY.getSymbol(key)+' '+mwb_tot_24h;
							mwb_subscription.push('5~CCCAGG~'+key+'~USD');
						}
						else
						{
							mwb_subscription.push('5~CCCAGG~'+key+'~'+mwb_curr);
						}

						var currencysymbol = mwb_wcw_data[key][mwb_curr].FROMSYMBOL; 
						if(jQuery.inArray( currencysymbol, mwb_crypto_currency ) != -1){
							mwb_table_html += '<tr>\
												<td data-title="#">'+mwb_i+'</td>\
												<td data-title="Name">\
													<div class="mwb-cryptocurrency-coin">\
														<span class="mwb-cryptocurrency-coin-icon">\
															<img src="'+mwb_wcw_imgurl+mwb_wcw_data[key][mwb_curr].ImageUrl+'" alt="btc">\
														</span>\
														<a href="#" data-symbol="'+key+'">'+mwb_wcw_data[key][mwb_curr].FullName+'</a>\
													</div>	\
												</td>\
												<td data-title="price"><span class="mwb-wcw-static PRICE_'+key+'">'+mwb_wcw_data[key][mwb_curr].PRICE+'</span></td>\
												<td data-title="Change 24H"><div class="mwb-change-24-update mwb-wcw-static CHANGE24HOUR_'+key+'">'+mwb_wcw_data[key][mwb_curr].CHANGE24HOUR+'</div><div class="mwb-wcw-static CHANGE24HOURPCT_'+key+'">'+mwb_wcw_data[key][mwb_curr].CHANGEPCT24HOUR+'%<span class="mwb-down-icon">&#x2193;</span><span class="mwb-up-icon">&#x2191;</span></div></td>\
												<td data-title="Low/High 24H"><span class="LOW24HOUR_'+key+'"> '+mwb_wcw_data[key][mwb_curr].LOW24HOUR+'</span>-<span class="HIGH24HOUR_'+key+'">'+mwb_wcw_data[key][mwb_curr].HIGH24HOUR+' </span></td>\
												<td data-title="Direct Vol. 24H"><span><div class="mwb-dircect-value-chnage VOLUME24HOUR_'+key+'">'+mwb_wcw_data[key][mwb_curr].VOLUME24HOUR+'</div><div class="mwb-dircect-value-chnage VOLUME24HOURTO_'+key+'">'+mwb_wcw_data[key][mwb_curr].VOLUME24HOURTO+'</div></span></td>\
												<td data-title="Total Vol. 24H"><span><div class="TOTALVOLUME24H_'+key+'">'+mwb_wcw_data[key][mwb_curr].TOTALVOLUME24H+'</div><div class="TOTALVOLUME24HTO_'+key+'">'+mwb_wcw_data[key][mwb_curr].TOTALVOLUME24HTO+'</div></span></td>\
												<td data-title="Market cap"><span class="mwb-wcw-static MKTCAP_'+key+'">'+mwb_wcw_data[key][mwb_curr].MKTCAP+'</span></td>\
											</tr>';
							mwb_i++;
						}
						
					}
				}
				$('.mwb_wcw_loader').hide();
				$('.mwb-cryptocurrency-table').show();
				$('.mwb-cryptocurrency-table tbody').html(mwb_table_html);
			},
			dataType:'json',
			async:false
		});
		var currentPrice = {};
		socket.emit('SubAdd', { subs: mwb_subscription });
		socket.on("m", function(message) {
			var messageType = message.substring(0, message.indexOf("~"));
			var res = {};
			if (messageType == CCC.STATIC.TYPE.CURRENTAGG) {
				res = CCC.CURRENT.unpack(message);
				dataUnpack(res);
			}
		});

		var dataUnpack = function(data) {
			var from = data['FROMSYMBOL'];
			data['TOSYMBOL'] = mwb_current_curr;
			var to = data['TOSYMBOL'];
			var fsym = CCC.STATIC.CURRENCY.getSymbol(from);
			var tsym = CCC.STATIC.CURRENCY.getSymbol(mwb_current_curr);
			var pair = from + to;

			if (!currentPrice.hasOwnProperty(pair)) {
				currentPrice[pair] = {};
			}
			for (var key in data) {
				if( typeof(data[key]) == 'number' )
				{
					data[key] = data[key] * mwb_exchange_rates[mwb_current_curr.trim()];
				}
				currentPrice[pair][key] = data[key];
			}
			if (currentPrice[pair]['LASTTRADEID'] != undefined && currentPrice[pair]['LASTTRADEID']) {
				currentPrice[pair]['LASTTRADEID'] = parseInt(currentPrice[pair]['LASTTRADEID']).toFixed(0);
			}
			if( currentPrice[pair]['PRICE'] )
			{
				currentPrice[pair]['PRICE'] = Number( currentPrice[pair]['PRICE'] );
				currentPrice[pair]['CHANGE24HOUR'] = CCC.convertValueToDisplay(tsym, (currentPrice[pair]['PRICE'] - currentPrice[pair]['OPEN24HOUR']));
				currentPrice[pair]['CHANGE24HOURPCT'] = ((currentPrice[pair]['PRICE'] - currentPrice[pair]['OPEN24HOUR']) / currentPrice[pair]['OPEN24HOUR'] * 100).toFixed(2) + "%";
			}
			if( currentPrice[pair]['OPEN24HOUR'] )
			{
				currentPrice[pair]['OPEN24HOUR'] = Number( currentPrice[pair]['OPEN24HOUR'] );
			}
			displayData(currentPrice[pair], from, tsym, fsym);
		};

		var displayData = function(current, from, tsym, fsym) {
			var priceDirection = current.FLAGS;
			//console.log(current);
			for (var key in current) {
				if (key == 'CHANGE24HOURPCT') {
					$('.' + key + '_' + from).html(' (' + current[key] + ') <span class="mwb-down-icon">&#x2193;</span><span class="mwb-up-icon">&#x2191;</span>');
				}
				else if (key == 'PRICE' || key == 'LASTVOLUMETO' || key == 'VOLUME24HOURTO' || key == 'HIGH24HOUR' || key == 'LOW24HOUR') {
					$(document).find('.' + key + '_' + from).text(CCC.convertValueToDisplay(tsym, current[key]));
				}
				else if (key == 'LASTVOLUME' || key == 'VOLUME24HOUR' || key == 'OPEN24HOUR' || key == 'OPENHOUR' || key == 'HIGHHOUR' || key == 'LOWHOUR') {
					$('.' + key + '_' + from).text(CCC.convertValueToDisplay(fsym, current[key]));
				}
				else {
					$('.' + key + '_' + from).text(current[key]);
				}
			}

			$('.PRICE_' + from).removeClass("mwb-coin-price-up");
			$('.PRICE_' + from).removeClass("mwb-coin-price-down");
			$('.CHANGE24HOUR_' + from).removeClass("mwb-coin-up-24");
			$('.VOLUME24HOUR_' + from).removeClass("mwb-coin-down-24");
			$('.VOLUME24HOURTO_' + from).removeClass("mwb-coin-up");
			$('.VOLUME24HOURTO_' + from).removeClass("mwb-coin-down");
			$('.CHANGE24HOURPCT_' + from).removeClass("mwb-coin-pct-up");
			$('.CHANGE24HOURPCT_' + from).removeClass("mwb-coin-pct-down");
			$('.PRICE_' + from).addClass('mwb-wcw-static');
			$('.CHANGE24HOUR_' + from).addClass('mwb-wcw-static');
			$('.CHANGE24HOURPCT_' + from).addClass('mwb-wcw-static');
			$('.VOLUME24HOUR_' + from).addClass('mwb-wcw-static');
			$('.VOLUME24HOURTO_' + from).addClass('mwb-wcw-static');
			if (priceDirection & 1) {
				$('.PRICE_' + from).addClass("mwb-coin-price-up");
				$('.VOLUME24HOUR_' + from).addClass("mwb-coin-up");
				$('.VOLUME24HOURTO_' + from).addClass("mwb-coin-up");
			}
			else if (priceDirection & 2) {
				$('.PRICE_' + from).addClass("mwb-coin-price-down");
				$('.VOLUME24HOUR_' + from).addClass("mwb-coin-down");
				$('.VOLUME24HOURTO_' + from).addClass("mwb-coin-down");
			}
			if (current['PRICE'] > current['OPEN24HOUR']) {
				$('.CHANGE24HOUR_' + from).addClass("mwb-coin-up-24");
				$('.CHANGE24HOURPCT_' + from).addClass("mwb-coin-pct-up");
			}
			else if (current['PRICE'] < current['OPEN24HOUR']) {
				$('.CHANGE24HOURPCT_' + from).addClass("mwb-coin-pct-down");
				$('.CHANGE24HOUR_' + from).addClass("mwb-coin-down-24");
			}
		};
	}

	function mwb_wcw_render_graph( limit, coin, status)
	{
		if( status != 1)
		{
			mwb_myChart.destroy();
		}
		var ctx = $(document).find('#myChart');
		var mwb_wcw_tm = new Date();
		var mwb_grph_time = [];
		var mwb_grph_mar = [];
		var mwb_grph_pri = [];
		var presets = window.chartColors;
		var utils = Samples.utils;
		$(document).find('.mwb_wcw_loader_grp').css('display','block');
		$.post(
			mwb_wcw_obj.ajax_url,
			{
				action:'mwb_wcw_history_list',
				mwb_url: 'http://coincap.io/history/'+limit+'/'+coin,
				multiplier: mwb_exchange_rates[mwb_current_curr]
			},
			function(response)
			{
				$(document).find('.mwb_wcw_loader_grp').css('display','none');
				mwb_grph_time = response.time;
				mwb_grph_mar = response.cap;
				mwb_grph_pri = response.price;
				var options = {
					maintainAspectRatio: false,
				    scales: {
				        yAxes: [{
				          stacked: true,
				          gridLines: {
				            display: true,
				            color: "rgba(255,99,132,0.2)"
				          }
				        }],
				        xAxes: [{
				          gridLines: {
				            display: false
				          }
				        }]
				    },
					plugins: {
						filler: {
							propagate: true
						}
					},
					tooltips: {
				         callbacks: {
						    label: function(tooltipItem, data) {
						        return tooltipItem.yLabel.toString().replace(/\B(?=(\d{3})+(?!\d))/g, ",");
						    },
						}
				    }
				};
				mwb_myChart = new Chart(ctx, {
				    type: 'line',
				    data: {
				        labels: mwb_grph_time,
				        datasets: [
					        {
					            label: mwb_crypto_data.mwb_market_cap_text,
					            data: mwb_grph_mar,
					            backgroundColor: utils.transparentize(presets.red),
								borderColor: presets.red,
					            borderWidth: 1,
					            hidden:true,

					        },
					        {
					            label: mwb_crypto_data.mwb_market_price_text,
					            data: mwb_grph_pri,
					            backgroundColor: utils.transparentize(presets.orange),
								borderColor: presets.orange,
					            borderWidth: 1,
					        },

						]
				    },
				    legend:true,
				    options: options
				});
			},'json'
		);
	}

	function mwb_wcw_number_format(number)
	{
	    return parseFloat(input).toLocaleString(int_language);
	}

	/*=============================================
	=            Mobile view Custom js            =
	=============================================*/
	var mwb_screenwidth = (window.innerWidth > 0) ? window.innerWidth : screen.width;
	if (mwb_screenwidth <= 640) {
	    var slideIndex = 1;
	    showSlides(slideIndex);
	    function plusSlides(n) {
	        showSlides(slideIndex += n);
	    }
	    function currentSlide(n) {
	        showSlides(slideIndex = n);
	    }
	    function showSlides(n) {
	        var i;
	        var slides = document.getElementsByClassName("mwb-coin-panel");
	        var dots = document.getElementsByClassName("mwb-coin-dot");
	        if (n > slides.length) {
	            slideIndex = 1;
	        }
	        if (n < 1) {
	            slideIndex = slides.length;
	        }
	        for (i = 0; i < slides.length; i++) {
	            slides[i].style.display = "none";  
	        }
	        for (i = 0; i < dots.length; i++) {
	            dots[i].className = dots[i].className.replace(" active", "");
	      }
	        slides[slideIndex - 1].style.display = "block";
	        dots[slideIndex - 1].className += " active";
	    }
	}
	/*=====  End of Mobile view Custom js  ======*/


})( jQuery );
