<?php

/**
 * The public-facing functionality of the plugin.
 *
 * @link       https://makewebbetter.com
 * @since      1.0.0
 *
 * @package    Wordpress_Crypto_Watcher
 * @subpackage Wordpress_Crypto_Watcher/public
 */

/**
 * The public-facing functionality of the plugin.
 *
 * Defines the plugin name, version, and two examples hooks for how to
 * enqueue the public-facing stylesheet and JavaScript.
 *
 * @package    Wordpress_Crypto_Watcher
 * @subpackage Wordpress_Crypto_Watcher/public
 * @author     MakeWebBetter <support@makewebbetter.com>
 */
class Wordpress_Crypto_Watcher_Public {

	/**
	 * The ID of this plugin.
	 *
	 * @since    1.0.0
	 * @access   private
	 * @var      string    $plugin_name    The ID of this plugin.
	 */
	private $plugin_name;

	/**
	 * The version of this plugin.
	 *
	 * @since    1.0.0
	 * @access   private
	 * @var      string    $version    The current version of this plugin.
	 */
	private $version;

	/**
	 * Initialize the class and set its properties.
	 *
	 * @since    1.0.0
	 * @param      string    $plugin_name       The name of the plugin.
	 * @param      string    $version    The version of this plugin.
	 */
	public function __construct( $plugin_name, $version ) {

		$this->plugin_name = $plugin_name;
		$this->version = $version;
		add_shortcode('mwb_wcw_crypto', array($this, 'mwb_wcw_render_table'));

	}

	/**
	 * Register the stylesheets for the public-facing side of the site.
	 *
	 * @since    1.0.0
	 */
	public function enqueue_styles() {

		/**
		 * This function is provided for demonstration purposes only.
		 *
		 * An instance of this class should be passed to the run() function
		 * defined in Wordpress_Crypto_Watcher_Loader as all of the hooks are defined
		 * in that particular class.
		 *
		 * The Wordpress_Crypto_Watcher_Loader will then create the relationship
		 * between the defined hooks and the functions defined in this
		 * class.
		 */

		

	}

	/**
	 * Register the JavaScript for the public-facing side of the site.
	 *
	 * @since    1.0.0
	 */
	public function enqueue_scripts() {

		/**
		 * This function is provided for demonstration purposes only.
		 *
		 * An instance of this class should be passed to the run() function
		 * defined in Wordpress_Crypto_Watcher_Loader as all of the hooks are defined
		 * in that particular class.
		 *
		 * The Wordpress_Crypto_Watcher_Loader will then create the relationship
		 * between the defined hooks and the functions defined in this
		 * class.
		 */

		$data_arr = array(
			'ajax_url' => admin_url('admin-ajax.php'),
			'mwb_wcw_nonce' => wp_create_nonce('mwb_wcw_nonce_text')
		);
		wp_enqueue_script( 'mwb_wcw_socket', 'https://cdnjs.cloudflare.com/ajax/libs/socket.io/1.7.2/socket.io.js', '', $this->version, true );
		wp_enqueue_script( 'mwb_wcw_streamer', plugin_dir_url( __FILE__ ) . 'js/ccc-streamer-utilities.js', '', $this->version, true );

		$news_count = get_option("wp_crypto_watcher_news_count", false);
		$cryptocurrency = get_option("wp_crypto_watcher_currency", false);
		if(empty($cryptocurrency)){
			$cryptocurrency= array("Ƀ","Ξ","Ł","DASH","XMR","NXT","ETC","DOGE","ZEC","BTS","DGB","XRP","BTCD","PPC","CRAIG","XBS","XPY","PRC","YBC","DANK","GIVE","KOBO","DT","CETI","SUP","XPD","GEO","CHASH","SPR","NXTI");
		}

		$crtypo_data = array("count" => $news_count, "currency" => $cryptocurrency, 'mwb_market_cap_text' => __("Market Cap", "wordpress-crypto-watcher"), 'mwb_market_price_text' => __("Price", "wordpress-crypto-watcher"));
		
		wp_register_script( $this->plugin_name, plugin_dir_url( __FILE__ ) . 'js/wordpress-crypto-watcher-public.js', array( 'jquery', 'mwb_wcw_socket', 'mwb_wcw_streamer'), $this->version, true );
		wp_localize_script( $this->plugin_name, "mwb_crypto_data", $crtypo_data);
		wp_enqueue_script( $this->plugin_name);

		wp_enqueue_script( 'mwb_wcw_chart', 'https://cdnjs.cloudflare.com/ajax/libs/Chart.js/2.7.1/Chart.bundle.min.js', '', $this->version, false );
		wp_localize_script( $this->plugin_name, 'mwb_wcw_obj', $data_arr);

	}

	/**
	 * This function is used to add Menu Setting in wordpress admin
	 * 
	 * @since 1.0.0
	 */	
	function mwb_wcw_admin_setting()
	{
		 add_menu_page( __( 'WP Crypto Watcher', 'wp-crypto-watcher' ), 'WP Crypto Watcher', 'manage_options', 'wp-crypto-watcher', array($this, 'wp_crypto_watcher_page')); 
	}

	/**
	 * This function is used to Show Menu Setting Page in wordpress admin
	 * 
	 * @since 1.0.0
	 */

	function wp_crypto_watcher_page()
	{
			include_once(MWB_WCW_PATH.'/admin/partials/wordpress-crypto-watcher-admin-display.php');
	}

	/**
	 * This function is used to Save Setting in wordpress admin
	 * 
	 * @since 1.0.0
	 */

	function mwb_wcw_save_admin_setting()
	{
		if(isset($_POST['wp_crypto_save']))
		{
			$_POST['wp_crypto_watcher_enable'] = isset($_POST['wp_crypto_watcher_enable'])?1:0;
			$_POST['wp_crypto_watcher_news_enable'] = isset($_POST['wp_crypto_watcher_news_enable'])?1:0;
			$_POST['wp_crypto_watcher_currency_switch_enable'] = isset($_POST['wp_crypto_watcher_currency_switch_enable'])?1:0;
			$_POST['wp_crypto_watcher_currency'] = isset($_POST['wp_crypto_watcher_currency'])?$_POST['wp_crypto_watcher_currency']:array();
			$_POST['wp_crypto_watcher_currency_symbol'] = isset($_POST['wp_crypto_watcher_currency_symbol'])?$_POST['wp_crypto_watcher_currency_symbol']:array();
			

			unset($_POST['wp_crypto_save']);
			$postdata = $_POST;
			if(isset($postdata) && !empty($postdata))
			{
				foreach ($postdata as $key => $value) 
				{
					if(!is_array($value)){
						$value = stripcslashes($value);
					}
					
					update_option($key, $value);
				}
			}
		}	
	}

	/**
	 * This function is List the Currency Value
	 * 
	 * @since 1.0.0
	 */
	function mwb_wcw_history_list()
	{
		print_r($_POST);
		$news_res = wp_remote_get($_POST['mwb_url'], array('timeout' => 20, 'sslverify' => false));
		$news_res = json_decode($news_res['body'], true);
		$mwb_grp_time;
		$mwb_grp_cap;
		$mwb_grp_pri;
		foreach ($news_res['market_cap'] as $key => $value) 
		{
			$mwb_grp_time[] = date('Y-m-d H:i:s', ($value[0]/1000));
			$mwb_grp_cap[] = $value[1]*$_POST['multiplier'];
			$mwb_grp_pri[] = $news_res['price'][$key][1]*$_POST['multiplier'];
		}
		echo json_encode( array('time' => $mwb_grp_time, 'cap' => $mwb_grp_cap, 'price' => $mwb_grp_pri));
		die();
	}

	/**
	 * This function is List the News Value
	 * 
	 * @since 1.0.0
	 */
	function mwb_wcw_news_list()
	{
		$news_res = wp_remote_get('https://min-api.cryptocompare.com/data/news/', array('timeout' => 20, 'sslverify' => false));
		$news_res = json_decode($news_res['body'], true);
		echo json_encode($news_res);
		die();
	}

	/**
	 * This function is List the News Value
	 * 
	 * @since 1.0.0
	 */
	function mwb_wcw_coin_list()
	{
		$ajax_referer = check_ajax_referer('mwb_wcw_nonce_text', 'mwb_wcw_nonce');
		if( $ajax_referer )
		{
			$mwb_arr = array();
			$symbol_array = array(
				'BTC',
				'ETH',
				'LTC',
				'DASH',
				'XMR',
				'NXT',
				'ETC',
				'DOGE',
				'ZEC',
				'BTS',
				'DGB',
				'XRP',
				'BTCD',
				'PPC',
				'CRAIG',
				'XBS',
				'XPY',
				'PRC',
				'YBC',
				'DANK',
				'GIVE',
				'KOBO',
				'DT',
				'CETI',
				'SUP',
				'XPD',
				'GEO',
				'CHASH',
				'SPR',
				'NXTI',
				'WOLF',
				'XDP',
				'2015',
				'42',
				'AC',
				'ACOIN',
				'AERO',
				'ALF',
				'AGS',
				'AMC',
				'ALN',
				'APEX',
				'ARCH',
				'ARG',
				'ARI',
				'AUR',
				'AXR',
				'BCX',
				'BEN',
				'BET',
				'BITB',
				'BLU',
				'BLK',
				'BOST',
				'BQC',
				'XMY',
				'MOON',
				'ZET',
				'SXC',
				'QTL',
				'ENRG',
				'QRK',
				'RIC',
				'DGC',
				'LIMX',
				'BTB',
				'CAIX',
				'BTE',
				'BTG*',
				'BTM',
				'BUK',
				'CACH',
				'CANN',
				'CAP',
				'CASH',
				'CAT1',
				'CBX',
				'CCN',
				'CIN',
				'CINNI',
				'CXC',
				'CLAM',
				'CLOAK',
				'CLR',
				'CMC',
				'CNC',
				'CNL',
				'COMM',
				'COOL',
				'CRACK',
				'CRC*',
				'CRYPT',
				'CSC',
				'DEM',
				'DMD',
				'XVG',
				'DRKC',
				'DSB',
				'DVC',
				'EAC',
				'EFL',
				'ELC',
				'EMC2',
				'EMD',
				'EXCL',
				'EXE',
				'EZC',
				'FLAP',
				'FC2',
				'FFC',
				'FIBRE',
				'FRC',
				'FLT',
				'FRK',
				'FRAC',
				'FST',
				'FTC',
				'GDC',
				'GLC',
				'GLD',
				'GLX',
				'GLYPH',
				'GML',
				'GUE',
				'HAL',
				'HBN',
				'HUC',
				'HVC',
				'HYP',
				'ICB',
				'IFC',
				'IOC',
				'IXC',
				'JBS',
				'JKC',
				'JUDGE',
				'KDC',
				'KEY*',
				'KGC',
				'LAB*',
				'LGD*',
				'LK7',
				'LKY',
				'LSD',
				'LTB',
				'LTCD',
				'LTCX',
				'LXC',
				'LYC',
				'MAX',
				'MEC',
				'MED',
				'MIN',
				'MINT',
				'MN',
				'MNC',
				'MRY',
				'MYST*',
				'MZC',
				'NAN',
				'NAUT',
				'NAV',
				'NBL',
				'NEC',
				'NET',
				'NMB',
				'NRB',
				'NOBL',
				'NRS',
				'NVC',
				'NMC',
				'NYAN',
				'OPAL',
				'ORB',
				'OSC',
				'PHS',
				'POINTS',
				'POT',
				'PSEUD',
				'PTS*',
				'PXC',
				'PYC',
				'RDD',
				'RIPO',
				'RPC',
				'RT2',
				'RYC',
				'RZR',
				'SAT2',
				'SBC',
				'SDC',
				'SFR',
				'SHADE',
				'SHLD',
				'SILK',
				'SLG',
				'SMC',
				'SOLE',
				'SPA',
				'SPT',
				'SRC',
				'SSV',
				'XLM',
				'SUPER',
				'SWIFT',
				'SYNC',
				'SYS',
				'TAG',
				'TAK',
				'TES',
				'TGC',
				'TIT',
				'TOR',
				'TRC',
				'TTC',
				'ULTC',
				'UNB',
				'UNO',
				'URO',
				'USDE',
				'UTC',
				'UTIL',
				'VDO',
				'VIA',
				'VOOT',
				'VRC',
				'VTC',
				'WC',
				'WDC',
				'XAI',
				'XBOT',
				'XC',
				'XCASH',
				'XCR',
				'XJO',
				'XLB',
				'XPM',
				'XST',
				'XXX',
				'YAC',
				'ZCC',
				'ZED',
				'ZRC*',
				'BCN',
				'EKN',
				'XDN',
				'XAU',
				'TMC',
				'XEM',
				'BURST',
				'NBT',
				'SJCX',
				'START',
				'HUGE',
				'XCP',
				'MAID',
				'007',
				'NSR',
				'MONA',
				'CELL',
				'TEK',
				'TRON',
				'BAY',
				'NTRN',
				'SLING',
				'XVC',
				'CRAVE',
				'BLOCK',
				'XSI',
				'GHS',
				'BYC',
				'GRC',
				'GEMZ',
				'KTK',
				'HZ',
				'FAIR',
				'QORA',
				'NLG',
				'RBY',
				'PTC',
				'KORE',
				'WBB',
				'SSD',
				'XTC',
				'NOTE',
				'GRID*',
				'FLO',
				'MMXIV',
				'8BIT',
				'STV',
				'EBS',
				'AM',
				'XMG',
				'AMBER',
				'JPC',
				'NKT',
				'J',
				'GHC',
				'DTC*',
				'ABY',
				'LDOGE',
				'MTR',
				'TRI',
				'SWARM',
				'BBR',
				'BTCRY',
				'BCR',
				'XPB',
				'XDQ',
				'FLDC',
				'SLR',
				'SMAC',
				'TRK',
				'U',
				'UIS',
				'CYP',
				'UFO',
				'ASN',
				'OC',
				'GSM',
				'FSC2',
				'NXTTY',
				'QBK',
				'BLC',
				'MARYJ',
				'OMC',
				'GIG',
				'CC',
				'BITS',
				'LTBC',
				'NEOS',
				'HYPER',
				'VTR',
				'METAL',
				'PINK',
				'GRE',
				'XG',
				'CHILD',
				'BOOM',
				'MINE',
				'ROS',
				'UNAT',
				'SLM',
				'GAIA',
				'TRUST',
				'FCN',
				'XCN',
				'CURE',
				'GMC',
				'MMC',
				'XBC',
				'CYC',
				'OCTO',
				'MSC',
				'EGG',
				'C2',
				'GSX',
				'CAM',
				'RBR',
				'XQN',
				'ICASH',
				'NODE',
				'SOON',
				'BTMI',
				'EVENT',
				'1CR',
				'VIOR',
				'XCO',
				'VMC',
				'MRS',
				'VIRAL',
				'EQM',
				'ISL',
				'QSLV',
				'XWT',
				'XNA',
				'RDN',
				'SKB',
				'BSTY',
				'FCS',
				'GAM',
				'NXS',
				'CESC',
				'TWLV',
				'EAGS',
				'MWC',
				'ADC',
				'MARS',
				'XMS',
				'SPHR',
				'SIGU',
				'BTX*',
				'DCC',
				'M1',
				'DB',
				'CTO',
				'EDGE',
				'LUX*',
				'FUTC',
				'GLOBE',
				'TAM',
				'MRP',
				'CREVA',
				'XFC',
				'NANAS',
				'LOG',
				'XCE',
				'ACP',
				'DRZ',
				'BUCKS*',
				'BSC',
				'DRKT',
				'CIRC',
				'NKA',
				'VERSA',
				'EPY',
				'SQL',
				'POLY',
				'PIGGY',
				'CHA',
				'MIL',
				'CRW',
				'GEN',
				'XPH',
				'GRM',
				'QTZ',
				'ARB',
				'LTS',
				'SPC',
				'GP',
				'BITZ',
				'DUB',
				'GRAV',
				'BOB',
				'MCN',
				'QCN',
				'HEDG',
				'SONG',
				'XSEED',
				'CRE',
				'AXIOM',
				'SMLY',
				'RBT',
				'CHIP',
				'SPEC',
				'GRAM',
				'UNC',
				'SPRTS',
				'ZNY',
				'BTQ',
				'PKB',
				'STR*',
				'SNRG',
				'GHOUL',
				'HNC',
				'DIGS',
				'EXP',
				'GCR',
				'MAPC',
				'MI',
				'CON',
				'NEU*',
				'TX',
				'GRS',
				'SC',
				'CLV',
				'FCT',
				'LYB',
				'BST',
				'PXI',
				'CPC',
				'AMS',
				'OBITS',
				'CLUB',
				'RADS',
				'EMC',
				'BLITZ',
				'HIRE*',
				'EGC',
				'MND',
				'I0C',
				'BTA',
				'KARMA',
				'DCR',
				'NAS2',
				'PAK',
				'CRB',
				'DOGED',
				'REP',
				'OK',
				'VOX',
				'AMP',
				'HODL',
				'DGD',
				'EDRC',
				'LSK',
				'WAVES',
				'HTC',
				'GAME',
				'DSH',
				'DBIC',
				'XHI',
				'SPOTS',
				'BIOS',
				'KNC*',
				'CAB',
				'DIEM',
				'GBT',
				'SAR',
				'RCX',
				'PWR',
				'TRUMP',
				'PRM',
				'BCY',
				'RBIES',
				'STEEM',
				'BLRY',
				'XWC',
				'DOT',
				'SCOT',
				'DNET',
				'BAC',
				'XID*',
				'GRT',
				'TCR',
				'POST',
				'INFX',
				'ETHS',
				'PXL',
				'NUM',
				'SOUL',
				'ION',
				'GROW',
				'UNITY',
				'OLDSF',
				'SSTC',
				'NETC',
				'GPU',
				'TAGR',
				'HMP',
				'ADZ',
				'GAP',
				'MYC',
				'IVZ',
				'VTA',
				'SLS',
				'SOIL',
				'CUBE',
				'YOC',
				'COIN*',
				'VPRC',
				'APC',
				'STEPS',
				'DBTC',
				'UNIT',
				'AEON',
				'MOIN',
				'SIB',
				'ERC',
				'AIB',
				'PRIME',
				'BERN',
				'BIGUP',
				'KR',
				'XRE',
				'1337',
				'MEME',
				'XDB',
				'ANTI',
				'BRK',
				'COLX',
				'MNM',
				'ADCN',
				'ZEIT',
				'611',
				'2GIVE',
				'CGA',
				'SWING',
				'SAFEX',
				'NEBU',
				'AEC',
				'FRN',
				'ADN',
				'PULSE',
				'N7',
				'CYG',
				'LGBTQ',
				'UTH',
				'MPRO',
				'KAT',
				'404',
				'SPM',
				'MOJO',
				'BELA',
				'FLX',
				'BOLI',
				'CLUD',
				'DIME',
				'FLY',
				'HVCO',
				'GIZ',
				'GREXIT',
				'CARBON',
				'DEUR',
				'TUR',
				'LEMON',
				'STS',
				'DISK',
				'NEVA',
				'CYT',
				'FUZZ',
				'NKC',
				'SCRT',
				'XRA',
				'XNX',
				'STAR*',
				'STHR',
				'DBG',
				'BON',
				'WMC',
				'GOTX',
				'FLVR',
				'SHREK',
				'STA*',
				'RISE',
				'REV',
				'PBC',
				'OBS',
				'EXIT',
				'EDC',
				'CLINT',
				'CKC',
				'VIP',
				'NXE',
				'ZOOM',
				'DRACO',
				'YOVI',
				'ORLY',
				'KUBO',
				'INCP',
				'SAK',
				'EVIL',
				'OMA',
				'MUE',
				'COX',
				'BNT',
				'BSD',
				'DES',
				'BIT16',
				'PDC',
				'CMT',
				'CHESS',
				'SPACE',
				'REE',
				'LQD',
				'MARV',
				'XDE2',
				'VEC2',
				'OMNI',
				'GSY',
				'TKN*',
				'LIR',
				'MMNXT',
				'SCRPT',
				'LBC',
				'SPX',
				'SBD',
				'CJ',
				'PUT',
				'KRAK',
				'DLISK',
				'IBANK',
				'STRAT',
				'VOYA',
				'ENTER',
				'WGC',
				'BM',
				'FRWC',
				'PSY',
				'XT',
				'RUST',
				'NZC',
				'SNGLS',
				'XAUR',
				'BFX',
				'UNIQ',
				'CRX',
				'DCT',
				'XPOKE',
				'MUDRA',
				'WARP',
				'CNMT',
				'PIZZA',
				'LC',
				'HEAT',
				'ICN',
				'EXB',
				'WINGS',
				'CDX*',
				'RBIT',
				'DCS.',
				'KMD',
				'GB',
				'NEO',
				'ANC',
				'SYNX',
				'MC',
				'EDR',
				'JWL',
				'WAY',
				'TAB',
				'TRIG',
				'BITCNY',
				'BITUSD',
				'ATM*',
				'STO',
				'SNS',
				'FSN',
				'CTC',
				'TOT',
				'BTD',
				'BOTS',
				'MDC',
				'FTP',
				'ZET2',
				'COV*',
				'KRB',
				'TELL',
				'ENE',
				'TDFB',
				'BLOCKPAY',
				'BXT',
				'ZYD',
				'MST',
				'GOON',
				'808',
				'VLT',
				'ZNE',
				'DCK',
				'COVAL',
				'DGDC',
				'TODAY',
				'VRM',
				'ROOT',
				'1ST',
				'GPL',
				'DOPE',
				'B3',
				'FX',
				'PIO',
				'GAY',
				'SMSR',
				'UBIQ',
				'ARM',
				'RING',
				'ERB',
				'LAZ',
				'FONZ',
				'BTCR',
				'DROP',
				'SANDG',
				'PNK',
				'MOOND',
				'DLC',
				'SEN',
				'SCN',
				'WEX',
				'LTH',
				'BRONZ',
				'SH',
				'BUZZ',
				'MG',
				'PSI',
				'XPO',
				'NLC',
				'PSB',
				'XBTS',
				'FIT',
				'PINKX',
				'FIRE',
				'UNF',
				'SPORT',
				'PPY',
				'NTC',
				'EGO',
				'BTCL*',
				'RCN*',
				'X2',
				'MT',
				'TIA',
				'GBRC',
				'XUP',
				'888',
				'HALLO',
				'BBCC',
				'EMIGR',
				'BHC',
				'CRAFT',
				'INV',
				'OLYMP',
				'DPAY',
				'ATOM',
				'HKG',
				'ANTC',
				'JOBS',
				'DGORE',
				'THC',
				'TRA',
				'RMS',
				'FJC',
				'VAPOR',
				'SDP',
				'RRT',
				'XZC',
				'PRE',
				'CALC',
				'LEA',
				'CF',
				'CRNK',
				'CFC',
				'VTY',
				'SFE',
				'ARDR',
				'BS',
				'JIF',
				'CRAB',
				'AIR*',
				'HILL',
				'FOREX',
				'MONETA',
				'EC',
				'RUBIT',
				'HCC',
				'BRAIN',
				'VTX',
				'KRC',
				'ROYAL',
				'LFC',
				'ZUR',
				'NUBIS',
				'TENNET',
				'PEC',
				'GMX',
				'32BIT',
				'GNJ',
				'TEAM',
				'SCT',
				'LANA',
				'ELE',
				'GCC',
				'AND',
				'GBYTE',
				'EQUAL',
				'SWEET',
				'2BACCO',
				'DKC',
				'COC',
				'CHOOF',
				'CSH',
				'ZCL',
				'RYCN',
				'PCS',
				'NBIT',
				'WINE',
				'DAR',
				'ARK',
				'IFLT',
				'ZECD',
				'ZXT',
				'WASH',
				'TESLA',
				'LUCKY',
				'VSL',
				'TPG',
				'LEO',
				'MDT',
				'CBD',
				'PEX',
				'INSANE',
				'GNT',
				'PEN',
				'BASH',
				'FAME',
				'LIV',
				'SP',
				'MEGA',
				'VRS',
				'ALC',
				'DOGETH',
				'KLC',
				'HUSH',
				'BTLC',
				'DRM8',
				'FIST',
				'EBZ',
				'365',
				'DRS',
				'FGZ',
				'BOSON',
				'ATX',
				'PNC',
				'BRDD',
				'TIME',
				'BIP',
				'XNC',
				'EMB',
				'BTTF',
				'DLR',
				'CSMIC',
				'FIRST',
				'SCASH',
				'XEN',
				'JIO',
				'IW',
				'JNS',
				'TRICK',
				'DCRE',
				'FRE',
				'NPC',
				'PLNC',
				'DGMS',
				'ICOB',
				'ARCO',
				'KURT',
				'XCRE',
				'ENT',
				'UR',
				'MTLM3',
				'ODNT',
				'EUC',
				'CCX',
				'BCF',
				'SEEDS',
				'POSW',
				'TKS',
				'BCCOIN',
				'SHORTY',
				'PCM',
				'KC',
				'CORAL',
				'BamitCoin',
				'NXC',
				'MONEY',
				'BSTAR',
				'HSP',
				'HZT',
				'CS',
				'XSP',
				'CCRB',
				'BULLS',
				'INCNT',
				'ICON',
				'NIC',
				'ACN',
				'XNG',
				'XCI',
				'LOOK',
				'LOC',
				'MMXVI',
				'TRST',
				'MIS',
				'WOP',
				'CQST',
				'IMPS',
				'IN',
				'CHIEF',
				'GOAT',
				'ANAL',
				'RC',
				'PND',
				'PX',
				'CND*',
				'OPTION',
				'AV',
				'LTD',
				'UNITS',
				'HEEL',
				'GAKH',
				'SHIFT',
				'S8C',
				'LVG',
				'DRA',
				'ASAFE2',
				'LTCR',
				'QBC',
				'XPRO',
				'AST*',
				'GIFT',
				'VIDZ',
				'INC',
				'PTA',
				'ACID',
				'ZLQ',
				'RADI',
				'RNC',
				'GOLOS',
				'PASC',
				'TWIST',
				'PAYP',
				'DETH',
				'YAY',
				'YES',
				'LENIN',
				'MRSA',
				'OS76',
				'BOSS',
				'MKR',
				'BIC',
				'CRPS',
				'MOTO',
				'NTCC',
				'XNC*',
				'HXX',
				'SPKTR',
				'MAC',
				'SEL',
				'NOO',
				'CHAO',
				'XGB',
				'YMC',
				'JOK',
				'GBIT',
				'TEC',
				'BOMB',
				'RIDE',
				'PIVX',
				'KED',
				'CNO',
				'WEALTH',
				'IOP',
				'XSPEC',
				'PEPECASH',
				'CLICK',
				'ELS',
				'KUSH',
				'ERY',
				'PLU',
				'PRES',
				'BTZ',
				'OPES',
				'WCT',
				'UBQ',
				'RATIO',
				'BAN',
				'NICE',
				'SMF',
				'CWXT',
				'TECH',
				'CIR',
				'LEPEN',
				'ROUND',
				'MAR',
				'MARX',
				'TAT',
				'HAZE',
				'PRX',
				'NRC',
				'PAC',
				'IMPCH',
				'ERR',
				'TIC',
				'NUKE',
				'EOC',
				'SFC',
				'JANE',
				'PARA',
				'MM',
				'BXC',
				'NDOGE',
				'ZBC',
				'MLN',
				'FRST',
				'PAY',
				'ORO',
				'ALEX',
				'TBCX',
				'MCAR',
				'THS',
				'ACES',
				'UAEC',
				'EA',
				'PIE',
				'CREA',
				'WISC',
				'BVC',
				'FIND',
				'MLITE',
				'STALIN',
				'TSE',
				'VLTC',
				'BIOB',
				'SWT',
				'PASL',
				'ZER',
				'CHAT',
				'CDN',
				'TPAY',
				'NETKO',
				'ZOI',
				'HONEY',
				'MXT',
				'MUSIC',
				'DTB',
				'VEG',
				'MBIT',
				'VOLT',
				'MGO',
				'EDG',
				'B@',
				'BEST',
				'CHC',
				'ZENI',
				'PLANET',
				'DUCK',
				'BNX',
				'BSTK',
				'RNS',
				'DBIX',
				'AMIS',
				'KAYI',
				'XVP',
				'BOAT',
				'TAJ',
				'IMX',
				'CJC',
				'AMY',
				'QBT',
				'SRC*',
				'EB3',
				'XVE',
				'FAZZ',
				'APT',
				'BLAZR',
				'ARPA',
				'BNB*',
				'UNI',
				'ECO',
				'XLR',
				'DARK',
				'DON',
				'MER',
				'WGO',
				'RLC',
				'ATMS',
				'INPAY',
				'ETT',
				'WBTC',
				'VISIO',
				'HPC',
				'GOT',
				'CXT',
				'EMPC',
				'GNO',
				'LGD',
				'TAAS',
				'BUCKS',
				'XBY',
				'GUP',
				'MCRN',
				'LUN',
				'RAIN',
				'WSX',
				'IEC',
				'IMS',
				'ARGUS',
				'CNT',
				'LMC',
				'TKN',
				'BTCS',
				'PROC',
				'XGR',
				'WRC*',
				'BENJI',
				'HMQ',
				'BCAP',
				'DUO',
				'RBX',
				'GRW',
				'APX',
				'MILO',
				'OLV',
				'ILC',
				'MRT',
				'IOU',
				'PZM',
				'PHR',
				'ANT',
				'PUPA',
				'RICE',
				'XCT',
				'DEA',
				'RED',
				'ZSE',
				'CTIC',
				'TAP',
				'BITOK',
				'PBT',
				'MUU',
				'INF8',
				'HTML5',
				'MNE',
				'DICE',
				'SUB*',
				'USC',
				'DUX',
				'XPS',
				'EQT',
				'INSN',
				'BAT',
				'MAT*',
				'F16',
				'HAMS',
				'QTUM',
				'NEF',
				'ZEN',
				'BOS',
				'QWARK',
				'IOT',
				'QRL',
				'ADL',
				'ECC*',
				'PTOY',
				'ZRC',
				'LKK',
				'ESP',
				'MAD',
				'DYN',
				'SEQ',
				'MCAP',
				'MYST',
				'VERI',
				'SNM',
				'SKY',
				'CFI',
				'SNT',
				'AVT',
				'CVC',
				'IXT',
				'DENT',
				'BQX',
				'STA',
				'TFL',
				'EFYT',
				'XTZ',
				'EOS',
				'MCO',
				'NMR',
				'ADX',
				'QAU',
				'ECOB',
				'PLBT',
				'USDT',
				'XRB',
				'AHT',
				'ATB',
				'TIX',
				'CHAN',
				'CMP',
				'RVT',
				'HRB',
				'NET*',
				'8BT',
				'CDT',
				'ACT',
				'DNT',
				'SUR',
				'PING',
				'MIV',
				'BET*',
				'SAN',
				'KIN',
				'WGR',
				'XEL',
				'NVST',
				'FUN',
				'FUNC',
				'PQT',
				'WTT',
				'MTL',
				'HVN',
				'MYB',
				'PPT',
				'SNC',
				'STAR',
				'COR',
				'XRL',
				'OROC',
				'OAX',
				'MBI',
				'DDF',
				'DIM',
				'GGS',
				'DNA',
				'FYN',
				'FND',
				'DCY',
				'CFT',
				'DNR',
				'DP',
				'VUC',
				'BTPL',
				'UNIFY',
				'IPC',
				'BRIT',
				'AMMO',
				'SOCC',
				'MASS',
				'LA',
				'IML',
				'XUC',
				'STU',
				'PLR',
				'GUNS',
				'IFT',
				'CAT*',
				'PRO',
				'SYC',
				'IND',
				'AHT*',
				'TRIBE',
				'ZRX',
				'TNT',
				'PRE*',
				'COSS',
				'STORM',
				'NPX',
				'STORJ',
				'SCORE',
				'OMG',
				'OTX',
				'EQB',
				'VOISE',
				'ETBS',
				'CVCOIN',
				'DRP',
				'ARC',
				'BOG',
				'NDC',
				'POE',
				'ADT',
				'AE',
				'UET',
				'PART',
				'AGRS',
				'SAND',
				'XAI*',
				'DMT',
				'DAS',
				'ADST',
				'CAT',
				'XCJ',
				'RKC',
				'NLC2',
				'LINDA',
				'SPN',
				'KING',
				'ANCP',
				'RCC',
				'ROOTS',
				'SNK',
				'CABS',
				'OPT',
				'ZNT',
				'BITSD',
				'XLC',
				'SKIN',
				'MSP',
				'HIRE',
				'BBT*',
				'REAL',
				'DFBT',
				'EQ',
				'WLK',
				'VIB',
				'ONION',
				'BTX',
				'ICE',
				'XID',
				'GCN',
				'ATOM*',
				'MANA',
				'ICOO',
				'TME',
				'SMART',
				'SIGT',
				'ONX',
				'COE',
				'ARENA',
				'WINK',
				'CRM',
				'BCH',
				'DGPT',
				'MOBI',
				'CSNO',
				'KICK',
				'SDAO',
				'STX',
				'BNB',
				'CORE',
				'KCN',
				'QVT',
				'TIE',
				'AUT',
				'CTT',
				'GRWI',
				'MNY',
				'MTH',
				'CCC',
				'UMC',
				'BMXT',
				'GAS',
				'FIL',
				'OCL',
				'BNC',
				'TOM',
				'BTM*',
				'XAS',
				'SMNX',
				'DCN',
				'DLT',
				'MRV',
				'MBRS',
				'SUB',
				'MET',
				'NEBL',
				'PGL',
				'XMCC',
				'AUTH',
				'CASH*',
				'CMPCO',
				'DTCT',
				'CTR',
				'WNET',
				'PRG',
				'THNX',
				'WORM',
				'FUCK',
				'VNT',
				'SIFT',
				'IGNIS',
				'IWT',
				'JDC',
				'ITT',
				'LNC',
				'AIX',
				'EVX',
				'ENTRP',
				'ICOS',
				'PIX',
				'MEDI',
				'HGT',
				'LTA',
				'NIMFA',
				'SCOR',
				'MLS',
				'KEX',
				'COB',
				'BRO',
				'MINEX',
				'ATL',
				'ARI*',
				'MAG*',
				'DFT',
				'VEN',
				'UTK',
				'LAT',
				'SOJ',
				'HDG',
				'STCN',
				'SQP',
				'RIYA',
				'LNK',
				'AMB',
				'WAN',
				'MNT',
				'ALTOCAR',
				'CFT*',
				'BLX',
				'BKX',
				'BOU',
				'OXY',
				'TTT',
				'AMT',
				'GIM',
				'NYC',
				'LBTC',
				'FRAZ',
				'EMT',
				'GXC',
				'HBT',
				'KRONE',
				'SRT',
				'AVA',
				'BT',
				'ACC',
				'AR*',
				'Z2',
				'LINX',
				'XCXT',
				'BLAS',
				'GOOD',
				'SCL',
				'TRV',
				'CRTM',
				'EON',
				'PST',
				'MTX',
				'PRIX',
				'CTX',
				'ENJ',
				'CNX',
				'DRC',
				'FUEL',
				'ACE',
				'WRC',
				'WTC',
				'BRX',
				'UCASH',
				'WRT',
				'ORME',
				'DEEP',
				'TMT',
				'CCT*',
				'WSH',
				'ARNA*',
				'ABC',
				'PRP',
				'BMC',
				'SKR*',
				'3DES',
				'PYN',
				'KAPU',
				'SENSE',
				'CAPP',
				'VEE',
				'FC',
				'RCN',
				'NRN',
				'EVC',
				'LINK',
				'WIZ',
				'EDO',
				'ATKN',
				'KNC',
				'RUSTBITS',
				'REX',
				'ETHD',
				'SUMO',
				'TRX',
				'8S',
				'H2O',
				'TKT',
				'RHEA',
				'ART',
				'DRT',
				'SNOV',
				'DTT',
				'MTN',
				'STOCKBET',
				'PLM',
				'FDC',
				'SALT',
				'SND',
				'XP',
				'LRC',
				'HSR',
				'GLA',
				'ZNA',
				'EZM',
				'ODN',
				'POLL',
				'MTK',
				'CAS',
				'MAT',
				'GJC',
				'WIC',
				'WEB',
				'WAND',
				'ELIX',
				'EBTC',
				'HAC',
				'ADA',
				'YOYOW',
				'REC',
				'BIS',
				'OPP',
				'ROCK',
				'EARTH',
				'ICX',
				'VSX',
				'WISH*',
				'FLASH',
				'GRF*',
				'BTCZ',
				'CZC',
				'PPP',
				'GUESS',
				'CAN',
				'ETP',
				'CIX',
				'ERT',
				'BAC*',
				'FLIK',
				'TRIP',
				'MBT',
				'JVY',
				'ALIS',
				'LEV',
				'ARBI',
				'ELT',
				'REQ',
				'ARN',
				'DAT',
				'VIBE',
				'ROK',
				'XRED',
				'DAY',
				'AST',
				'FLP',
				'HXT',
				'CND',
				'VRP*',
				'NTM',
				'TZC',
				'ENG',
				'MCI',
				'COV',
				'WAX',
				'AIR',
				'NTO',
				'ATCC',
				'KOLION',
				'WILD',
				'ELTC2',
				'ILCT',
				'POWR',
				'C20',
				'RYZ',
				'GXC*',
				'ELM',
				'TER',
				'XCS',
				'BQ',
				'CAV',
				'CLOUT',
				'PTC*',
				'WABI',
				'EVR',
				'TOA',
				'MNZ',
				'VIVO',
				'RPX',
				'MDA',
				'ZSC',
				'AURS',
				'CAG',
				'PKT',
				'SMT**',
				'ECHT',
				'INXT',
				'ATS',
				'RGC',
				'EBET',
				'R',
				'MOD',
				'BM*',
				'CPAY',
				'RUP',
				'BON*',
				'APPC',
				'WHL',
				'BTG',
				'UP',
				'ETG',
				'WOMEN',
				'MAY',
				'RNDR',
				'EDDIE',
				'SCT*',
				'NAMO',
				'KCS',
				'GAT',
				'BLUE',
				'FLLW',
				'WYR',
				'VZT',
				'INDI',
				'LUX',
				'BAR',
				'PIRL',
				'ECASH',
				'WPR',
				'DRGN',
				'ODMC',
				'CABS*',
				'BRAT',
				'DTR',
				'TKR',
				'KEY',
				'ELITE',
				'XIOS',
				'DOVU',
				'ETN',
				'REA',
				'AVE',
				'XNN',
				'BTDX',
				'LOAN*',
				'DTT*',
				'ZAB',
				'MDL',
				'BT1',
				'BT2',
				'SHP',
				'JCR',
				'XSB',
				'ATM**',
				'EBST',
				'KEK',
				'AID',
				'BHC*',
				'ALTCOM',
				'OST',
				'DATA',
				'UGC',
				'DTC',
				'PLAY',
				'PURE',
				'CLD',
				'OTN',
				'POS',
				'REBL',
				'NEOG',
				'EXN',
				'INS',
				'TRCT',
				'UKG',
				'BTCRED',
				'EBCH',
				'JPC*',
				'AXT',
				'RDN*',
				'NEU',
				'RUPX',
				'BDR',
				'XIN*',
				'DUTCH',
				'TIO',
				'HNC*',
				'MDC*',
				'PURA',
				'INN',
				'HST',
				'BCPT',
				'BDL',
				'CMS',
				'XBL',
				'ZEPH',
				'ATFS',
				'GES',
				'NULS',
				'PHR*',
				'LCASH',
				'CFD',
				'SPHTX',
				'PLC',
				'SRN',
				'WSC',
				'DBET',
				'xGOx',
				'NEWB',
				'LIFE',
				'RMC',
				'CREDO',
				'MSR',
				'CJT',
				'ESC*',
				'EVN',
				'BNK',
				'ELLA',
				'BPL',
				'ROCK*',
				'DRXNE',
				'SKR',
				'GRID',
				'XPTX',
				'GVT',
				'ETK',
				'ASTRO',
				'GMT',
				'EPY*',
				'SOAR',
				'EXY',
				'HOLD',
				'MNX',
				'CRDS',
				'VIU',
				'SCR',
				'DBR',
				'ABT',
				'GFT',
				'STAC',
				'QSP',
				'RIPT',
				'BBT',
				'GBX',
				'CSTL',
				'ICC',
				'JNT',
				'QASH',
				'ALQO',
				'KNC**',
				'TRIA',
				'PBL',
				'MAG',
				'STEX',
				'UFR',
				'LOCI',
				'TAU',
				'LAB',
				'DEB',
				'FLIXX',
				'FRD',
				'PFR',
				'ECA',
				'LDM',
				'LTG',
				'BCD',
				'STP',
				'SPANK',
				'WISH',
				'AERM',
				'PLX',
				'NIO',
				'ETHB',
				'CDX',
				'FOOD',
				'DRC*',
				'VOT',
				'UQC',
				'LEND',
				'SETH',
				'TIO*',
				'ABYSS',
				'XSH',
				'BCD*',
				'GEA',
				'BCO*',
				'DSR',
				'BDG',
				'ONG',
				'PRL',
				'BTCM',
				'ETBT',
				'ZCG',
				'MUT',
				'AION',
				'MEOW',
				'DIVX',
				'CNBC',
				'RHOC',
				'ARC*',
				'XUN',
				'RFL',
				'COFI',
				'ELTCOIN',
				'GRX',
				'NTK',
				'ERO',
				'CMT*',
				'RLX',
				'MAN',
				'CWV',
				'ACT*',
				'NRO',
				'SEND',
				'GLT',
				'X8X',
				'COAL',
				'DAXX',
				'BWK',
				'FNT',
				'XMRG',
				'BTCE',
				'FYP',
				'BOXY',
				'NGC',
				'UTN',
				'EGAS',
				'DPP',
				'ADB',
				'TGT',
				'XDC',
				'BMT',
				'BIO',
				'MTRC',
				'BTCL',
				'PCN',
				'PYP',
				'RBTC',
				'CRED',
				'SBTC',
				'KLK',
				'AC3',
				'GTO',
				'TNB',
				'CHIPS*',
				'HKN',
				'B2B',
				'LOC*',
				'MNT*',
				'ITNS',
				'SMT*',
				'GER',
				'LTCU',
				'EMGO',
				'BTCA',
				'HQX',
				'ETF',
				'BCX*',
				'LUX**',
				'STAK',
				'BCOIN',
				'MED*',
				'CCOS',
				'BNTY',
				'BRD',
				'HAT',
				'ELF',
				'VLR',
				'CWX',
				'DBC',
				'ZEN*',
				'POP',
				'CRC',
				'PNX',
				'BAS',
				'UTT',
				'HBC',
				'AMM',
				'DAV',
				'XCPO',
				'GET',
				'ERC20',
				'ITC',
				'HTML',
				'GENE',
				'NMS',
				'PHO',
				'XTRA',
				'HION',
				'NTWK',
				'SUCR',
				'SMART*',
				'GNX',
				'NAS',
				'ACCO',
				'BTH',
				'REM',
				'TOK',
				'EREAL',
				'CPN',
				'XFT',
				'QLC',
				'BTSE',
				'OMGC',
				'Q2C',
				'BLT',
				'SPF',
				'TDS',
				'ORE',
				'SPK',
				'GOA',
				'FLS',
				'PHILS',
				'GUN',
				'DFS',
				'POLIS',
				'WELL',
				'FLOT',
				'CL',
				'SHND',
				'AUA',
				'DNN',
				'SAGA',
				'GXS',
				'TSL',
				'IRL',
				'BOT',
				'PMA',
				'TROLL',
				'FOR',
				'SGR',
				'JET',
				'MDS',
				'LCP',
				'GTC',
				'IETH',
				'GCC*',
				'SDRN',
				'INK',
				'KBR',
				'HPB',
				'MONK',
				'JINN',
				'SET',
				'MGN',
				'KZC',
				'GNR',
				'LWF',
				'BRC',
				'WCG',
				'HIVE',
				'GX',
				'LCK',
				'MFG',
				'ETL',
				'TEL',
				'DRG',
				'BRC*',
				'SPX*',
				'ONL',
				'ZAP',
				'AIDOC',
				'ECC',
				'ET4',
				'LCT',
				'EBC',
				'VST',
				'INT',
				'CPY',
				'STN',
				'SFU',
				'PCOIN',
				'BLN',
				'LUC',
				'EDT',
				'CYDER',
				'SRNT',
				'MLT',
				'EKO',
				'UBTC',
				'BTO',
				'DOC*',
				'ARCT',
				'IMV',
				'AURA',
				'IDH',
				'CBT',
				'ITZ',
				'XBP',
				'EXRN',
				'AGI',
				'BFT',
				'LGO',
				'CRPT',
				'SGL',
				'TNC',
				'FSBT',
				'CFTY',
				'DTA',
				'CV',
				'DTX',
				'MCU',
				'OCN',
				'THETA',
				'MDT*',
				'PRPS',
				'DUBI',
				'BPT',
				'SGN',
				'IOST',
				'TCT',
				'TRAC',
				'MOT',
				'ZIL',
				'HORSE',
				'QUN',
				'QBT*',
				'ACC*',
				'SWFTC',
				'SENT',
				'IPL',
				'OPC',
				'SAF',
				'SHA',
				'PYLNT',
				'GRLC',
				'EVE',
				'YEE',
				'REPUX',
				'JOY',
				'GTC*',
				'XCD',
				'BTW',
				'AXP',
				'FOTA',
				'CPC*',
				'SPEND',
				'PXS',
				'ZPT',
				'CROAT',
				'REF',
				'SXDT',
				'SXUT',
				'LDC*',
				'FAIR*',
				'VAL',
				'MAN*',
				'BCDN',
				'STK',
				'MZX',
				'CRC**',
				'SPICE',
				'Q1S',
				'POLY*',
				'XTO',
				'RUFF',
				'ELA',
				'CXO',
				'WT',
				'HGS',
				'RCT'
			);
			$count = 0;
			if( isset( $_POST['mwb_index'] ) && !empty( $_POST['mwb_index'] ) )
			{
				$count = 30;
			}
			else
			{
				$count = 30 + $_POST['mwb_index'];
			}
			$mwb_price_arr;
			$mwb_size = sizeof($response['Data']);
			$symbol_array = array_slice($symbol_array, 0,$count);
			foreach($symbol_array as $key => $value) 
			{
				$mwb_price_arr .= $value.',';
			}
			$mwb_price_arr = trim($mwb_price_arr, ',');
			$price_res = wp_remote_get('https://min-api.cryptocompare.com/data/pricemultifull?fsyms='.$mwb_price_arr.'&tsyms='.$_POST['current_currency'], array('timeout' => 20, 'sslverify' => false));
			$coin_res = wp_remote_get('https://min-api.cryptocompare.com/data/all/coinlist', array('timeout' => 20, 'sslverify' => false));
			$exchage_res = wp_remote_get('https://coincap.io/exchange_rates', array('timeout' => 20, 'sslverify' => false));
			$exchage_res = json_decode($exchage_res['body'], true);
			$coin_res = json_decode($coin_res['body'], true);
			$price_res = json_decode($price_res['body'],true);
			$price_res['BaseImageUrl'] = $coin_res['BaseImageUrl'];
			$price_res['exchange_rates'] = $exchage_res['rates'];
			$price_res['symbols'] = $exchage_res['symbols'];
			$price_res['symbols']['USD'] = "$";
			foreach ($price_res['RAW'] as $key => $value) 
			{
				$price_res['RAW'][$key][$_POST['current_currency']]['ImageUrl'] = $coin_res['Data'][$key]['ImageUrl'];
				$price_res['RAW'][$key][$_POST['current_currency']]['FullName'] = $coin_res['Data'][$key]['FullName'];
				$price_res['DISPLAY'][$key][$_POST['current_currency']]['ImageUrl'] = $coin_res['Data'][$key]['ImageUrl'];
				$price_res['DISPLAY'][$key][$_POST['current_currency']]['FullName'] = $coin_res['Data'][$key]['FullName'];
			}
			echo json_encode($price_res);
			die();
		}
	}

	/**
	 * This function is Used to list admin setting
	 * 
	 * @since 1.0.0
	 */
	function mwb_wcw_render_table()
	{
		$pluginenable = get_option("wp_crypto_watcher_enable", false);

		if($pluginenable)
		{	
			$pluginnewsenable = get_option("wp_crypto_watcher_news_enable", false);

			wp_enqueue_style( $this->plugin_name, plugin_dir_url( __FILE__ ) . 'css/wordpress-crypto-watcher-public.css', array(), $this->version, 'all' );
			$exchage_res = wp_remote_get('https://coincap.io/exchange_rates', array('timeout' => 20, 'sslverify' => false));
			if(!is_wp_error( $exchage_res )){
				$exchage_res = json_decode($exchage_res['body'], true);	
			}else{
				return;
			}

			$cryptocurrencysymbol = get_option("wp_crypto_watcher_currency_symbol", false);

			$cryptocurrencyswitcherenable = get_option("wp_crypto_watcher_currency_switch_enable", false);

			$exchage_res = $exchage_res['symbols'];
			$exchage_res['USD'] = "$";
			ksort($exchage_res);
			$mwb_curr_html = '';



			foreach ($exchage_res as $key => $value) 
			{
				if(in_array($key, $cryptocurrencysymbol)){
					$mwb_curr_html .= '<li class="mwb_wcw_curr mwb-show" aria-hidden="true">
											<a href="javascript:void(0)" class="mwb_wcw_curr_val">'.$key.'</a>
										</li>';
				}					
			}
			$mwb_crypto_html = '<div class="mwb-cryptocurrency-table-wrapper">';

			if($cryptocurrencyswitcherenable && isset($cryptocurrencysymbol) && !empty($cryptocurrencysymbol))
			{
				$mwb_crypto_html .= '<div class="mwb_wcw_swatcher_wrap">
					<div class="mwb_wcw_curr_wrap">
						<a href="javascript:void(0)" >USD</a>
					</div>
					<div class="mwb_wcw_select_curr">
						<ul>'.$mwb_curr_html.'</ul>
					</div>
				</div>';
			}	
			$mwb_crypto_html .= '<div class="mwb-cryptocurrency">';
			if($pluginnewsenable){
				$mwb_crypto_html .= '
				<ul class="mwb-cryptocurrency__tabs">
					<li class="active" data-current="1"><a href="javascript:void(0)">'.__("Coins", "wordpress-crypto-watcher").'</a></li>
					<li data-current="2"><a href="javascript:void(0)">'.__("News", "wordpress-crypto-watcher").'</a></li>
				</ul>';
			}

			$mwb_crypto_html .= '<div class="mwb-cryptocurrency-content-tab">
								<!--mwb-cryptocurrency-table-content-->
								<div class="mwb-cryptocurrency-table-content active mwb-cryptocurrency-tab-content">
									<img class="mwb_wcw_loader" src="'.MWB_WCW_URL.'/public/images/loader.gif">
									<table class="mwb-cryptocurrency-table" style="display:none;">
										<thead>
											<tr>
												<th>#</th>
												<th>'.__("Name", "wordpress-crypto-watcher").'</th>
												<th>'.__("Price", "wordpress-crypto-watcher").'Price</th>
												<th>'.__("Change 24H", "wordpress-crypto-watcher").'</th>
												<th>'.__("Low/High 24H", "wordpress-crypto-watcher").'</th>
												<th>'.__("Direct Vol. 24H", "wordpress-crypto-watcher").'</th>
												<th>'.__("Total Vol. 24H", "wordpress-crypto-watcher").'</th>
												<th>'.__("Market Cap", "wordpress-crypto-watcher").'</th>
											</tr>
										</thead>
										<tbody>
										</tbody>
									</table>
								</div><!--mwb-cryptocurrency-table-content-->
								<!--mwb-cryptocurrency-news-wrapper-->
								<div class="mwb-cryptocurrency-news-wrapper mwb-cryptocurrency-tab-content">
									<img class="mwb_wcw_loader mwb_wcw_news_load" src="'.MWB_WCW_URL.'/public/images/loader.gif">
								</div><!--mwb-cryptocurrency-news-wrapper-->
							</div>
						</div><!--mwb-cryptocurrency-->
					</div><!--mwb-cryptocurrency-table-wrapper-->
					<!--======================
					=  mwb-cryptocurrency-GRAPH  =
					=======================-->
					<div id="mwb-main-content" style="display:none;">
						<a class="mwb_close" href="#">x</a>
						<div class="mwb-main-container-table">
							<div class="">
								<div class="mwb-row">
									<div class="mwb-coin-panel-main-wrapper mwb-clearfix">
										<div class="mwb-col mwb-left mwb-coin-panel mwb-fade">
											<div class="mwb-coin-panel__content">
												<div class="mwb-coin-panel__heading mwb-clearfix">
													<div class="mwb-left">
														<span class="mwb_btc_head">BTC - USD</span>
													</div>
													<div class="mwb-right">
														<span class="VOLUME24HOUR_BTC">
															Vol: 180,186.97
														</span>
													</div>
												</div>
												<div class="mwb-coin-panel__value">
													<span class="PRICE_BTC">
														$8324.75
													</span>
													<span class="CHANGE24HOURPCT_BTC">
														(-10.25%)
													</span>
												</div>
											</div>
										</div>
										<div class="mwb-col mwb-left mwb-coin-panel mwb-fade">
											<div class="mwb-coin-panel__content">
												<div class="mwb-coin-panel__heading mwb-clearfix">
													<div class="mwb-left">
														<span class="mwb_etc_head">ETC - USD</span>
													</div>
													<div class="mwb-right">
														<span class="VOLUME24HOUR_ETC">
															Vol: 180,186.97
														</span>
													</div>
												</div>
												<div class="mwb-coin-panel__value">
													<span class="PRICE_ETC">
														$8324.75
													</span>
													<span class="CHANGE24HOURPCT_ETC">
														(-10.25%)
													</span>
												</div>
											</div>
										</div>
										<div class="mwb-col mwb-left mwb-coin-panel mwb-fade">
											<div class="mwb-coin-panel__content">
												<div class="mwb-coin-panel__heading mwb-clearfix">
													<div class="mwb-left">
														<span class="mwb_ltc_head">LTC - USD</span>
													</div>
													<div class="mwb-right">
														<span class="VOLUME24HOUR_LTC">
															Vol: 180,186.97
														</span>
													</div>
												</div>
												<div class="mwb-coin-panel__value">
													<span class="PRICE_LTC">
														$8324.75
													</span>
													<span class="CHANGE24HOURPCT_LTC">
														(-10.25%)
													</span>
												</div>
											</div>
										</div>
										<div class="mwb-col mwb-left mwb-coin-panel mwb-fade">
											<div class="mwb-coin-panel__content">
												<div class="mwb-coin-panel__heading mwb-clearfix">
													<div class="mwb-left">
														<span class="mwb_dash_head">DASH - USD</span>
													</div>
													<div class="mwb-right">
														<span class="VOLUME24HOUR_DASH">
															Vol: 180,186.97
														</span>
													</div>
												</div>
												<div class="mwb-coin-panel__value">
													<span class="PRICE_DASH">
														$8324.75
													</span>
													<span class="CHANGE24HOURPCT_DASH">
														(-10.25%)
													</span>
												</div>
											</div>
										</div>
									</div>
									<div class="mwb-coin-dot-wrapper">
										<span class="mwb-coin-dot" onclick="currentSlide(1)"></span> 
										<span class="mwb-coin-dot" onclick="currentSlide(2)"></span> 
										<span class="mwb-coin-dot" onclick="currentSlide(3)"></span> 
										<span class="mwb-coin-dot" onclick="currentSlide(4)"></span> 
									</div>
								</div>
								<div class="mwb-row">
									<div class="mwb-col mwb-left mwb-col--logo">
										<div class="mwb-col--logo__wrapper">
											<img src="btc-logo.png" alt="stat logo image">
										</div>
									</div>
									<div class="mwb-col mwb-left mwb-col--stats-info">
										<div class="mwb-row">
											<div class="mwb-col mwb-clearfix">
												<div class="mwb-stat-price mwb-left">
													<span class="mwb_mcw_grap_price">10,159.450</span>
													<label for="" class="mwb-stat-price__refresh-time">1 min ago</label>
												</div>
												<div class="mwb-right mwb-stat-change">
													<!--<span class="mwb-stat-down__down-icon">&#x2193;</span>
													<span class="mwb-stat-up__up-icon">&#x2191;</span>-->
													<span class="mwb_mcw_grap_change">0.15</span>
													<span class="mwb_mcw_grap_change_pct">0.15</span>
												</div>
											</div>
										</div>
										<div class="mwb-row mwb-stat-infowrapper">
											<div class="mwb-col mwb-left mwb-stat-info">
												<div class="mwb-stat-info__content">
													<span class="mwb-stat-info__title">
													'.__("Market Cap", "wordpress-crypto-watcher").'
													</span>
													<span class="mwb-stat-info__prices mwb_mcw_grap_mkt_cap">
														$902,208,425.000
													</span>
												</div>
											</div>
											<div class="mwb-col mwb-left mwb-stat-info">
												<div class="mwb-stat-info__content">
													<span class="mwb-stat-info__title">
													'.__("Volume 24H", "wordpress-crypto-watcher").'
													</span>
													<span class="mwb-stat-info__prices mwb_mcw_grap_vol_24h">
														276352 BTC
													</span>
												</div>
											</div>
											<div class="mwb-col mwb-left mwb-stat-info">
												<div class="mwb-stat-info__content">
													<span class="mwb-stat-info__title">
													'.__("Open 24H", "wordpress-crypto-watcher").'
													</span>
													<span class="mwb-stat-info__prices mwb_mcw_grap_open24h">
														$9,602.940
													</span>
												</div>
											</div>
											<div class="mwb-col mwb-left mwb-stat-info">
												<div class="mwb-stat-info__content">
													<span class="mwb-stat-info__title">
													'.__("Low/High", "wordpress-crypto-watcher").'
													</span>
													<span class="mwb-stat-info__prices mwb_mcw_grap_low">
														$8,213.570</span> - <span class="mwb-stat-info__prices mwb_mcw_grap_high">
														$9,684.370 
													</span>
												</div>
											</div>
										</div>
										<!--<div class="mwb-row mwb-sell-buy-btn-wrapper">
											<div class="mwb-col mwb-left mwb-btn mwb-btn-sell">
												<a href="#">
												'.__("Buy", "wordpress-crypto-watcher").'</a>
											</div>
											<div class="mwb-col mwb-right mwb-btn mwb-btn-buy">
												<a href="#">'.__("Sell", "wordpress-crypto-watcher").'</a>
											</div>
										</div>-->
									</div>
								</div>
							</div>
							<div class=" mwb-detail-graph-wrapper">
								<div class="mwb-detail-graph-wrapper__links-wrap mwb-clearfix">
									<ul class="mwb-right">
										<li class="mwb_wcw_1d" active><a href="#">'.__("1 Day", "wordpress-crypto-watcher").' </a></li>
										<li class="mwb_wcw_1w"><a href="#">'.__("1 Week", "wordpress-crypto-watcher").'</a></li>
										<li class="mwb_wcw_1m"><a href="#">'.__("1 Month", "wordpress-crypto-watcher").'</a></li>
										<li class="mwb_wcw_3m"><a href="#">'.__("3 Months", "wordpress-crypto-watcher").'</a></li>
										<li class="mwb_wcw_6m"><a href="#">'.__("6 Months", "wordpress-crypto-watcher").'</a></li>
										<li class="mwb_wcw_1y"><a href="#">'.__("1 Year", "wordpress-crypto-watcher").'</a></li>
									</ul>
								</div>
								<img class="mwb_wcw_loader_grp" src="'.MWB_WCW_URL.'/public/images/loader.gif" style="display:none;margin: 0 auto;">
								<canvas id="myChart" width="600" height="300"></canvas>
							</div>
						</div>
					</div>
					';

			$cryptocurrencycustom_css = get_option("wp_crypto_watcher_custom_css", false);		
			
			if(isset($cryptocurrencycustom_css) && !empty($cryptocurrencycustom_css)){
				$cryptocurrencycustom_css = "<style>".$cryptocurrencycustom_css."</style>";
				$mwb_crypto_html = $cryptocurrencycustom_css.$mwb_crypto_html;
			}	
			return $mwb_crypto_html;		
		}
	}	
}
