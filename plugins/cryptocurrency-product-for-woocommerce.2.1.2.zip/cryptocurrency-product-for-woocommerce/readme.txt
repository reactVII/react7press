=== Cryptocurrency Product for WooCommerce ===
Contributors: ethereumicoio
Tags: woocommerce, ethereum, erc20, erc223, token, crypto, cryptocurrency, blockchain, ico, initial coin offering
Requires at least: 4.7
Tested up to: 4.9.7
Stable tag: 2.1.2
Donate link: https://etherscan.io/address/0x476Bb28Bc6D0e9De04dB5E19912C392F9a76535d
License: GPLv2 or later
License URI: https://www.gnu.org/licenses/gpl-2.0.html
Requires PHP: 7.0

Cryptocurrency Product for WooCommerce enables customers to buy Ether or any ERC20 or ERC223 token on your WooCommerce store for fiat, bitcoin or any other currency or cryptocurrency supported by WooCommerce.

== Description ==

Cryptocurrency Product for WooCommerce is the only one WooCommerce plugin that allows you to sell Ether or any ERC20/ERC223 token for fiat money like USD, EUR, ... or any cryptocurrency, like bitcoin, litecoin, dogecoin or any other WooCommerce supports. You can sell your ERC20 tokens for USD, EUR, or even Ether or another ERC20 token by using the [Ether and ERC20 tokens WooCommerce Payment Gateway](https://wordpress.org/plugins/ether-and-erc20-tokens-woocommerce-payment-gateway/) plugin.

> It can be a valuable addition to your ICO strategy with the [Ethereum ICO WordPress](https://wordpress.org/plugins/ethereumico/) plugin!

> The [Wordpress Ethereum Wallet](https://ethereumico.io/product/wordpress-ethereum-wallet-plugin/) plugin auto-creates a user wallet upon registration and allows user to send Ether or ERC20/ERC223 tokens from it. Using these two plugins your non-techie customers can register to obtain an Ethereum account address and then buy your tokens to be sent to this new address.

Features:

* Sell any ERC20 or ERC223 tokens for any WooCommerce supported currency. [PRO version only!](https://ethereumico.io/product/cryptocurrency-wordpress-plugin/ "The Cryptocurrency Product for WooCommerce plugin")
* Sell Ether for any WooCommerce supported currency
* Your customer can buy Ether or ERC20/ERC223 tokens just like any other product in WooCommerce
* The `Ethereum address` required input field is added to the Checkout page for all Cryptocurrency products
* Custom user meta key can be configured to fill the `Ethereum address` field automatically. With a plugin like [Ultimate Member](https://wordpress.org/plugins/ultimate-member/) you can configure your registartion form to include a required `Ethereum address` field. You can use this address on a checkout page then.
* You also can disable the `Ethereum address` field to restrict user to buy only to the address they provide you on registration.
* Friendly admin panel
* Free to use for Ether. Fixed fee per purchase
* No fee per purchase for ERC20/ERC223 tokens. [PRO version only!](https://ethereumico.io/product/cryptocurrency-wordpress-plugin/ "The Cryptocurrency Product for WooCommerce plugin")
* The minimum amount of Ether or ERC20/ERC223 tokens can be set for purchase to protect you from spam purchases
* The quantity increase/decrease step is configured per product
* The Ethereum transaction hash and link is added to the order notes to assist you in corner cases
* Stock availability is auto-managed
* Decimal product quantities can be inputted by users - you can sell 0.5 Ether for example
* The Ethereum Gas price is auto adjusted according to the [etherchain.org](https://www.etherchain.org) API
* The only one true decentralized Ether and ERC20/ERC223 WooCommerce token sell plugin. There are no service other then the Ethereum blockchain is used in this plugin. You do not need to trust us or any other party. This plugin uses a public Gateway smart contract in the Ethereum blockchain to record and confirm orders
* The Gateway smart contract: [0x3091d37ef18cb33Af72Cf7Ca63714733172cE724](https://etherscan.io/address/0x3091d37ef18cb33Af72Cf7Ca63714733172cE724#code)

== Screenshots ==

1. The ERC20/ERC223 token product in a store
2. The ERC20/ERC223 token product settings
3. The plugin settings
4. The Cryptocurrency product checkout page
5. The order details
6. Auto stock decrease
7. The stock management
8. Make a deposit
9. Wait for a deposit in progress
10. The custom user field settings

== Disclaimer ==

**By using this free plugin you accept all responsibility for handling the account balances for all your users.**

Under no circumstances is **ethereumico.io** or any of its affiliates responsible for any damages incurred by the use of this plugin.

Every effort has been made to harden the security of this plugin, but its safe operation depends on your site being secure overall. You, the site administrator, must take all necessary precautions to secure your WordPress installation before you connect it to any live wallets.

You are strongly advised to take the following actions (at a minimum):

- [Educate yourself about cold and hot cryptocurrency storage](https://en.bitcoin.it/wiki/Cold_storage)
- Obtain hardware wallet to store your coins, like [Ledger Nano S](https://www.ledgerwallet.com/r/4caf109e65ab?path=/products/ledger-nano-s), [TREZOR](https://shop.trezor.io?a=ethereumico.io) or [KeepKey](http://keepkey.go2cloud.org/aff_c?offer_id=1&aff_id=5037)
- [Educate yourself about hardening WordPress security](https://codex.wordpress.org/Hardening_WordPress)
- [Install a security plugin such as Jetpack](https://jetpack.com/pricing/?aff=9181&cid=886903) or any other security plugin
- **Enable SSL on your site** if you have not already done so.

> By continuing to use the Cryptocurrency Product for WooCommerce plugin, you indicate that you have understood and agreed to this disclaimer.

== Installation ==

* Install and activate it as you would any other plugin
* Head over to Settings » Cryptocurrency Product
* Enter your Ethereum address and private key for this address. See the Security section for security considerations
* Register for an infura.io API key and put it in admin settings. It is required to interact with Ethereum blockchain. After register you'll get a mail with links like that: https://mainnet.infura.io/1234567890. The 1234567890 part is the API Key required.
* Tune other options if you need to
* Follow steps below to prepare your system to be able to sigh Ethereum transactions


= bcmath and gmp =

`
sudo apt-get install php-bcmath php-gmp
service apache2 restart
`

For AWS bitnami AMI restart apache2 with this command:

`
sudo /opt/bitnami/ctlscript.sh restart apache
`

= Products =

Create and configure Ether and/or ERC20/ERC223 token products as you do it for any other WooCommerce products.

Check the `Cryptocurrency` checkbox near the `Virtual` and `Downloadable` checkboxes. It adds new `Cryptocurrency` tab on the left tabs panel. Use this panel to configure your product to be Ether or ERC20/ERC223 token and it's address and minimum amount value if desired.

= Deposit =

> Deposit is an amount of cryptocurrency on your wallet that you want to sell. The plugin won't sell all cryptocurrency from your wallet, but only the deposited amount. It protects you from some obvious mistakes. You always can refund your deposit. In this case there would be no cryptocurrency available for sell.

Make a deposit of Ether or ERC20/ERC223 token for your products. You need to have Ether and/or ERC20/ERC223 tokens on the Ethereum address you have entered in the plugin settings for that step. Send it from another wallet if you need to.

> You need to have some Ether amount on your wallet even if you want to sell only ERC20/ERC223 tokens. It is required to pay Ethereum transactions fees.

== Testing ==

You can test this plugin in the ropsten network for free

= Test Ether product in ropsten =

* Set the `Blockchain` setting to `ropsten`
* "Buy" some Ropsten Ether for free using [MetaMask](https://metamask.io)
* Install, configure to use `ropsten` and enable the [Ether and ERC20 tokens WooCommerce Payment Gateway](https://wordpress.org/plugins/ether-and-erc20-tokens-woocommerce-payment-gateway/) plugin
* Create an Ether type cryptocurrency product
* Make a deposit of the Ropsten Ether for that product. See Installation/Deposit section for details.
* Buy this product for free by the [Ether and ERC20 tokens WooCommerce Payment Gateway](https://wordpress.org/plugins/ether-and-erc20-tokens-woocommerce-payment-gateway/) method. Input another Ethereum wallet address on the checkout page
* Check that proper amount of Ropsten Ether has been sent to your payment address

= Test ERC20 product in ropsten =

[PRO version only!](https://ethereumico.io/product/cryptocurrency-wordpress-plugin/ "The Cryptocurrency Product for WooCommerce plugin")

* Set the `Blockchain` setting to `ropsten`
* "Buy" some Ropsten Ether for free using [MetaMask](https://metamask.io)
* Buy some `0x6Fe928d427b0E339DB6FF1c7a852dc31b651bD3a` TSX token by sending some Ropsten Ether amount to it's Crowdsale contract: `0x773F803b0393DFb7dc77e3f7a012B79CCd8A8aB9`
* Install, configure to use `ropsten` and enable the [Ether and ERC20 tokens WooCommerce Payment Gateway](https://wordpress.org/plugins/ether-and-erc20-tokens-woocommerce-payment-gateway/) plugin
* Create a ERC20 type cryptocurrency product. Set the ERC20 token address setting to the `0x6Fe928d427b0E339DB6FF1c7a852dc31b651bD3a`
* Make a deposit of the ERC20 token for that product. See Installation/Deposit section for details.
* Buy this product for free by the [Ether and ERC20 tokens WooCommerce Payment Gateway](https://wordpress.org/plugins/ether-and-erc20-tokens-woocommerce-payment-gateway/) method. Input another Ethereum wallet address on the checkout page
* Check that proper amount of TSX token has been sent to your payment address

= Test Ether product in rinkeby =

* Set the `Blockchain` setting to `rinkeby`
* You can "buy" some Rinkeby Ether for free here: [rinkeby.io](https://www.rinkeby.io/#faucet)
* Install, configure to use `rinkeby` and enable the [Ether and ERC20 tokens WooCommerce Payment Gateway](https://wordpress.org/plugins/ether-and-erc20-tokens-woocommerce-payment-gateway/) plugin
* Create an Ether type cryptocurrency product
* Make a deposit of the Rinkeby Ether for that product. See Installation/Deposit section for details.
* Buy this product for free by the [Ether and ERC20 tokens WooCommerce Payment Gateway](https://wordpress.org/plugins/ether-and-erc20-tokens-woocommerce-payment-gateway/) method. Input another Ethereum wallet address on the checkout page
* Check that proper amount of Rinkeby Ether has been sent to your payment address

= Test ERC20 product in rinkeby =

[PRO version only!](https://ethereumico.io/product/cryptocurrency-wordpress-plugin/ "The Cryptocurrency Product for WooCommerce plugin")

* Set the `Blockchain` setting to `rinkeby`
* You can "buy" some Rinkeby Ether for free here: [rinkeby.io](https://www.rinkeby.io/#faucet)
* Buy some `0x194c35B62fF011507D6aCB55B95Ad010193d303E` TSX token by sending some Rinkeby Ether amount to it's Crowdsale contract: `0x669519e1e150dfdfcf0d747d530f2abde2ab3f0e`
* Install, configure to use `rinkeby` and enable the [Ether and ERC20 tokens WooCommerce Payment Gateway](https://wordpress.org/plugins/ether-and-erc20-tokens-woocommerce-payment-gateway/) plugin
* Create a ERC20 type cryptocurrency product. Set the ERC20 token address setting to the `0x194c35B62fF011507D6aCB55B95Ad010193d303E`
* Make a deposit of the ERC20 token for that product. See Installation/Deposit section for details.
* Buy this product for free by the [Ether and ERC20 tokens WooCommerce Payment Gateway](https://wordpress.org/plugins/ether-and-erc20-tokens-woocommerce-payment-gateway/) method. Input another Ethereum wallet address on the checkout page
* Check that proper amount of TSX token has been sent to your payment address

== Fees ==

> You pay NO FEE if selling your ERC20/ERC223 tokens. Except the standard Ethereum transaction fee in gas. The typical tx gas price is 0.000260354 Ether ($0.16). So, you can limit the minimum tokens amount to buy with this plugin to be not less then 100$ in price. Then you'll pay just 16 cents in Ether for 100$ or more.

If you sell Ether, you pay a small fee for each purchase. For example, if customer buy 1 Ether, you'll spend 1.015 Ether from your deposit. Customer will get 1 Ether and the Gateway smart contract would get a 0.015 Ether fee.

The fee is [published](https://etherscan.io/address/0x3091d37ef18cb33af72cf7ca63714733172ce724#readContract "The Gateway smart contract") in a blockchain and is limited by a maxFee property in smart contract. This guaranties your safety as a plugin customer. The feePercent and maxFee values are saved as % * 10^6:

* The maxFee is 3% which is saved as 3000000 and can not be changed. 
* The feePercent is 1,5% which is saved as 1500000 and can be changed in a 0% to 3% range.

> We reserve the right to change the fee in the 0% to 3% range to reflect the market changes.

== Changelog ==

= 2.1.2 =

* Fix rounding problem for deposit amount field
* Fix disabled -> readonly for address field

= 2.1.1 =

* Check for PHP version before the `autoload.php` file inclusion to prevent errors for PHP 5.X versions

= 2.1.0 =

* The Ethereum Gas price is auto adjusted according to the [etherchain.org](https://www.etherchain.org) API
* Check for the gmp PHP module is added on the plugin activation
* js error on pages with no WordPress Ethereum Wallet plugin shortcodes is fixed
* additional protection against double send

= 2.0.2 =

* The transactions serialization queue is implemented to safely increase the nonce value on a high traffic

= 2.0.1 =

* The [0x00 nonce](https://github.com/web3p/ethereum-tx/issues/15) error is fixed
* Long wait for low gas price admin transactions is fixed: set the Gas price to be >= 11Gwei for admin transactions
* The Ether deposit now preserves at least 0.01 Ether on the wallet to pay Ethereum transaction fees

= 2.0.0 =

* Pure PHP Ethereum tx sign implementation. All glory for [Kuan-Cheng,Lai](https://github.com/sc0Vu) here. It simplifies installation procedure dramatically
* Minor fixes

= 1.1.0 =

* Custom user meta key can be configured to fill the `Ethereum address` field automatically. With a plugin like [Ultimate Member](https://ru.wordpress.org/plugins/ultimate-member/) you can configure your registartion form to include a required `Ethereum address` field. You can use this address on a checkout page then.
* You also can disable the `Ethereum address` field to restrict user to buy only to the address they provide you on registration.
* The quantity increase/decrease step is configured per product

= 1.0.0 =

* Initial public release
