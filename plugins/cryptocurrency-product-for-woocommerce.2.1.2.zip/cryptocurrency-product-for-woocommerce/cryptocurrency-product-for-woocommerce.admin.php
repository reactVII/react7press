<?php

if ( ! defined( 'ABSPATH' ) ) exit; // Exit if accessed directly

function CRYPTOCURRENCY_PRODUCT_FOR_WOOCOMMERCE_options_page() {

	// Require admin privs
	if ( ! current_user_can( 'manage_options' ) )
		return false;
	
	$new_options = array();
	
	// Which tab is selected?
	$possible_screens = array( 'default', 'floating' );
	$current_screen = ( isset( $_GET['action'] ) && in_array( $_GET['action'], $possible_screens ) ) ? $_GET['action'] : 'default';
	
	if ( isset( $_POST['Submit'] ) ) {
		
		// Nonce verification 
		check_admin_referer( 'cryptocurrency-product-for-woocommerce-update-options' );

        // Standard options screen

        $new_options['wallet_address']        = ( ! empty( $_POST['CRYPTOCURRENCY_PRODUCT_FOR_WOOCOMMERCE_wallet_address'] )       /*&& is_numeric( $_POST['CRYPTOCURRENCY_PRODUCT_FOR_WOOCOMMERCE_wallet_address'] )*/ )       ? sanitize_text_field($_POST['CRYPTOCURRENCY_PRODUCT_FOR_WOOCOMMERCE_wallet_address'])        : '';
        $new_options['gas_limit']         = ( ! empty( $_POST['CRYPTOCURRENCY_PRODUCT_FOR_WOOCOMMERCE_gas_limit'] )         && is_numeric( $_POST['CRYPTOCURRENCY_PRODUCT_FOR_WOOCOMMERCE_gas_limit'] ) )             ? intval(sanitize_text_field($_POST['CRYPTOCURRENCY_PRODUCT_FOR_WOOCOMMERCE_gas_limit']))  : 200000;
        $new_options['gas_price']             = ( ! empty( $_POST['CRYPTOCURRENCY_PRODUCT_FOR_WOOCOMMERCE_gas_price'] )             && is_numeric( $_POST['CRYPTOCURRENCY_PRODUCT_FOR_WOOCOMMERCE_gas_price'] ) )                 ? floatval(sanitize_text_field($_POST['CRYPTOCURRENCY_PRODUCT_FOR_WOOCOMMERCE_gas_price']))    : 2;
        if ( ! empty( $_POST['CRYPTOCURRENCY_PRODUCT_FOR_WOOCOMMERCE_wallet_private_key'] ) ) {
            $new_options['wallet_private_key'] = sanitize_text_field($_POST['CRYPTOCURRENCY_PRODUCT_FOR_WOOCOMMERCE_wallet_private_key']);
        }
        $new_options['blockchain_network']      = ( ! empty( $_POST['CRYPTOCURRENCY_PRODUCT_FOR_WOOCOMMERCE_blockchain_network'] )      /*&& is_numeric( $_POST['CRYPTOCURRENCY_PRODUCT_FOR_WOOCOMMERCE_blockchain_network'] )*/ )      ? sanitize_text_field($_POST['CRYPTOCURRENCY_PRODUCT_FOR_WOOCOMMERCE_blockchain_network'])       : 'mainnet';
        $new_options['infuraApiKey']     = ( ! empty( $_POST['CRYPTOCURRENCY_PRODUCT_FOR_WOOCOMMERCE_infuraApiKey'] )     /*&& is_numeric( $_POST['CRYPTOCURRENCY_PRODUCT_FOR_WOOCOMMERCE_infuraApiKey'] )*/ )     ? sanitize_text_field($_POST['CRYPTOCURRENCY_PRODUCT_FOR_WOOCOMMERCE_infuraApiKey'])      : '';

        $new_options['wallet_meta']     = ( ! empty( $_POST['CRYPTOCURRENCY_PRODUCT_FOR_WOOCOMMERCE_wallet_meta'] )     /*&& is_numeric( $_POST['CRYPTOCURRENCY_PRODUCT_FOR_WOOCOMMERCE_wallet_meta'] )*/ )     ? sanitize_text_field($_POST['CRYPTOCURRENCY_PRODUCT_FOR_WOOCOMMERCE_wallet_meta'])      : '';
        $new_options['wallet_field_disable']     = ( ! empty( $_POST['CRYPTOCURRENCY_PRODUCT_FOR_WOOCOMMERCE_wallet_field_disable'] )     /*&& is_numeric( $_POST['CRYPTOCURRENCY_PRODUCT_FOR_WOOCOMMERCE_wallet_field_disable'] )*/ )     ? 'on'      : '';

		// Get all existing Cryptocurrency Product options
		$existing_options = get_option( 'cryptocurrency-product-for-woocommerce_options', array() );
		
		// Merge $new_options into $existing_options to retain Cryptocurrency Product options from all other screens/tabs
		if ( $existing_options ) {
			$new_options = array_merge( $existing_options, $new_options );
		}
		
        if ( get_option('cryptocurrency-product-for-woocommerce_options') ) {
            update_option('cryptocurrency-product-for-woocommerce_options', $new_options);
        } else {
            $deprecated='';
            $autoload='no';
            add_option('cryptocurrency-product-for-woocommerce_options', $new_options, $deprecated, $autoload);
        }
		
		?>
		<div class="updated"><p><?php _e( 'Settings saved.' ); ?></p></div>
		<?php
		
	} else if ( isset( $_POST['Reset'] ) ) {
		// Nonce verification 
		check_admin_referer( 'cryptocurrency-product-for-woocommerce-update-options' );
		
		delete_option( 'cryptocurrency-product-for-woocommerce_options' );
	}

	$options = stripslashes_deep( get_option( 'cryptocurrency-product-for-woocommerce_options', array() ) );
	
	?>
	
	<div class="wrap">
	
	<h1><?php _e( 'Cryptocurrency Product Settings', 'cryptocurrency-product-for-woocommerce' ); ?></h1>
	
	<h2 class="nav-tab-wrapper">
		<a href="<?php echo admin_url( 'options-general.php?page=cryptocurrency-product-for-woocommerce' ); ?>" class="nav-tab<?php if ( 'default' == $current_screen ) echo ' nav-tab-active'; ?>"><?php esc_html_e( 'Standard' ); ?></a>
	</h2>

	<form id="cryptocurrency-product-for-woocommerce_admin_form" method="post" action="">
	
	<?php wp_nonce_field('cryptocurrency-product-for-woocommerce-update-options'); ?>

		<table class="form-table">
		
		<?php if ( 'default' == $current_screen ) : ?>
			<tr valign="top">
			<th scope="row"><?php _e("Ethereum wallet address", 'cryptocurrency-product-for-woocommerce'); ?></th>
			<td><fieldset>
				<label>
                    <input class="text" autocomplete="off" name="CRYPTOCURRENCY_PRODUCT_FOR_WOOCOMMERCE_wallet_address" type="text" maxlength="42" placeholder="0x0000000000000000000000000000000000000000" value="<?php echo ! empty( $options['wallet_address'] ) ? esc_attr( $options['wallet_address'] ) : ''; ?>">
                    <p><?php _e("The Ethereum address of your wallet from which you would sell Ether or ERC20 tokens.", 'cryptocurrency-product-for-woocommerce') ?></p>
                </label>
			</fieldset></td>
			</tr>
			
			<tr valign="top">
			<th scope="row"><?php _e("Ethereum wallet private key", 'cryptocurrency-product-for-woocommerce'); ?></th>
			<td><fieldset>
				<label>
                    <input class="text" autocomplete="off" name="CRYPTOCURRENCY_PRODUCT_FOR_WOOCOMMERCE_wallet_private_key" type="password" maxlength="128" value="">
                    <p><?php _e("The private key of your Ethereum wallet from which you will sell Ether or ERC20 tokens. It is kept in a secret and <strong>never</strong> sent to the client side. See plugin documentation for additional security considerations.", 'cryptocurrency-product-for-woocommerce') ?></p>
                </label>
			</fieldset></td>
			</tr>
			
			<tr valign="top">
			<th scope="row"><?php _e("Infura.io API Key", 'cryptocurrency-product-for-woocommerce'); ?></th>
			<td><fieldset>
				<label>
                    <input class="text" name="CRYPTOCURRENCY_PRODUCT_FOR_WOOCOMMERCE_infuraApiKey" type="text" maxlength="35" placeholder="<?php _e("Put your Infura.io API Key here", 'cryptocurrency-product-for-woocommerce'); ?>" value="<?php echo ! empty( $options['infuraApiKey'] ) ? esc_attr( $options['infuraApiKey'] ) : ''; ?>">
                    <p><?php echo sprintf(
                            __('The API key for the %1$s. You need to register on this site to obtain it. After register you\'ll get a mail with links like that: %2$s. Copy the %3$s part here.', 'cryptocurrency-product-for-woocommerce')
                            , '<a target="_blank" href="https://infura.io/signup">https://infura.io/</a>'
                            , 'https://mainnet.infura.io/1234567890'
                            , '<strong>1234567890</strong>'
                        )?></p>
                </label>
			</fieldset></td>
			</tr>
			
			<tr valign="top">
			<th scope="row"><?php _e("Blockchain", 'cryptocurrency-product-for-woocommerce'); ?></th>
			<td><fieldset>
				<label>
                    <input class="text" name="CRYPTOCURRENCY_PRODUCT_FOR_WOOCOMMERCE_blockchain_network" type="text" maxlength="128" placeholder="mainnet" value="<?php echo ! empty( $options['blockchain_network'] ) ? esc_attr( $options['blockchain_network'] ) : 'mainnet'; ?>">
                    <p><?php _e("The blockchain used: mainnet or ropsten. Use mainnet in production, and ropsten in test mode. See plugin documentation for the testing guide.", 'cryptocurrency-product-for-woocommerce') ?></p>
                </label>
			</fieldset></td>
			</tr>

			<tr valign="top">
			<th scope="row"><?php _e("Gas Limit", 'cryptocurrency-product-for-woocommerce'); ?></th>
			<td><fieldset>
				<label>
                    <input class="text" name="CRYPTOCURRENCY_PRODUCT_FOR_WOOCOMMERCE_gas_limit" type="number" min="0" step="10000" maxlength="8" placeholder="200000" value="<?php echo ! empty( $options['gas_limit'] ) ? esc_attr( $options['gas_limit'] ) : '200000'; ?>">
                    <p><?php _e("The default gas limit to to spen on your transactions. 200000 is a reasonable default value.", 'cryptocurrency-product-for-woocommerce') ?></p>
                </label>
			</fieldset></td>
			</tr>
			
			<tr valign="top">
			<th scope="row"><?php _e("Gas price", 'cryptocurrency-product-for-woocommerce'); ?></th>
			<td><fieldset>
				<label>
                    <input class="text" name="CRYPTOCURRENCY_PRODUCT_FOR_WOOCOMMERCE_gas_price" type="number" min="0" step="1" maxlength="8" placeholder="2" value="<?php echo ! empty( $options['gas_price'] ) ? esc_attr( $options['gas_price'] ) : '2'; ?>">
                    <p><?php _e("The gas price in Gwei. Reasonable values are in a 2-40 ratio. The default value is 2 that is cheap but not very fast. Increase if you want transactions to be mined faster, decrease if you want pay less fee per transaction.", 'cryptocurrency-product-for-woocommerce') ?></p>
                </label>
			</fieldset></td>
			</tr>

			<tr valign="top">
			<th scope="row"><?php _e("Ethereum Wallet meta key", 'cryptocurrency-product-for-woocommerce'); ?></th>
			<td><fieldset>
				<label>
                    <input class="text" name="CRYPTOCURRENCY_PRODUCT_FOR_WOOCOMMERCE_wallet_meta" type="text" value="<?php echo ! empty( $options['wallet_meta'] ) ? esc_attr( $options['wallet_meta'] ) : ''; ?>">
                    <p><?php _e("The meta key used in plugin like Ultimate Member for an Ethereum wallet address field in user registration form. It can be used here to pre-fill the Ethereum wallet field on the Checkout page.", 'cryptocurrency-product-for-woocommerce') ?></p>
                </label>
			</fieldset></td>
			</tr>

			<tr valign="top">
			<th scope="row"><?php _e("Disable Ethereum Wallet field?", 'cryptocurrency-product-for-woocommerce'); ?></th>
			<td><fieldset>
				<label>
                    <input class="checkbox" name="CRYPTOCURRENCY_PRODUCT_FOR_WOOCOMMERCE_wallet_field_disable" type="checkbox" <?php echo ! empty( $options['wallet_field_disable'] ) ? 'checked' : ''; ?> >
                    <p><?php _e("If the Ethereum Wallet meta key value is used, you can disable the Ethereum wallet field on the Checkout page. It prevents user to buy tokens to any other address except the registered one.", 'cryptocurrency-product-for-woocommerce') ?></p>
                </label>
			</fieldset></td>
			</tr>

		<?php endif; ?>
		
		</table>

		<p class="submit">
			<input class="button-primary" type="submit" name="Submit" value="<?php _e('Save Changes', 'cryptocurrency-product-for-woocommerce' ) ?>" />
			<input id="CRYPTOCURRENCY_PRODUCT_FOR_WOOCOMMERCE_reset_options" type="submit" name="Reset" onclick="return confirm('<?php _e('Are you sure you want to delete all Cryptocurrency Product options?', 'cryptocurrency-product-for-woocommerce' ) ?>')" value="<?php _e('Reset', 'cryptocurrency-product-for-woocommerce' ) ?>" />
		</p>
	
	</form>
    
    <h2><?php _e("Need help to configure this plugin?", 'cryptocurrency-product-for-woocommerce'); ?></h2>
    <p><?php echo sprintf(
        __('Feel free to %1$shire me!%2$s', 'cryptocurrency-product-for-woocommerce')
        , '<a target="_blank" href="https://www.upwork.com/freelancers/~0134e80b874bd1fa5f">'
        , '</a>'
    )?></p>

    <h2><?php _e("Need help to develop a ERC20 token for your ICO?", 'cryptocurrency-product-for-woocommerce'); ?></h2>
    <p><?php echo sprintf(
        __('Feel free to %1$shire me!%2$s', 'cryptocurrency-product-for-woocommerce')
        , '<a target="_blank" href="https://www.upwork.com/freelancers/~0134e80b874bd1fa5f">'
        , '</a>'
    )?></p>

    <h2><?php _e("Want to perform an ICO Crowdsale from your Wordpress site?", 'cryptocurrency-product-for-woocommerce'); ?></h2>
    <p><?php echo sprintf(
        __('Install the %1$sEthereum ICO WordPress plugin%2$s!', 'cryptocurrency-product-for-woocommerce')
        , '<a target="_blank" href="https://ethereumico.io/product/ethereum-ico-wordpress-plugin/">'
        , '</a>'
    )?></p>

    <h2><?php _e("Want to create Ethereum wallets on your Wordpress site?", 'cryptocurrency-product-for-woocommerce'); ?></h2>
    <p><?php echo sprintf(
        __('Install the %1$sWordPress Ethereum Wallet plugin%2$s!', 'cryptocurrency-product-for-woocommerce')
        , '<a target="_blank" href="https://ethereumico.io/product/wordpress-ethereum-wallet-plugin/">'
        , '</a>'
    )?></p>

    <h2><?php _e("Want to sell ERC20 token for fiat and/or Bitcoin?", 'cryptocurrency-product-for-woocommerce'); ?></h2>
    <p><?php echo sprintf(
        __('Install the %1$sPRO plugin version%2$s!', 'cryptocurrency-product-for-woocommerce')
        , '<a target="_blank" href="https://ethereumico.io/product/cryptocurrency-product-for-woocommerce-standard-license/">'
        , '</a>'
    )?></p>

    </div>

<?php

    // Used in Free version only
    $_ = __('In order to sell your ERC20/ERC223 tokens install the %1$sPRO plugin version%2$s please.', 'cryptocurrency-product-for-woocommerce');

}
