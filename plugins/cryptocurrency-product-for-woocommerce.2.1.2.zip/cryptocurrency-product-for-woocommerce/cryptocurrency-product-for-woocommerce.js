// https://ethereum.stackexchange.com/a/2830
// @method CRYPTOCURRENCY_PRODUCT_FOR_WOOCOMMERCE_awaitBlockConsensus
// @param txhash is the transaction hash from when you submitted the transaction
// @param blockCount is the number of blocks to wait for.
// @param timeout in seconds 
// @param callback - callback(error, transaction_receipt) 
//
function CRYPTOCURRENCY_PRODUCT_FOR_WOOCOMMERCE_awaitBlockConsensus(txhash, blockCount, timeout, transactionTime, callback) {
    var txWeb3 = window.cryptocurrency.web3;
    var startBlock = Number.MAX_SAFE_INTEGER;
    var stateEnum = { start: 1, mined: 2, awaited: 3, confirmed: 4, unconfirmed: 5 };
    var savedTxInfo;
    // the actual transaction start time
    var startTime = new Date((new Date).getTime() - transactionTime);

    var pollState = stateEnum.start;
    
    var checkTimeout = function() {
        var tm = new Date;
        if ((tm - startTime) > 1000 * timeout) {
            pollState = stateEnum.unconfirmed;
            callback(new Error("Timed out, not confirmed"), null);
            return false;
        }
        return true;
    };

    var processPollStateStart = function() {
        if (!checkTimeout()) {
            return;
        }
        txWeb3.eth.getTransaction(txhash, function(e, txInfo) {
            if (e || txInfo === null) {
                console.log(e);
                setTimeout(processPollStateStart, 1000);
                return; // XXX silently drop errors
            }
            if (txInfo.blockHash !== null) {
                startBlock = txInfo.blockNumber;
                savedTxInfo = txInfo;
                console.log("mined");
                pollState = stateEnum.mined;
                setTimeout(processPollStateMined, 1);
            } else {
                setTimeout(processPollStateStart, 1000);
            }
        });
    };
    var processPollStateMined = function() {
        if (!checkTimeout()) {
            return;
        }
        txWeb3.eth.getBlockNumber(function (e, blockNum) {
            if (e) {
                console.log(e);
                setTimeout(processPollStateMined, 1000);
                return; // XXX silently drop errors
            }
            console.log("blockNum: ", blockNum);
            if (blockNum >= (blockCount + startBlock)) {
                pollState = stateEnum.awaited;
                setTimeout(processPollStateAwaited, 1);
            } else {
                console.log("Need to wait ", (blockCount + startBlock - blockNum), " blocks");
                setTimeout(processPollStateMined, 1000);
            }
        });
    };
    var processPollStateAwaited = function() {
        if (!checkTimeout()) {
            return;
        }
        txWeb3.eth.getTransactionReceipt(txhash, function(e, receipt) {
            if (e || receipt === null) {
                if (e) {
                    console.log("getTransactionReceipt: ", e);
                }
                setTimeout(processPollStateAwaited, 1000);
                return; // XXX silently drop errors.  TBD callback error?
            }
            console.log("receipt: ", receipt);
            // confirm we didn't run out of gas
            // XXX this is where we should be checking a plurality of nodes.  TBD
            if (receipt.gasUsed >= savedTxInfo.gas) {
                pollState = stateEnum.unconfirmed;
                callback(new Error("we ran out of gas, not confirmed!"), null);
            } else {
                pollState = stateEnum.confirmed;
                callback(null, receipt);
            }
        });
    };

    processPollStateStart();
}
 
function CRYPTOCURRENCY_PRODUCT_FOR_WOOCOMMERCE_show_wait_icon() {
    jQuery('p._chk_input_cryptocurrency_refund_deposit_field').append(
        '<span id="cryptocurrency-spinner" class="spinner is-active" style="float: none;margin-top: 0;"></span>');
    jQuery('#_chk_input_cryptocurrency_make_deposit').attr('disabled', 'disabled');
    jQuery('#_chk_input_cryptocurrency_refund_deposit').attr('disabled', 'disabled');
}

function CRYPTOCURRENCY_PRODUCT_FOR_WOOCOMMERCE_hide_wait_icon() {
    jQuery('#cryptocurrency-spinner').remove();
    CRYPTOCURRENCY_PRODUCT_FOR_WOOCOMMERCE_select_cryptocurrency_option_change(function() {
        CRYPTOCURRENCY_PRODUCT_FOR_WOOCOMMERCE_enableMakeDepositCheckbox();
        CRYPTOCURRENCY_PRODUCT_FOR_WOOCOMMERCE_enableRefundDepositCheckbox();
    });
}
 
 function CRYPTOCURRENCY_PRODUCT_FOR_WOOCOMMERCE_select_cryptocurrency_option_change(cb) {
    if ('function' !== typeof cb) {
        cb = function () {};
    }
    jQuery('._text_input_cryptocurrency_balance_field').addClass('hidden');
    jQuery('._text_input_cryptocurrency_allowed_balance_field').addClass('hidden');

    jQuery( '._chk_input_cryptocurrency_make_deposit_field' ).show();
    jQuery( '._chk_input_cryptocurrency_refund_deposit_field' ).show();

    var v = jQuery( '#_select_cryptocurrency_option' ).val();
    if ('ERC20' === v) {
        // Show PRO plugin adverticement info
        jQuery('#_cryptocurrency_install_pro').removeClass('hidden');
        jQuery( '._chk_input_cryptocurrency_make_deposit_field' ).hide();
        jQuery( '._chk_input_cryptocurrency_refund_deposit_field' ).hide();
        jQuery('._text_input_cryptocurrency_minimum_value_field').addClass('hidden');
        jQuery('#_text_input_cryptocurrency_minimum_value').attr('type', 'hidden');
        jQuery('._text_input_cryptocurrency_step_field').addClass('hidden');
        jQuery('#_text_input_cryptocurrency_step').attr('type', 'hidden');
    } else {
        jQuery('#_cryptocurrency_install_pro').addClass('hidden');
        if ('Ether' === v) {
            CRYPTOCURRENCY_PRODUCT_FOR_WOOCOMMERCE_showEtherBalance(cb);
            jQuery('._text_input_cryptocurrency_minimum_value_field').removeClass('hidden');
            jQuery('#_text_input_cryptocurrency_minimum_value').attr('type', 'number');
            jQuery('._text_input_cryptocurrency_step_field').removeClass('hidden');
            jQuery('#_text_input_cryptocurrency_step').attr('type', 'number');
        } else {
            jQuery( '._chk_input_cryptocurrency_make_deposit_field' ).hide();
            jQuery( '._chk_input_cryptocurrency_refund_deposit_field' ).hide();

            jQuery('._text_input_cryptocurrency_minimum_value_field').addClass('hidden');
            jQuery('#_text_input_cryptocurrency_minimum_value').attr('type', 'hidden');
            jQuery('._text_input_cryptocurrency_step_field').addClass('hidden');
            jQuery('#_text_input_cryptocurrency_step').attr('type', 'hidden');
        }
    }
}
function CRYPTOCURRENCY_PRODUCT_FOR_WOOCOMMERCE_select_cryptocurrency_product_type() {
    var is_cryptocurrency = jQuery( '#_cryptocurrency_product_for_woocommerce_cryptocurrency_product_type' ).prop('checked');
    if (is_cryptocurrency) {
        jQuery( '.cryptocurrency_options' ).show();
    } else {
        jQuery( '.cryptocurrency_options' ).hide();
    }
}
function CRYPTOCURRENCY_PRODUCT_FOR_WOOCOMMERCE_showTokenDepositValueField() {
    var checked = jQuery('#_chk_input_cryptocurrency_make_deposit').prop('checked');
    if (checked) {
        jQuery('._text_input_cryptocurrency_make_deposit_value_field').removeClass('hidden');
        jQuery('#_text_input_cryptocurrency_make_deposit_value').attr('type', 'number');
        jQuery('#_chk_input_cryptocurrency_refund_deposit').removeProp('checked');
        jQuery('#_chk_input_cryptocurrency_refund_deposit').attr('disabled', 'disabled');
    } else {
        jQuery('._text_input_cryptocurrency_make_deposit_value_field').addClass('hidden');
        jQuery('#_text_input_cryptocurrency_make_deposit_value').attr('type', 'hidden');
        CRYPTOCURRENCY_PRODUCT_FOR_WOOCOMMERCE_enableRefundDepositCheckbox();
    }
}
function CRYPTOCURRENCY_PRODUCT_FOR_WOOCOMMERCE_processRefundDeposit() {
    var checked = jQuery('#_chk_input_cryptocurrency_refund_deposit').prop('checked');
    if (checked) {
        jQuery('#_chk_input_cryptocurrency_make_deposit').removeProp('checked');
        jQuery('#_chk_input_cryptocurrency_make_deposit').attr('disabled', 'disabled');
    } else {
        CRYPTOCURRENCY_PRODUCT_FOR_WOOCOMMERCE_enableMakeDepositCheckbox();
    }
}
function CRYPTOCURRENCY_PRODUCT_FOR_WOOCOMMERCE_enableMakeDepositCheckbox() {
    var deposit = jQuery('#_text_input_cryptocurrency_allowed_balance').val();
    var v = jQuery( '#_select_cryptocurrency_option' ).val();
    if ('Ether' === v) {
        jQuery('#_chk_input_cryptocurrency_make_deposit').removeAttr('disabled');
    }
}
function CRYPTOCURRENCY_PRODUCT_FOR_WOOCOMMERCE_enableRefundDepositCheckbox() {
        var deposit = jQuery('#_text_input_cryptocurrency_allowed_balance').val();
    if (parseFloat(deposit) > 0) {
        jQuery('#_chk_input_cryptocurrency_refund_deposit').removeAttr('disabled');
    } else {
        jQuery('#_chk_input_cryptocurrency_refund_deposit').attr('disabled', 'disabled');
    }
}
function CRYPTOCURRENCY_PRODUCT_FOR_WOOCOMMERCE_showEtherBalance(cb) {
    if ('function' !== typeof cb) {
        cb = function () {};
    }
    CRYPTOCURRENCY_PRODUCT_FOR_WOOCOMMERCE_get_ether_balance_by_account(window.cryptocurrency.walletAddress, function(err, balance) {
        if (err) {
            console.log(err); 
            cb.call(null, err, null);
            return;
        }
        console.log("Ether balance: ", balance.toNumber() / Math.pow(10, 18));
        jQuery('#_text_input_cryptocurrency_balance').val(balance.toNumber() / Math.pow(10, 18));
        jQuery('._text_input_cryptocurrency_balance_field').removeClass('hidden');

        CRYPTOCURRENCY_PRODUCT_FOR_WOOCOMMERCE_get_ether_allowed_balance_by_account(window.cryptocurrency.walletAddress, function(err, allowed) {
            if (err) {
                console.log(err); 
                cb.call(null, err, null);
                return;
            }
            console.log("Allowed Ether balance: ", allowed.toNumber() / Math.pow(10, 18));
            jQuery('#_text_input_cryptocurrency_allowed_balance').val(allowed.toNumber() / Math.pow(10, 18));
            jQuery('._text_input_cryptocurrency_allowed_balance_field').removeClass('hidden');
            
            jQuery('._chk_input_cryptocurrency_make_deposit_field').removeClass('hidden');
            jQuery('._chk_input_cryptocurrency_refund_deposit_field').removeClass('hidden');
            // keep 0.01ETH for fees
            var v = balance.toNumber() / Math.pow(10, 18) - 0.01;
            if (v < 0) {
                v = 0;
            }
            v = Math.floor(v * Math.pow(10, 12)) / Math.pow(10, 12);
            jQuery('#_text_input_cryptocurrency_make_deposit_value').val(v);
            cb.call(null, null, v);
        });
    });
}

function CRYPTOCURRENCY_PRODUCT_FOR_WOOCOMMERCE_get_gateway_contract() {
    var abi = JSON.parse(window.cryptocurrency.gatewayContractABI);
	return window.cryptocurrency.web3.eth.contract(abi).at(window.cryptocurrency.gatewayContractAddress);
}

function CRYPTOCURRENCY_PRODUCT_FOR_WOOCOMMERCE_get_ether_allowed_balance_by_account(account, callback) {
	var contract = CRYPTOCURRENCY_PRODUCT_FOR_WOOCOMMERCE_get_gateway_contract();
	if (!contract) {
		callback.call(null, "Failed to get contract", null);
		return;
	}
	contract.balances(account, callback);
}

function CRYPTOCURRENCY_PRODUCT_FOR_WOOCOMMERCE_get_ether_balance_by_account(account, callback) {
	window.cryptocurrency.web3.eth.getBalance(account, callback);
}

function CRYPTOCURRENCY_PRODUCT_FOR_WOOCOMMERCE_init() {
	if ("undefined" !== typeof window.cryptocurrency && window.cryptocurrency.initialized === true) {
        return;
    }
	if ("undefined" !== typeof window.cryptocurrency.web3Endpoint) {
		if (typeof window !== 'undefined' && typeof window.web3 !== 'undefined') {
            var injectedProvider = window.web3.currentProvider;
            window.cryptocurrency.web3metamask = new Web3(injectedProvider)
		}
        if ("undefined" !== typeof window.cryptocurrency.web3Endpoint) {
            window.cryptocurrency.web3 = new Web3(new Web3.providers.HttpProvider(window.cryptocurrency.web3Endpoint));
        }
	}
    window.cryptocurrency.initialized = true;
    jQuery('#_chk_input_cryptocurrency_make_deposit').change(CRYPTOCURRENCY_PRODUCT_FOR_WOOCOMMERCE_showTokenDepositValueField);
    jQuery('#_chk_input_cryptocurrency_refund_deposit').change(CRYPTOCURRENCY_PRODUCT_FOR_WOOCOMMERCE_processRefundDeposit);
    
    // fix chrome problem: An invalid form control with name='_text_input_cryptocurrency_make_deposit_value' is not focusable.
    jQuery('#_text_input_cryptocurrency_make_deposit_value').attr('type', 'hidden');
    
    if (jQuery('#_text_input_cryptocurrency_last_admin_txhash').length > 0) {
        var transactionHash = jQuery('#_text_input_cryptocurrency_last_admin_txhash').val();
        if ('' !== transactionHash) {
            var blockCount = 1; // TODO: add admin setting
            var timeout = 5 * 60; // 5 minutes in seconds
            var transactionTimeStr = jQuery('#_text_input_cryptocurrency_last_admin_txhash_time').val();
            // for old transactions made before this update
            // set it to expire immediately
            var transactionTime = timeout * 1000;
            if ('' !== transactionTimeStr) {
                // for new transactions count it's real time
                transactionTime = 1000 * parseInt(transactionTimeStr);
            }
            CRYPTOCURRENCY_PRODUCT_FOR_WOOCOMMERCE_show_wait_icon();
            CRYPTOCURRENCY_PRODUCT_FOR_WOOCOMMERCE_awaitBlockConsensus(transactionHash, blockCount, timeout, transactionTime, function(err, transaction_receipt) {
                CRYPTOCURRENCY_PRODUCT_FOR_WOOCOMMERCE_hide_wait_icon();
                if (err) {
                    console.log(err);
                    return;
                }
            });
        }
    }
}

jQuery(document).ready(CRYPTOCURRENCY_PRODUCT_FOR_WOOCOMMERCE_init);
// proper init if loaded by ajax
jQuery(document).ajaxComplete(function( event, xhr, settings ) {
    CRYPTOCURRENCY_PRODUCT_FOR_WOOCOMMERCE_init();
});
