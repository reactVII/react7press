<?php
/*
Plugin Name: Cryptocurrency Product for WooCommerce
Plugin URI: https://wordpress.org/plugins/cryptocurrency-product-for-woocommerce
Description: Cryptocurrency Product for WooCommerce enables customers to buy Ether or any ERC20 or ERC223 token on your WooCommerce store for fiat, bitcoin or any other currency supported by WooCommerce.
Version: 2.1.2
WC requires at least: 3.0.0
WC tested up to: 3.4
Author: ethereumicoio
Author URI: https://ethereumico.io
License: GPLv2 or later
License URI: https://www.gnu.org/licenses/gpl-2.0.html
Text Domain: cryptocurrency-product-for-woocommerce
Domain Path: /languages
*/

// Exit if accessed directly
if ( ! defined( 'ABSPATH' ) ) exit;

// Explicitly globalize to support bootstrapped WordPress
global 
	$CRYPTOCURRENCY_PRODUCT_FOR_WOOCOMMERCE_plugin_basename, 
    $CRYPTOCURRENCY_PRODUCT_FOR_WOOCOMMERCE_options, 
    $CRYPTOCURRENCY_PRODUCT_FOR_WOOCOMMERCE_plugin_dir, 
    $CRYPTOCURRENCY_PRODUCT_FOR_WOOCOMMERCE_plugin_url_path,
    $CRYPTOCURRENCY_PRODUCT_FOR_WOOCOMMERCE_gatewayContractABI;

$CRYPTOCURRENCY_PRODUCT_FOR_WOOCOMMERCE_plugin_basename = plugin_basename( dirname( __FILE__ ) );
$CRYPTOCURRENCY_PRODUCT_FOR_WOOCOMMERCE_plugin_dir = untrailingslashit( plugin_dir_path( __FILE__ ) );

$plugin_url_path = untrailingslashit( plugin_dir_url( __FILE__ ) );
// HTTPS?
$CRYPTOCURRENCY_PRODUCT_FOR_WOOCOMMERCE_plugin_url_path = is_ssl() ? str_replace( 'http:', 'https:', $plugin_url_path ) : $plugin_url_path;
// Set plugin options
$CRYPTOCURRENCY_PRODUCT_FOR_WOOCOMMERCE_options = get_option( 'cryptocurrency-product-for-woocommerce_options', array() );

/**
 * The Gateway smart contract ABI
 * 
 * @var string The Gateway smart contract ABI
 * @see http://www.webtoolkitonline.com/json-minifier.html
 */
$CRYPTOCURRENCY_PRODUCT_FOR_WOOCOMMERCE_gatewayContractABI = '[{"constant":false,"inputs":[{"name":"_sellerAddress","type":"address"},{"name":"_orderId","type":"uint256"},{"name":"_value","type":"uint256"}],"name":"payEth","outputs":[{"name":"success","type":"bool"}],"payable":false,"stateMutability":"nonpayable","type":"function"},{"constant":false,"inputs":[{"name":"_tokenAddress","type":"address"},{"name":"_sellerAddress","type":"address"},{"name":"_orderId","type":"uint256"},{"name":"_value","type":"uint256"}],"name":"payToken","outputs":[{"name":"success","type":"bool"}],"payable":false,"stateMutability":"nonpayable","type":"function"},{"constant":false,"inputs":[],"name":"refund","outputs":[],"payable":false,"stateMutability":"nonpayable","type":"function"},{"constant":false,"inputs":[{"name":"_feeAccount1","type":"address"}],"name":"setFeeAccount1","outputs":[],"payable":false,"stateMutability":"nonpayable","type":"function"},{"constant":false,"inputs":[{"name":"_feeAccount2","type":"address"}],"name":"setFeeAccount2","outputs":[],"payable":false,"stateMutability":"nonpayable","type":"function"},{"constant":false,"inputs":[{"name":"_feePercent","type":"uint256"}],"name":"setFeePercent","outputs":[],"payable":false,"stateMutability":"nonpayable","type":"function"},{"constant":false,"inputs":[],"name":"transferFee","outputs":[],"payable":false,"stateMutability":"nonpayable","type":"function"},{"constant":false,"inputs":[{"name":"newOwner","type":"address"}],"name":"transferOwnership","outputs":[],"payable":false,"stateMutability":"nonpayable","type":"function"},{"inputs":[],"payable":false,"stateMutability":"nonpayable","type":"constructor"},{"payable":true,"stateMutability":"payable","type":"fallback"},{"constant":true,"inputs":[],"name":"balanceOfEthFee","outputs":[{"name":"","type":"uint256"}],"payable":false,"stateMutability":"view","type":"function"},{"constant":true,"inputs":[{"name":"_tokenAddress","type":"address"},{"name":"_Address","type":"address"}],"name":"balanceOfToken","outputs":[{"name":"","type":"uint256"}],"payable":false,"stateMutability":"view","type":"function"},{"constant":true,"inputs":[{"name":"","type":"address"}],"name":"balances","outputs":[{"name":"","type":"uint256"}],"payable":false,"stateMutability":"view","type":"function"},{"constant":true,"inputs":[],"name":"feeAccount1","outputs":[{"name":"","type":"address"}],"payable":false,"stateMutability":"view","type":"function"},{"constant":true,"inputs":[],"name":"feeAccount2","outputs":[{"name":"","type":"address"}],"payable":false,"stateMutability":"view","type":"function"},{"constant":true,"inputs":[],"name":"feePercent","outputs":[{"name":"","type":"uint256"}],"payable":false,"stateMutability":"view","type":"function"},{"constant":true,"inputs":[],"name":"getBalanceEth","outputs":[{"name":"","type":"uint256"}],"payable":false,"stateMutability":"view","type":"function"},{"constant":true,"inputs":[{"name":"_sellerAddress","type":"address"},{"name":"_orderId","type":"uint256"}],"name":"getBuyerAddressPayment","outputs":[{"name":"","type":"address"}],"payable":false,"stateMutability":"view","type":"function"},{"constant":true,"inputs":[{"name":"_sellerAddress","type":"address"},{"name":"_orderId","type":"uint256"}],"name":"getCurrencyPayment","outputs":[{"name":"","type":"address"}],"payable":false,"stateMutability":"view","type":"function"},{"constant":true,"inputs":[{"name":"_sellerAddress","type":"address"},{"name":"_orderId","type":"uint256"}],"name":"getSellerAddressPayment","outputs":[{"name":"","type":"address"}],"payable":false,"stateMutability":"view","type":"function"},{"constant":true,"inputs":[{"name":"_sellerAddress","type":"address"},{"name":"_orderId","type":"uint256"}],"name":"getValuePayment","outputs":[{"name":"","type":"uint256"}],"payable":false,"stateMutability":"view","type":"function"},{"constant":true,"inputs":[],"name":"maxFee","outputs":[{"name":"","type":"uint256"}],"payable":false,"stateMutability":"view","type":"function"},{"constant":true,"inputs":[],"name":"owner","outputs":[{"name":"","type":"address"}],"payable":false,"stateMutability":"view","type":"function"},{"constant":true,"inputs":[{"name":"","type":"address"},{"name":"","type":"uint256"}],"name":"payment","outputs":[{"name":"buyerAddress","type":"address"},{"name":"sellerAddress","type":"address"},{"name":"value","type":"uint256"},{"name":"currency","type":"address"}],"payable":false,"stateMutability":"view","type":"function"}]';

/**
 * The ERC20 smart contract ABI
 * 
 * @var string The ERC20 smart contract ABI
 * @see http://www.webtoolkitonline.com/json-minifier.html
 */
$CRYPTOCURRENCY_PRODUCT_FOR_WOOCOMMERCE_erc20ContractABI = '[{"constant":true,"inputs":[],"name":"totalSupply","outputs":[{"name":"supply","type":"uint256"}],"payable":false,"stateMutability":"view","type":"function"},{"constant":true,"inputs":[],"name":"name","outputs":[{"name":"","type":"string"}],"payable":false,"stateMutability":"view","type":"function"},{"constant":true,"inputs":[],"name":"decimals","outputs":[{"name":"","type":"uint256"}],"payable":false,"stateMutability":"view","type":"function"},{"constant":true,"inputs":[{"name":"_owner","type":"address"}],"name":"balanceOf","outputs":[{"name":"balance","type":"uint256"}],"payable":false,"stateMutability":"view","type":"function"},{"constant":true,"inputs":[{"name":"_owner","type":"address"},{"name":"_spender","type":"address"}],"name":"allowance","outputs":[{"name":"remaining","type":"uint256"}],"payable":false,"stateMutability":"view","type":"function"},{"anonymous":false,"inputs":[{"indexed":true,"name":"_owner","type":"address"},{"indexed":true,"name":"_spender","type":"address"},{"indexed":false,"name":"_value","type":"uint256"}],"name":"Approval","type":"event"},{"anonymous":false,"inputs":[{"indexed":true,"name":"_from","type":"address"},{"indexed":true,"name":"_to","type":"address"},{"indexed":false,"name":"_value","type":"uint256"}],"name":"Transfer","type":"event"},{"constant":false,"inputs":[{"name":"_spender","type":"address"},{"name":"_value","type":"uint256"}],"name":"approve","outputs":[{"name":"success","type":"bool"}],"payable":false,"stateMutability":"nonpayable","type":"function"},{"constant":false,"inputs":[{"name":"_to","type":"address"},{"name":"_value","type":"uint256"}],"name":"transfer","outputs":[{"name":"success","type":"bool"}],"payable":false,"stateMutability":"nonpayable","type":"function"},{"constant":false,"inputs":[{"name":"_from","type":"address"},{"name":"_to","type":"address"},{"name":"_value","type":"uint256"}],"name":"transferFrom","outputs":[{"name":"success","type":"bool"}],"payable":false,"stateMutability":"nonpayable","type":"function"}]';

function CRYPTOCURRENCY_PRODUCT_FOR_WOOCOMMERCE_deactivate() {
    if ( ! current_user_can( 'activate_plugins' ) ) {
        return;
    }
    deactivate_plugins( plugin_basename( __FILE__ ) );
}

if ( version_compare( phpversion(), '7.0', '<' ) ) {
	add_action( 'admin_init', 'CRYPTOCURRENCY_PRODUCT_FOR_WOOCOMMERCE_deactivate' );
	add_action( 'admin_notices', 'CRYPTOCURRENCY_PRODUCT_FOR_WOOCOMMERCE_admin_notice' );
	function CRYPTOCURRENCY_PRODUCT_FOR_WOOCOMMERCE_admin_notice() {
		if ( ! current_user_can( 'activate_plugins' ) ) {
			return;
		}
		echo '<div class="error"><p><strong>Cryptocurrency Product for WooCommerce</strong> requires PHP version 7.0 or above.</p></div>';
		if ( isset( $_GET['activate'] ) ) {
			unset( $_GET['activate'] );
		}
	}
} else if (!function_exists('gmp_init') ) {
	add_action( 'admin_init', 'CRYPTOCURRENCY_PRODUCT_FOR_WOOCOMMERCE_deactivate' );
	add_action( 'admin_notices', 'CRYPTOCURRENCY_PRODUCT_FOR_WOOCOMMERCE_admin_notice_gmp' );
	function CRYPTOCURRENCY_PRODUCT_FOR_WOOCOMMERCE_admin_notice_gmp() {
		if ( ! current_user_can( 'activate_plugins' ) ) {
			return;
		}
		echo '<div class="error"><p><strong>Cryptocurrency Product for WooCommerce</strong> requires <a href="http://php.net/manual/en/book.gmp.php">GMP</a> module to be installed.</p></div>';
		if ( isset( $_GET['activate'] ) ) {
			unset( $_GET['activate'] );
		}
	}
} else {
    /**
     * Check if WooCommerce is active
     * https://wordpress.stackexchange.com/a/193908/137915
     **/
    if ( 
      !in_array( 
        'woocommerce/woocommerce.php', 
        apply_filters( 'active_plugins', get_option( 'active_plugins' ) ) 
      ) 
    ) {
        add_action( 'admin_init', 'CRYPTOCURRENCY_PRODUCT_FOR_WOOCOMMERCE_deactivate' );
        add_action( 'admin_notices', 'CRYPTOCURRENCY_PRODUCT_FOR_WOOCOMMERCE_admin_notice_woocommerce' );
        function CRYPTOCURRENCY_PRODUCT_FOR_WOOCOMMERCE_admin_notice_woocommerce() {
            if ( ! current_user_can( 'activate_plugins' ) ) {
                return;
            }
            echo '<div class="error"><p><strong>Cryptocurrency Product for WooCommerce</strong> requires WooCommerce plugin to be installed and activated.</p></div>';
            if ( isset( $_GET['activate'] ) ) {
                unset( $_GET['activate'] );
            }
        }
    } else {

require $CRYPTOCURRENCY_PRODUCT_FOR_WOOCOMMERCE_plugin_dir . '/vendor/autoload.php';
require_once $CRYPTOCURRENCY_PRODUCT_FOR_WOOCOMMERCE_plugin_dir . '/vendor/prospress/action-scheduler/action-scheduler.php';

function CRYPTOCURRENCY_PRODUCT_FOR_WOOCOMMERCE_product_type_options( $product_type_options ) {

    $cryptocurrency = array(
		'cryptocurrency_product_for_woocommerce_cryptocurrency_product_type' => array(
			'id' => '_cryptocurrency_product_for_woocommerce_cryptocurrency_product_type',
			'wrapper_class' => 'show_if_simple show_if_variable',
			'label' => __( 'Cryptocurrency', 'cryptocurrency-product-for-woocommerce' ),
			'description' => __( 'Make product a cryptocurrency.', 'cryptocurrency-product-for-woocommerce' ),
            'default'     => 'no',
		),
	);

	// combine the two arrays
	$product_type_options = array_merge( $cryptocurrency, $product_type_options );

	return apply_filters( 'cryptocurrency_product_for_woocommerce_product_type_options', $product_type_options );
}
add_filter( 'product_type_options', 'CRYPTOCURRENCY_PRODUCT_FOR_WOOCOMMERCE_product_type_options' );

// Function to check if a product is a cryptocurrency
function _CRYPTOCURRENCY_PRODUCT_FOR_WOOCOMMERCE_is_cryptocurrency( $product_id ) {
    $cryptocurrency = get_post_meta( $product_id, '_cryptocurrency_product_for_woocommerce_cryptocurrency_product_type', true );
    $is_cryptocurrency  = !empty( $cryptocurrency ) ? 'yes' : 'no';
    return $is_cryptocurrency === 'yes';
}

function CRYPTOCURRENCY_PRODUCT_FOR_WOOCOMMERCE_process_meta( $post_id, $post ) {
	global $wpdb, $woocommerce, $woocommerce_errors;
    $product = wc_get_product($post_id);
    if (!$product) {
        return $post_id;
    }

	if ( get_post_type( $post_id ) == 'product' ) {
        
        // check if we are called from the product settings page
        // fix from: https://stackoverflow.com/questions/5434219/problem-with-wordpress-save-post-action#comment6729746_5849143
        if (!isset($_POST['_text_input_cryptocurrency_flag'])) {
            return $post_id;
        }

		$is_cryptocurrency  = isset( $_POST['_cryptocurrency_product_for_woocommerce_cryptocurrency_product_type'] ) ? 'yes' : 'no';
		if( $is_cryptocurrency == 'yes' ) {

			update_post_meta( $post_id, '_cryptocurrency_product_for_woocommerce_cryptocurrency_product_type', $is_cryptocurrency );

//			if ( get_option( "woocommerce_enable_multiples") != "yes" ) {
//				update_post_meta( $post_id, '_sold_individually', $is_cryptocurrency );
//			}

			$want_physical = get_option( 'woocommerce_enable_physical' );

			if ( $want_physical == "no" ) {
				update_post_meta( $post_id, '_virtual', $is_cryptocurrency );
			}
            
            // 
            // Handle first save
            // 

            // Select
            $woocommerce_select = $_POST['_select_cryptocurrency_option'];
            if( !empty( $woocommerce_select ) ) {
                update_post_meta( $post_id, '_select_cryptocurrency_option', esc_attr( $woocommerce_select ) );
            } else {
                update_post_meta( $post_id, '_select_cryptocurrency_option',  '' );
            }

            if ( isset( $_POST['_text_input_cryptocurrency_minimum_value'] ) ) {
                update_post_meta( $post_id, '_text_input_cryptocurrency_minimum_value', sanitize_text_field( $_POST['_text_input_cryptocurrency_minimum_value'] ) );
            }

            if ( isset( $_POST['_text_input_cryptocurrency_step'] ) ) {
                update_post_meta( $post_id, '_text_input_cryptocurrency_step', sanitize_text_field( $_POST['_text_input_cryptocurrency_step'] ) );
            }

		} else {
			delete_post_meta( $post_id, '_cryptocurrency_product_for_woocommerce_cryptocurrency_product_type' );
		}
	}
}
add_action( 'save_post', 'CRYPTOCURRENCY_PRODUCT_FOR_WOOCOMMERCE_process_meta', 10, 2 );

/**
 * Show pricing fields for cryptocurrency product.
 */
function CRYPTOCURRENCY_PRODUCT_FOR_WOOCOMMERCE_custom_js() {

	if ( 'product' != get_post_type() ) :
		return;
	endif;

	?><script type='text/javascript'>
		jQuery( document ).ready( function() {
			jQuery( '.options_group.pricing' ).addClass( 'show_if_cryptocurrency' ).show();
			jQuery( '#_select_cryptocurrency_option' ).on( 'change', CRYPTOCURRENCY_PRODUCT_FOR_WOOCOMMERCE_select_cryptocurrency_option_change);
			jQuery( '#_cryptocurrency_product_for_woocommerce_cryptocurrency_product_type' ).on( 'change', CRYPTOCURRENCY_PRODUCT_FOR_WOOCOMMERCE_select_cryptocurrency_product_type);
            CRYPTOCURRENCY_PRODUCT_FOR_WOOCOMMERCE_select_cryptocurrency_option_change();
            CRYPTOCURRENCY_PRODUCT_FOR_WOOCOMMERCE_select_cryptocurrency_product_type();
		});

	</script><?php

}
add_action( 'admin_footer', 'CRYPTOCURRENCY_PRODUCT_FOR_WOOCOMMERCE_custom_js' );


/**
 * Add a custom product tab.
 */
function CRYPTOCURRENCY_PRODUCT_FOR_WOOCOMMERCE_custom_product_tabs( $tabs) {

	$tabs['cryptocurrency'] = array(
		'label'		=> __( 'Cryptocurrency', 'cryptocurrency-product-for-woocommerce' ),
		'target'	=> 'cryptocurrency_options',
		'class'		=> array( 'show_if_cryptocurrency', 'show_if_variable_cryptocurrency'  ),
	);

	return $tabs;

}
add_filter( 'woocommerce_product_data_tabs', 'CRYPTOCURRENCY_PRODUCT_FOR_WOOCOMMERCE_custom_product_tabs' );


/**
 * Contents of the cryptocurrency options product tab.
 */
function CRYPTOCURRENCY_PRODUCT_FOR_WOOCOMMERCE_options_product_tab_content() {

	global $post;

    $chainId = CRYPTOCURRENCY_PRODUCT_FOR_WOOCOMMERCE_getChainId();
	?><div id='cryptocurrency_options' class='panel woocommerce_options_panel'><?php

		?><div class='options_group'><?php

            // Get the selected value
            $value = get_post_meta( $post->ID, '_select_cryptocurrency_option', true );
            if( empty( $value ) ) {
                $value = '';
            }
            
            $options[''] = __( 'Select a value', 'woocommerce'); // default value
            $options['Ether'] = __( 'Ether', 'cryptocurrency-product-for-woocommerce');
            $options['ERC20'] = __( 'ERC20', 'cryptocurrency-product-for-woocommerce');
            
			woocommerce_wp_select( array(
				'id' 		=> '_select_cryptocurrency_option',
				'label' 	=> __( 'The cryptocurrency', 'cryptocurrency-product-for-woocommerce' ),
                'options' =>  $options,
                'value'   => $value,
			) );

            ?>
            <p id="_cryptocurrency_install_pro" class="hidden"><?php echo sprintf(
                    __('In order to sell your ERC20/ERC223 tokens install the %1$sPRO plugin version%2$s please.', 'cryptocurrency-product-for-woocommerce')
                    , '<a target="_blank" href="https://ethereumico.io/product/cryptocurrency-product-for-woocommerce-standard-license/">'
                    , '</a>'
                ) ?></p>
            <?php

			woocommerce_wp_text_input( array(
				'id'			=> '_text_input_cryptocurrency_minimum_value',
				'label'			=> __( 'Minimum amount', 'cryptocurrency-product-for-woocommerce' ),
				'desc_tip'		=> 'true',
				'description'	=> __( 'The minimum amount of cryptocurrency user can buy', 'cryptocurrency-product-for-woocommerce' ),
				'type' 			=> 'number',
                'wrapper_class' => 'hidden',
                'custom_attributes' => array('min' => 0, 'step' => pow(10, -12), 'novalidate' => 'novalidate'),
			) );

			woocommerce_wp_text_input( array(
				'id'			=> '_text_input_cryptocurrency_step',
				'label'			=> __( 'Step', 'cryptocurrency-product-for-woocommerce' ),
				'desc_tip'		=> 'true',
				'description'	=> __( 'The increment/decrement step', 'cryptocurrency-product-for-woocommerce' ),
				'type' 			=> 'number',
                'wrapper_class' => 'hidden',
                'custom_attributes' => array('min' => pow(10, -12), 'step' => pow(10, -12), 'novalidate' => 'novalidate'),
			) );

			woocommerce_wp_text_input( array(
				'id'			=> '_text_input_cryptocurrency_balance',
				'label'			=> __( 'Balance', 'cryptocurrency-product-for-woocommerce' ),
				'desc_tip'		=> 'true',
				'description'	=> __( 'The wallet balance', 'cryptocurrency-product-for-woocommerce' ),
				'type' 			=> 'text',
                'wrapper_class' => 'hidden',
                'custom_attributes' => array('disabled' => 'disabled')
			) );

			woocommerce_wp_text_input( array(
				'id'			=> '_text_input_cryptocurrency_allowed_balance',
				'label'			=> __( 'Balance on deposit', 'cryptocurrency-product-for-woocommerce' ),
				'desc_tip'		=> 'true',
				'description'	=> __( 'The wallet deposit available for sell', 'cryptocurrency-product-for-woocommerce' ),
				'type' 			=> 'text',
                'wrapper_class' => 'hidden',
                'custom_attributes' => array('disabled' => 'disabled')
			) );

			woocommerce_wp_checkbox( array(
				'id'			=> '_chk_input_cryptocurrency_make_deposit',
				'label'			=> __( 'Make a deposit', 'cryptocurrency-product-for-woocommerce' ),
				'desc_tip'		=> 'true',
				'description'	=> __( 'Make a deposit available for sell', 'cryptocurrency-product-for-woocommerce' ),
				'type' 			=> 'text',
                'wrapper_class' => 'hidden',
                'value'   => 'no',
//                'cbvalue'   => 'no',
			) );

			woocommerce_wp_text_input( array(
				'id'			=> '_text_input_cryptocurrency_make_deposit_value',
				'label'			=> __( 'Deposit amount', 'cryptocurrency-product-for-woocommerce' ),
				'desc_tip'		=> 'true',
				'description'	=> __( 'The amount to deposit for sell', 'cryptocurrency-product-for-woocommerce' ),
				'type' 			=> 'number',
                'wrapper_class' => 'hidden',
                'custom_attributes' => array('min' => 0, 'step' => pow(10, -12), 'novalidate' => 'novalidate'),
			) );

			woocommerce_wp_checkbox( array(
				'id'			=> '_chk_input_cryptocurrency_refund_deposit',
				'label'			=> __( 'Refund a deposit', 'cryptocurrency-product-for-woocommerce' ),
				'desc_tip'		=> 'true',
				'description'	=> __( 'Refund your deposit available for sell', 'cryptocurrency-product-for-woocommerce' ),
				'type' 			=> 'text',
                'wrapper_class' => 'hidden',
                'value'   => 'no',
//                'cbvalue'   => 'no',
			) );

            $txhash = get_post_meta( $post->ID, 'txhash' . $chainId, true );
            if( empty( $txhash ) ) {
                $txhash = '';
            }
            woocommerce_wp_hidden_input( array(
                'id'	=> '_text_input_cryptocurrency_last_admin_txhash',
                'value' => $txhash,
            ) );
            
            $txhashtime = get_post_meta( $post->ID, 'txhashtime' . $chainId, true );
            if( empty( $txhashtime ) ) {
                $txhashtime = '';
            } else {
                $txhashtime = time() - intval($txhashtime);
            }
            woocommerce_wp_hidden_input( array(
                'id'	=> '_text_input_cryptocurrency_last_admin_txhash_time',
                'value' => $txhashtime,
            ) );
            
            // fix for save_post: https://stackoverflow.com/questions/5434219/problem-with-wordpress-save-post-action#comment6729746_5849143
            woocommerce_wp_hidden_input( array(
                'id'	=> '_text_input_cryptocurrency_flag',
                'value' => 'yes',
            ) );

		?></div>

	</div><?php


}
add_action( 'woocommerce_product_data_panels', 'CRYPTOCURRENCY_PRODUCT_FOR_WOOCOMMERCE_options_product_tab_content' );


/**
 * Save the custom fields.
 */
function CRYPTOCURRENCY_PRODUCT_FOR_WOOCOMMERCE_save_option_field( $post_id ) {

    $product = wc_get_product( $post_id );
    if (!$product) {
        CRYPTOCURRENCY_PRODUCT_FOR_WOOCOMMERCE_log("save_option_field($post_id) not a product");
        return;
    }
    if ( !_CRYPTOCURRENCY_PRODUCT_FOR_WOOCOMMERCE_is_cryptocurrency( $product->get_id() ) ) {
        return;
    }
    
    // Select
    $woocommerce_select = $_POST['_select_cryptocurrency_option'];
    if( !empty( $woocommerce_select ) ) {
        update_post_meta( $post_id, '_select_cryptocurrency_option', esc_attr( $woocommerce_select ) );
    } else {
        update_post_meta( $post_id, '_select_cryptocurrency_option',  '' );
    }

	if ( isset( $_POST['_text_input_cryptocurrency_minimum_value'] ) ) {
		update_post_meta( $post_id, '_text_input_cryptocurrency_minimum_value', sanitize_text_field( $_POST['_text_input_cryptocurrency_minimum_value'] ) );
    }

	if ( isset( $_POST['_text_input_cryptocurrency_step'] ) ) {
		update_post_meta( $post_id, '_text_input_cryptocurrency_step', sanitize_text_field( $_POST['_text_input_cryptocurrency_step'] ) );
    }

    if ( isset( $_POST['_chk_input_cryptocurrency_make_deposit'] ) &&
         'yes' === $_POST['_chk_input_cryptocurrency_make_deposit'] 
    ) {
        $deposit_quantity = 0;
        if (isset( $_POST['_text_input_cryptocurrency_make_deposit_value'] )) {
            $deposit_quantity = $_POST['_text_input_cryptocurrency_make_deposit_value'];
        }
        if (__( 'Ether', 'cryptocurrency-product-for-woocommerce') == $woocommerce_select) {
            if (CRYPTOCURRENCY_PRODUCT_FOR_WOOCOMMERCE_make_ether_deposit($post_id, $deposit_quantity)) {
//                $_POST['_manage_stock'] = 'yes';
                $token_quantity_f = floatval($deposit_quantity);
//                $providerUrl = CRYPTOCURRENCY_PRODUCT_FOR_WOOCOMMERCE_getWeb3Endpoint();
//                $blockchainNetwork = CRYPTOCURRENCY_PRODUCT_FOR_WOOCOMMERCE_getBlockchainNetwork();
//                $eth_balance = CRYPTOCURRENCY_PRODUCT_FOR_WOOCOMMERCE_getBalanceEth($providerUrl, $blockchainNetwork);
//                list($eth_balance, $_) = $eth_balance->divide(new phpseclib\Math\BigInteger(pow(10, 9)));
//                $prev_stock = doubleval($eth_balance->toString()) / pow(10, 9);
//                $_POST['_stock'] = $prev_stock + $token_quantity_f;

                $status = 'outofstock';
                $minimumValue = apply_filters( 'woocommerce_quantity_input_min', 0, $product );
                if (empty($minimumValue) || 0 == $minimumValue) {
                    $minimumValue = CRYPTOCURRENCY_PRODUCT_FOR_WOOCOMMERCE_woocommerce_quantity_input_min( 0.01, $product );
                }
                if (floatval($minimumValue) < $token_quantity_f) {
                    $status = 'instock';
                }
                $_POST['_stock_status'] = $status;
            }
        }
    }
    else if ( isset( $_POST['_chk_input_cryptocurrency_refund_deposit'] ) &&
         'yes' === $_POST['_chk_input_cryptocurrency_refund_deposit']
    ) {
        if (__( 'Ether', 'cryptocurrency-product-for-woocommerce') == $woocommerce_select) {
            if (CRYPTOCURRENCY_PRODUCT_FOR_WOOCOMMERCE_refund_ether_deposit($post_id)) {
//                $_POST['_manage_stock'] = 'yes';
//                $_POST['_stock'] = 0;
                $status = 'outofstock';
                $_POST['_stock_status'] = $status;
            }
        }
    }

}
add_action( 'woocommerce_process_product_meta', 'CRYPTOCURRENCY_PRODUCT_FOR_WOOCOMMERCE_save_option_field'  );
add_action( 'woocommerce_process_product_meta_variable', 'CRYPTOCURRENCY_PRODUCT_FOR_WOOCOMMERCE_save_option_field'  );

function CRYPTOCURRENCY_PRODUCT_FOR_WOOCOMMERCE_get_default_gas_price_gwei() {
    global $CRYPTOCURRENCY_PRODUCT_FOR_WOOCOMMERCE_options;
    $gasPriceMaxGwei = doubleval(isset($CRYPTOCURRENCY_PRODUCT_FOR_WOOCOMMERCE_options['gas_price']) ? $CRYPTOCURRENCY_PRODUCT_FOR_WOOCOMMERCE_options['gas_price'] : '41');
    return array('tm' => time(), 'gas_price' => $gasPriceMaxGwei);
}
    
function CRYPTOCURRENCY_PRODUCT_FOR_WOOCOMMERCE_query_gas_price_gwei() {    
    $apiEndpoint = "https://www.etherchain.org/api/gasPriceOracle";
    $response = wp_remote_get( $apiEndpoint, array('sslverify' => false) );
    if( is_wp_error( $response ) ) {
        CRYPTOCURRENCY_PRODUCT_FOR_WOOCOMMERCE_log("Error in gasPriceOracle response: ", $response);
        return CRYPTOCURRENCY_PRODUCT_FOR_WOOCOMMERCE_get_default_gas_price_gwei();
    }
    
    $http_code = wp_remote_retrieve_response_code( $response );
    if (200 != $http_code) {
        CRYPTOCURRENCY_PRODUCT_FOR_WOOCOMMERCE_log("Bad response code in gasPriceOracle response: ", $http_code);
        return CRYPTOCURRENCY_PRODUCT_FOR_WOOCOMMERCE_get_default_gas_price_gwei();
    }
    
    $body = wp_remote_retrieve_body( $response );
    if (!$body) {
        CRYPTOCURRENCY_PRODUCT_FOR_WOOCOMMERCE_log("empty body in gasPriceOracle response");
        return CRYPTOCURRENCY_PRODUCT_FOR_WOOCOMMERCE_get_default_gas_price_gwei();
    }
    
    $j = json_decode($body, true);
    if (!isset($j["fast"])) {
        CRYPTOCURRENCY_PRODUCT_FOR_WOOCOMMERCE_log("no fast field in gasPriceOracle response");
        return CRYPTOCURRENCY_PRODUCT_FOR_WOOCOMMERCE_get_default_gas_price_gwei();
    }
    
    $gasPriceGwei = $j["fast"];
    $cache_gas_price = array('tm' => time(), 'gas_price' => $gasPriceGwei);

    if ( get_option('ethereumicoio_cache_gas_price') ) {
        update_option('ethereumicoio_cache_gas_price', $cache_gas_price);
    } else {
        $deprecated='';
        $autoload='no';
        add_option('ethereumicoio_cache_gas_price', $cache_gas_price, $deprecated, $autoload);
    }
    return $cache_gas_price;
}

function CRYPTOCURRENCY_PRODUCT_FOR_WOOCOMMERCE_get_gas_price_wei() {
    // Get all existing Cryptocurrency Product options
    $cache_gas_price_gwei = get_option( 'ethereumicoio_cache_gas_price', array() );
    if (!$cache_gas_price_gwei) {
        $cache_gas_price_gwei = CRYPTOCURRENCY_PRODUCT_FOR_WOOCOMMERCE_query_gas_price_gwei();
    }
    
    $tm_diff = time() - intval($cache_gas_price_gwei['tm']);
    // TODO: admin setting
    $timeout = 10 * 60; // seconds
    if ($tm_diff > $timeout) {
        $cache_gas_price_gwei = CRYPTOCURRENCY_PRODUCT_FOR_WOOCOMMERCE_query_gas_price_gwei();
    }
    
    $gasPriceGwei = doubleval($cache_gas_price_gwei['gas_price']);
    $gasPriceMaxGwei = doubleval(CRYPTOCURRENCY_PRODUCT_FOR_WOOCOMMERCE_get_default_gas_price_gwei()['gas_price']);
    
    if ($gasPriceMaxGwei < $gasPriceGwei) {
        $gasPriceGwei = $gasPriceMaxGwei;
    }
    $gasPriceWei = 1000000000 * $gasPriceGwei; // gwei -> wei
    return intval($gasPriceWei);
}

function CRYPTOCURRENCY_PRODUCT_FOR_WOOCOMMERCE_make_ether_deposit($post_id, $ether_quantity) {
    global $CRYPTOCURRENCY_PRODUCT_FOR_WOOCOMMERCE_options;
    
    $chainId = CRYPTOCURRENCY_PRODUCT_FOR_WOOCOMMERCE_getChainId();
    if (null === $chainId) {
        WC_Admin_Meta_Boxes::add_error( __( 'Configuration error. Last action was not completed.', 'cryptocurrency-product-for-woocommerce' ) );
        return false;
    }
    $blockchainNetwork = CRYPTOCURRENCY_PRODUCT_FOR_WOOCOMMERCE_getBlockchainNetwork();
    // 1. get token decimals, calc qty in wei
    $providerUrl = CRYPTOCURRENCY_PRODUCT_FOR_WOOCOMMERCE_getWeb3Endpoint();
    
    $ether_quantity_wei = _CRYPTOCURRENCY_PRODUCT_FOR_WOOCOMMERCE_double_int_multiply($ether_quantity, pow(10, 18));
    
    // 2. check allowance
    $thisWalletAddress = esc_attr($CRYPTOCURRENCY_PRODUCT_FOR_WOOCOMMERCE_options['wallet_address']);
    // 4. call approve
    $requestManager = new \Web3\RequestManagers\HttpRequestManager($providerUrl, 10/* seconds */);
    $web3 = new \Web3\Web3(new \Web3\Providers\HttpProvider($requestManager));
    $eth = $web3->eth;

    // correct deposit sum to be able to pay Ethereum fees
    $eth->getBalance($thisWalletAddress, function ($err, $balance) use(&$ether_quantity_wei) {
        if ($err !== null) {
            CRYPTOCURRENCY_PRODUCT_FOR_WOOCOMMERCE_log("Failed to getBalance: " . $err);
            return;
        }
        $min_ether_quantity_wei = _CRYPTOCURRENCY_PRODUCT_FOR_WOOCOMMERCE_double_int_multiply(0.01, pow(10, 18));
        $sum = $ether_quantity_wei->add($min_ether_quantity_wei);
        if ($balance->compare($sum) < 0) {
            $ether_quantity_wei = $balance->subtract($min_ether_quantity_wei);
        }
    });
    $ether_quantity_wei_str = $ether_quantity_wei->toString();

    $nonce = CRYPTOCURRENCY_PRODUCT_FOR_WOOCOMMERCE_get_nonce($thisWalletAddress, $providerUrl, $eth);
    if (null === $nonce) {
        WC_Admin_Meta_Boxes::add_error( __( 'Network problems detected. Last action was not completed.', 'cryptocurrency-product-for-woocommerce' ) );
        return false;
    }
    $gasLimit = intval(CRYPTOCURRENCY_PRODUCT_FOR_WOOCOMMERCE_get_payToken_gas('', 0, $providerUrl, $blockchainNetwork, '', $ether_quantity_wei_str));
    $gasPrice = CRYPTOCURRENCY_PRODUCT_FOR_WOOCOMMERCE_get_gas_price_wei();

    $thisWalletPrivKey = esc_attr($CRYPTOCURRENCY_PRODUCT_FOR_WOOCOMMERCE_options['wallet_private_key']);
    
    $contractAddress = CRYPTOCURRENCY_PRODUCT_FOR_WOOCOMMERCE_getGatewayContractAddress($blockchainNetwork);
    $to = $contractAddress;
    $nonce = \BitWasp\Buffertools\Buffer::int($nonce);
    $gasPrice = \BitWasp\Buffertools\Buffer::int($gasPrice);
    $gasLimit = \BitWasp\Buffertools\Buffer::int($gasLimit);
    $value = \BitWasp\Buffertools\Buffer::int($ether_quantity_wei_str);

    $transaction = new \Web3p\EthereumTx\Transaction([
        'nonce' => '0x' . $nonce->getHex(),
        'to' => strtolower($to),
        'gas' => '0x' . $gasLimit->getHex(),
        'gasPrice' => '0x' . $gasPrice->getHex(),
        'value' => '0x' . $value->getHex(),
        'chainId' => $chainId,
        'data' => ''
    ]);
    $signedTransaction = "0x" . $transaction->sign($thisWalletPrivKey);

    $txHash = null;
    $eth->sendRawTransaction((string)$signedTransaction, function ($err, $transaction) use(&$txHash) {
        if ($err !== null) {
            CRYPTOCURRENCY_PRODUCT_FOR_WOOCOMMERCE_log("Failed to sendRawTransaction: " . $err);
            return;
        }
        $txHash = $transaction;
    });
    
    if (null === $txHash) {
        CRYPTOCURRENCY_PRODUCT_FOR_WOOCOMMERCE_log("txHash is null");
        WC_Admin_Meta_Boxes::add_error( __( 'Network problems detected. Last action was not completed.', 'cryptocurrency-product-for-woocommerce' ) );
        return false;
    }
    
    update_post_meta( $post_id, 'txhash' . $chainId, sanitize_text_field( $txHash ) );
    update_post_meta( $post_id, 'txhashtime' . $chainId, time() );

    return true;
}

/**
 * Hide Attributes data panel.
 */
function CRYPTOCURRENCY_PRODUCT_FOR_WOOCOMMERCE_hide_attributes_data_panel( $tabs) {

	$tabs['shipping']['class'][] = 'hide_if_cryptocurrency';
	$tabs['shipping']['class'][] = 'hide_if_variable_cryptocurrency';

	return $tabs;

}
add_filter( 'woocommerce_product_data_tabs', 'CRYPTOCURRENCY_PRODUCT_FOR_WOOCOMMERCE_hide_attributes_data_panel' );

//----------------------------------------------------------------------------//
//                     Shipping field for crypto-address                      //
//----------------------------------------------------------------------------//

// Hook in
add_filter( 'woocommerce_checkout_fields' , 'CRYPTOCURRENCY_PRODUCT_FOR_WOOCOMMERCE_override_checkout_fields' );

function _CRYPTOCURRENCY_PRODUCT_FOR_WOOCOMMERCE_is_cryptocurrency_product_in_cart() {
	// Find each product in the cart and add it to the $cart_ids array
	foreach( WC()->cart->get_cart() as $cart_item_key => $product ) {
        if (_CRYPTOCURRENCY_PRODUCT_FOR_WOOCOMMERCE_is_cryptocurrency($product['product_id'])) {
            return true;
        }
	}
    return false;
}
// Our hooked in function - $fields is passed via the filter!
function CRYPTOCURRENCY_PRODUCT_FOR_WOOCOMMERCE_override_checkout_fields( $fields ) {
    global $CRYPTOCURRENCY_PRODUCT_FOR_WOOCOMMERCE_options;
    if (_CRYPTOCURRENCY_PRODUCT_FOR_WOOCOMMERCE_is_cryptocurrency_product_in_cart()) {
        $value = CRYPTOCURRENCY_PRODUCT_FOR_WOOCOMMERCE_get_user_wallet();

        $custom_attributes = array();
        $walletDisabled = esc_attr($CRYPTOCURRENCY_PRODUCT_FOR_WOOCOMMERCE_options['wallet_field_disable']);
        if (!empty($walletDisabled)) {
            $custom_attributes['readonly'] = 'readonly';
        }
        ?>
    <script type='text/javascript'>
		jQuery( document ).ready( function() {
			setTimeout(function(){jQuery('#billing_cryptocurrency_ethereum_address').val("<?php echo $value; ?>");}, 100);
		});
	</script>
        <?php
        $fields['billing']['billing_cryptocurrency_ethereum_address'] = array(
            'label'             => __('Ethereum Address', 'cryptocurrency-product-for-woocommerce'),
            'placeholder'       => _x('0x', 'placeholder', 'cryptocurrency-product-for-woocommerce'),
            'required'          => true,
            'class'             => array('form-row-wide'),
            'clear'             => true,
            'value'             => $value,
            'custom_attributes' => $custom_attributes
        );
    }

     return $fields;
}

/**
 * Display field value on the order edit page
 */
 
//add_action( 'woocommerce_admin_order_data_after_billing_address', 'CRYPTOCURRENCY_PRODUCT_FOR_WOOCOMMERCE_checkout_field_display_admin_order_meta', 10, 1 );
//
//function CRYPTOCURRENCY_PRODUCT_FOR_WOOCOMMERCE_checkout_field_display_admin_order_meta($order){
//    echo '<p><strong>'.__('Ethereum Address From Checkout Form', 'cryptocurrency-product-for-woocommerce').':</strong> ' . get_post_meta( $order->get_id(), '_billing_cryptocurrency_ethereum_address', true ) . '</p>';
//}

/* Display additional billing fields (email, phone) in ADMIN area (i.e. Order display ) */
/* Note:  $fields keys (i.e. field names) must be in format:  WITHOUT the "billing_" prefix (it's added by the code) */
add_filter( 'woocommerce_admin_billing_fields' , 'CRYPTOCURRENCY_PRODUCT_FOR_WOOCOMMERCE_additional_admin_billing_fields' );
function CRYPTOCURRENCY_PRODUCT_FOR_WOOCOMMERCE_additional_admin_billing_fields( $fields ) {
    $fields['cryptocurrency_ethereum_address'] = array(
        'label'     => __('Ethereum Address', 'cryptocurrency-product-for-woocommerce'),
    );
    return $fields;
}
/* Display additional billing fields (email, phone) in USER area (i.e. Admin User/Customer display ) */
/* Note:  $fields keys (i.e. field names) must be in format: billing_ */
add_filter( 'woocommerce_customer_meta_fields' , 'CRYPTOCURRENCY_PRODUCT_FOR_WOOCOMMERCE_additional_customer_meta_fields' );
function CRYPTOCURRENCY_PRODUCT_FOR_WOOCOMMERCE_additional_customer_meta_fields( $fields ) {
    $fields['billing']['fields']['billing_cryptocurrency_ethereum_address'] = array(
        'label'     => __('Ethereum Address', 'cryptocurrency-product-for-woocommerce'),
        'description' => '',
    );
    return $fields;
}
/* Add CSS for ADMIN area so that the additional billing fields (email, phone) display on left and right side of edit billing details */
//add_action('admin_head', 'CRYPTOCURRENCY_PRODUCT_FOR_WOOCOMMERCE_custom_admin_css');
//function CRYPTOCURRENCY_PRODUCT_FOR_WOOCOMMERCE_custom_admin_css() {
//  echo '<style>
//    #order_data .order_data_column ._billing_email2_field {
//        clear: left;
//        float: left;
//    }
//    #order_data .order_data_column ._billing_phone_field {
//        float: right;
//    }
//  </style>';
//}


//----------------------------------------------------------------------------//
//                     Process order status changes                           //
//----------------------------------------------------------------------------//


function CRYPTOCURRENCY_PRODUCT_FOR_WOOCOMMERCE_order_processing($order_id) {
    CRYPTOCURRENCY_PRODUCT_FOR_WOOCOMMERCE_process_order($order_id);
}
add_action( 'woocommerce_order_status_processing', 'CRYPTOCURRENCY_PRODUCT_FOR_WOOCOMMERCE_order_processing');

function CRYPTOCURRENCY_PRODUCT_FOR_WOOCOMMERCE_order_completed($order_id) {
    CRYPTOCURRENCY_PRODUCT_FOR_WOOCOMMERCE_process_order($order_id);
}
add_action( 'woocommerce_order_status_completed', 'CRYPTOCURRENCY_PRODUCT_FOR_WOOCOMMERCE_order_completed');


function _CRYPTOCURRENCY_PRODUCT_FOR_WOOCOMMERCE_double_int_multiply($dval, $ival) {
    $dval = doubleval($dval);
    $ival = intval($ival);
    $dv1 = floor($dval);
    $ret = new phpseclib\Math\BigInteger(intval($dv1));
    $ret = $ret->multiply(new phpseclib\Math\BigInteger($ival));
    if ($dv1 === $dval) {
        return $ret;
    }
    $dv2 = $dval - $dv1;
    $iv1 = intval($dv2 * $ival);
    $ret = $ret->add(new phpseclib\Math\BigInteger($iv1));
    return $ret;
}

add_action("CRYPTOCURRENCY_PRODUCT_FOR_WOOCOMMERCE_send_ether", "CRYPTOCURRENCY_PRODUCT_FOR_WOOCOMMERCE_send_ether", 0, 5);

function CRYPTOCURRENCY_PRODUCT_FOR_WOOCOMMERCE_send_ether($order_id, $product_id, $marketAddress, $eth_value, $providerUrl) {
    global $CRYPTOCURRENCY_PRODUCT_FOR_WOOCOMMERCE_options;
    
    $blockchainNetwork = CRYPTOCURRENCY_PRODUCT_FOR_WOOCOMMERCE_getBlockchainNetwork();
    $paymentInfo = CRYPTOCURRENCY_PRODUCT_FOR_WOOCOMMERCE_getPaymentInfo($order_id, $providerUrl, $blockchainNetwork, $marketAddress);
    if ($paymentInfo) {
        // already payed
        CRYPTOCURRENCY_PRODUCT_FOR_WOOCOMMERCE_log("Payment found for order $order_id. Skip payment.");
        return;
    }

    // проверить, есть ли прошлая транзакция
    $thisWalletAddress = esc_attr($CRYPTOCURRENCY_PRODUCT_FOR_WOOCOMMERCE_options['wallet_address']);
    $lasttxhash = CRYPTOCURRENCY_PRODUCT_FOR_WOOCOMMERCE_get_last_txhash($thisWalletAddress);
    $txhash = null;
    $nonce = null;
    if ($lasttxhash) {
        // если есть, проверить, завершена ли она
        $lastnonce = CRYPTOCURRENCY_PRODUCT_FOR_WOOCOMMERCE_get_last_nonce($thisWalletAddress);
        $tx_confirmed = CRYPTOCURRENCY_PRODUCT_FOR_WOOCOMMERCE_is_tx_confirmed($lasttxhash, $lastnonce, $providerUrl);
        if ($tx_confirmed) {
            //   - да, послать новую транзакцию
            list($txhash, $nonce) = CRYPTOCURRENCY_PRODUCT_FOR_WOOCOMMERCE_send_ether_impl($order_id, $product_id, $marketAddress, $eth_value, $providerUrl);
        } else if (is_null($tx_confirmed)) {
            // nonce in last tx is outdated. remove it
            CRYPTOCURRENCY_PRODUCT_FOR_WOOCOMMERCE_delete_last_txhash($thisWalletAddress);
//            CRYPTOCURRENCY_PRODUCT_FOR_WOOCOMMERCE_cancel_complete_order_task($order_id, $txhash, $nonce);
        }
    } else {
        // нет последней транзакции. послать новую транзакцию
        list($txhash, $nonce) = CRYPTOCURRENCY_PRODUCT_FOR_WOOCOMMERCE_send_ether_impl($order_id, $product_id, $marketAddress, $eth_value, $providerUrl);
    }
    
    if ($txhash) {
        // успех - запомнить новую последнюю транзакцию
        CRYPTOCURRENCY_PRODUCT_FOR_WOOCOMMERCE_set_last_txhash($thisWalletAddress, $txhash, $nonce);
        // поставить задачу отслеживания состояния транзакции
        CRYPTOCURRENCY_PRODUCT_FOR_WOOCOMMERCE_enqueue_complete_order_task($order_id, $txhash, $nonce);
    } else {
        // Неуспех - поставить себя снова в очередь
        CRYPTOCURRENCY_PRODUCT_FOR_WOOCOMMERCE_enqueue_send_ether_task($order_id, $product_id, $marketAddress, $eth_value, $providerUrl);
    }

    return true;
}

function CRYPTOCURRENCY_PRODUCT_FOR_WOOCOMMERCE_send_ether_impl($order_id, $product_id, $marketAddress, $eth_value, $providerUrl) {
    global $CRYPTOCURRENCY_PRODUCT_FOR_WOOCOMMERCE_options;
    
    $chainId = CRYPTOCURRENCY_PRODUCT_FOR_WOOCOMMERCE_getChainId();
    if (null === $chainId) {
        return null;
    }
    
    $blockchainNetwork = CRYPTOCURRENCY_PRODUCT_FOR_WOOCOMMERCE_getBlockchainNetwork();
    $feePercent = CRYPTOCURRENCY_PRODUCT_FOR_WOOCOMMERCE_getFeePercent($providerUrl, $blockchainNetwork);
    if (null === $feePercent) {
        CRYPTOCURRENCY_PRODUCT_FOR_WOOCOMMERCE_log("feePercent is null");
        update_post_meta( $order_id, 'status', __('Network error', 'cryptocurrency-product-for-woocommerce') );
        return null;
    }
    $feePercent = intval($feePercent->toString());
    
    $eth_value_wei0 = _CRYPTOCURRENCY_PRODUCT_FOR_WOOCOMMERCE_double_int_multiply($eth_value, pow(10, 18));
    $eth_value_wei = $eth_value_wei0->multiply(new phpseclib\Math\BigInteger(100000000));
    list($eth_value_wei, $_) = $eth_value_wei->divide(new phpseclib\Math\BigInteger(100000000 - $feePercent));
    $eth_value_wei_str = $eth_value_wei->toString();
    
    // 1. check deposit
    $eth_balance = CRYPTOCURRENCY_PRODUCT_FOR_WOOCOMMERCE_getBalanceEth($providerUrl, $blockchainNetwork);
    if (null === $eth_balance) {
        CRYPTOCURRENCY_PRODUCT_FOR_WOOCOMMERCE_log("eth_balance is null");
        update_post_meta( $order_id, 'status', __('Network error', 'cryptocurrency-product-for-woocommerce') );
        return null;
    }
    if ($eth_balance->compare($eth_value_wei) < 0) {
        $eth_balance_str = $eth_balance->toString();
        CRYPTOCURRENCY_PRODUCT_FOR_WOOCOMMERCE_log("eth_balance_wei($eth_balance_str) < eth_value_wei($eth_value_wei_str)");
        update_post_meta( $order_id, 'status', __('Insufficient funds', 'cryptocurrency-product-for-woocommerce') );
        return null;
    }
    // 2. make deposit if needed
    // 3. make payment if deposit is enough
    $requestManager = new \Web3\RequestManagers\HttpRequestManager($providerUrl, 10/* seconds */);
    $web3 = new \Web3\Web3(new \Web3\Providers\HttpProvider($requestManager));
    $eth = $web3->eth;
    $thisWalletAddress = esc_attr($CRYPTOCURRENCY_PRODUCT_FOR_WOOCOMMERCE_options['wallet_address']);
    $nonce = CRYPTOCURRENCY_PRODUCT_FOR_WOOCOMMERCE_get_nonce($thisWalletAddress, $providerUrl, $eth);
    if (null === $nonce) {
        update_post_meta( $order_id, 'status', __('Network error', 'cryptocurrency-product-for-woocommerce') );
        return null;
    }
    $data = CRYPTOCURRENCY_PRODUCT_FOR_WOOCOMMERCE_get_payEth_data($order_id, $providerUrl, $blockchainNetwork, $marketAddress, $eth_value_wei_str);
    $gasLimit = intval(CRYPTOCURRENCY_PRODUCT_FOR_WOOCOMMERCE_get_payEth_gas($order_id, $providerUrl, $blockchainNetwork, $marketAddress, $eth_value_wei_str));
    $gasPrice = CRYPTOCURRENCY_PRODUCT_FOR_WOOCOMMERCE_get_gas_price_wei();

    $thisWalletPrivKey = esc_attr($CRYPTOCURRENCY_PRODUCT_FOR_WOOCOMMERCE_options['wallet_private_key']);
    $contractAddress = CRYPTOCURRENCY_PRODUCT_FOR_WOOCOMMERCE_getGatewayContractAddress($blockchainNetwork);

    $to = $contractAddress;
    $nonceb = \BitWasp\Buffertools\Buffer::int($nonce);
    $gasPrice = \BitWasp\Buffertools\Buffer::int($gasPrice);
    $gasLimit = \BitWasp\Buffertools\Buffer::int($gasLimit);

    $transaction = new \Web3p\EthereumTx\Transaction([
        'nonce' => '0x' . $nonceb->getHex(),
        'to' => strtolower($to),
        'gas' => '0x' . $gasLimit->getHex(),
        'gasPrice' => '0x' . $gasPrice->getHex(),
        'value' => '0x0',
        'chainId' => $chainId,
        'data' => '0x' . $data
    ]);
    $signedTransaction = "0x" . $transaction->sign($thisWalletPrivKey);

    $txHash = null;
    $eth->sendRawTransaction((string)$signedTransaction, function ($err, $transaction) use(&$txHash) {
        if ($err !== null) {
            CRYPTOCURRENCY_PRODUCT_FOR_WOOCOMMERCE_log("Failed to sendRawTransaction: " . $err);
            return;
        }
        $txHash = $transaction;
    });
    
    if (null === $txHash) {
        update_post_meta( $order_id, 'status', __('Network error', 'cryptocurrency-product-for-woocommerce') );
        return null;
    }
    CRYPTOCURRENCY_PRODUCT_FOR_WOOCOMMERCE_set_order_txhash($order_id, $txHash, $blockchainNetwork);
    update_post_meta( $order_id, 'txdata', sanitize_text_field( $signedTransaction ) );

    // the remaining balance
    $eth_balance_remaining = $eth_balance->subtract($eth_value_wei);
    list($eth_balance_remaining, $_) = $eth_balance_remaining->divide(new phpseclib\Math\BigInteger(pow(10, 9)));
    $eth_balance_f = doubleval($eth_balance_remaining->toString()) / pow(10, 9);

    $product = wc_get_product($product_id);
    if (!$product) {
        CRYPTOCURRENCY_PRODUCT_FOR_WOOCOMMERCE_log("send_ether($product_id) not a product");
        return null;
    }
    $minimumValue = apply_filters( 'woocommerce_quantity_input_min', 0, $product );
    if (empty($minimumValue) || 0 == $minimumValue) {
        $minimumValue = CRYPTOCURRENCY_PRODUCT_FOR_WOOCOMMERCE_woocommerce_quantity_input_min( 0.01, $product );
    }
    $status = 'outofstock';
    if (doubleval($minimumValue) < $eth_balance_f) {
        $status = 'instock';
    }
    wc_update_product_stock_status( $product_id, $status );
//    // adjust stock quantity for fee
//    list($eth_value_diff_wei, $_) = $eth_value_diff_wei->divide(new phpseclib\Math\BigInteger(pow(10, 9)));
//    $eth_value_f = floatval(doubleval($eth_value_diff_wei->toString()) / pow(10, 9));
//    // the fee amount to decrease stock
//    $eth_value_diff_wei = $eth_value_wei->subtract($eth_value_wei0);
//    // adjust stock quantity for fee
//    list($eth_value_diff_wei, $_) = $eth_value_diff_wei->divide(new phpseclib\Math\BigInteger(pow(10, 9)));
//    $eth_value_f = floatval(doubleval($eth_value_diff_wei->toString()) / pow(10, 9));
//    wc_update_product_stock( $product, $eth_value_f, 'decrease');
    update_post_meta( $order_id, 'status', __('Success', 'cryptocurrency-product-for-woocommerce') );
    
    return array($txHash, $nonce);
}

function CRYPTOCURRENCY_PRODUCT_FOR_WOOCOMMERCE_set_order_txhash($order_id, $txHash, $blockchainNetwork) {
    $txHashPath = '';
    switch ($blockchainNetwork) {
        case 'mainnet':
            $txHashPath = 'https://etherscan.io/tx/' . $txHash;
            break;
        case 'ropsten':
            $txHashPath = 'https://ropsten.etherscan.io/tx/' . $txHash;
            break;
        case 'rinkeby':
            $txHashPath = 'https://rinkeby.etherscan.io/tx/' . $txHash;
            break;
        default:
            break;
    }
    $order = new WC_Order($order_id);
    $order->add_order_note(
        sprintf(
            __('Sent to blockchain. Transaction hash <a href="%1$s">%2$s</a>.', 'cryptocurrency-product-for-woocommerce')
            , $txHashPath
            , $txHash
        )
    );
    update_post_meta( $order_id, 'txhash', sanitize_text_field( $txHash ) );
}

// TODO: wait for a configured number of blocks
function CRYPTOCURRENCY_PRODUCT_FOR_WOOCOMMERCE_is_tx_confirmed($txhash, $lastnonce, $providerUrl) {
    global $CRYPTOCURRENCY_PRODUCT_FOR_WOOCOMMERCE_options;

    $requestManager = new \Web3\RequestManagers\HttpRequestManager($providerUrl, 10/* seconds */);
    $web3 = new \Web3\Web3(new \Web3\Providers\HttpProvider($requestManager));
    $eth = $web3->eth;
    $is_confirmed = false;
    $thisWalletAddress = esc_attr($CRYPTOCURRENCY_PRODUCT_FOR_WOOCOMMERCE_options['wallet_address']);
    $eth->getTransactionByHash($txhash, function ($err, $transaction) use(&$is_confirmed, $lastnonce, $thisWalletAddress, $providerUrl) {
        if ($err !== null) {
            CRYPTOCURRENCY_PRODUCT_FOR_WOOCOMMERCE_log("Failed to getTransactionByHash: " . $err);
            $nonce = CRYPTOCURRENCY_PRODUCT_FOR_WOOCOMMERCE_get_nonce($thisWalletAddress, $providerUrl);
            if (!is_null($nonce) && intval($lastnonce) < intval($nonce)) {
                // tx outdated flag
                $is_confirmed = null;
                CRYPTOCURRENCY_PRODUCT_FOR_WOOCOMMERCE_log("tx nonce($lastnonce) less then address nonce($nonce)");
            }
            return;
        }
        CRYPTOCURRENCY_PRODUCT_FOR_WOOCOMMERCE_log("transaction: " . print_r($transaction, true));
        $is_confirmed = property_exists($transaction, "blockHash") && !empty($transaction->blockHash);
    });
    CRYPTOCURRENCY_PRODUCT_FOR_WOOCOMMERCE_log("is_confirmed: " . $is_confirmed);
    return $is_confirmed;
}

function CRYPTOCURRENCY_PRODUCT_FOR_WOOCOMMERCE_get_last_txhash($thisWalletAddress) {
    $option = $thisWalletAddress . "-cryptocurrency-product-for-woocommerce-queue-txhash";
    $txhash = get_option($option);
    return $txhash;
}

function CRYPTOCURRENCY_PRODUCT_FOR_WOOCOMMERCE_get_last_nonce($thisWalletAddress) {
    $option = $thisWalletAddress . "-cryptocurrency-product-for-woocommerce-queue-nonce";
    $nonce = get_option($option);
    return $nonce;
}

function CRYPTOCURRENCY_PRODUCT_FOR_WOOCOMMERCE_set_last_txhash($thisWalletAddress, $txhash, $nonce) {
    $option = $thisWalletAddress . "-cryptocurrency-product-for-woocommerce-queue-txhash";
    $new_value = $txhash;
    $autoload = true;
    update_option($option, $new_value, $autoload);
    
    $option = $thisWalletAddress . "-cryptocurrency-product-for-woocommerce-queue-nonce";
    $new_value = $nonce;
    $autoload = true;
    update_option($option, $new_value, $autoload);
}

function CRYPTOCURRENCY_PRODUCT_FOR_WOOCOMMERCE_delete_last_txhash($thisWalletAddress) {
    $option = $thisWalletAddress . "-cryptocurrency-product-for-woocommerce-queue-txhash";
    delete_option($option);
    
    $option = $thisWalletAddress . "-cryptocurrency-product-for-woocommerce-queue-nonce";
    delete_option($option);
}

add_action("CRYPTOCURRENCY_PRODUCT_FOR_WOOCOMMERCE_complete_order", "CRYPTOCURRENCY_PRODUCT_FOR_WOOCOMMERCE_complete_order", 0, 3);

function CRYPTOCURRENCY_PRODUCT_FOR_WOOCOMMERCE_complete_order($order_id, $txhash, $nonce) {
    $providerUrl = CRYPTOCURRENCY_PRODUCT_FOR_WOOCOMMERCE_getWeb3Endpoint();
    $tx_confirmed = CRYPTOCURRENCY_PRODUCT_FOR_WOOCOMMERCE_is_tx_confirmed($txhash, $nonce, $providerUrl);
    if ($tx_confirmed) {
        // Load the order.
        $order = new WC_Order($order_id);

        // Place the order on hold.
        $res = $order->update_status('completed', __('Transaction confirmed.', 'cryptocurrency-product-for-woocommerce'));
        if (!$res) {
            // failed to complete order
            CRYPTOCURRENCY_PRODUCT_FOR_WOOCOMMERCE_log("Failed to complete order: " . $order_id);
            // Неуспех - поставить себя снова в очередь
            CRYPTOCURRENCY_PRODUCT_FOR_WOOCOMMERCE_enqueue_complete_order_task($order_id, $txhash, $nonce);
        }
    } else if (is_null($tx_confirmed)) {
        // nonce in last tx is outdated. remove it
        CRYPTOCURRENCY_PRODUCT_FOR_WOOCOMMERCE_log("Failed to complete order: " . $order_id . ". tx is outdated. Restart processing.");
        CRYPTOCURRENCY_PRODUCT_FOR_WOOCOMMERCE_process_order($order_id);
    } else {
        // re-enqueue itself to check later
        CRYPTOCURRENCY_PRODUCT_FOR_WOOCOMMERCE_enqueue_complete_order_task($order_id, $txhash, $nonce);
    }
}

function CRYPTOCURRENCY_PRODUCT_FOR_WOOCOMMERCE_enqueue_complete_order_task($order_id, $txhash, $nonce) {
//    global $CRYPTOCURRENCY_PRODUCT_FOR_WOOCOMMERCE_options;
    
    $timestamp = time();
    $hook = "CRYPTOCURRENCY_PRODUCT_FOR_WOOCOMMERCE_complete_order";
    $args = array($order_id, $txhash, $nonce);
    $task_id = wc_schedule_single_action( $timestamp, $hook, $args );
    CRYPTOCURRENCY_PRODUCT_FOR_WOOCOMMERCE_log("Task complete_order with id $task_id scheduled for order: $order_id");
}

function CRYPTOCURRENCY_PRODUCT_FOR_WOOCOMMERCE_cancel_complete_order_task($order_id, $txhash, $nonce) {
//    global $CRYPTOCURRENCY_PRODUCT_FOR_WOOCOMMERCE_options;
    
    $hook = "CRYPTOCURRENCY_PRODUCT_FOR_WOOCOMMERCE_complete_order";
    $args = array($order_id, $txhash, $nonce);
    wc_unschedule_action( $hook, $args );
    CRYPTOCURRENCY_PRODUCT_FOR_WOOCOMMERCE_log("Task complete_order with txhash $txhash unscheduled for order: $order_id");
}

function CRYPTOCURRENCY_PRODUCT_FOR_WOOCOMMERCE_enqueue_send_ether_task($order_id, $product_id, $marketAddress, $product_quantity, $providerUrl) {
    global $CRYPTOCURRENCY_PRODUCT_FOR_WOOCOMMERCE_options;
    
    $timestamp = time();
    $hook = "CRYPTOCURRENCY_PRODUCT_FOR_WOOCOMMERCE_send_ether";
    $args = array($order_id, $product_id, $marketAddress, $product_quantity, $providerUrl);
    $thisWalletAddress = esc_attr($CRYPTOCURRENCY_PRODUCT_FOR_WOOCOMMERCE_options['wallet_address']);
    $group = $thisWalletAddress . "-cryptocurrency-product-for-woocommerce-queue";
    $task_id = wc_schedule_single_action( $timestamp, $hook, $args, $group );
    CRYPTOCURRENCY_PRODUCT_FOR_WOOCOMMERCE_log("Task send_ether with id $task_id scheduled for group: $group");
}

function CRYPTOCURRENCY_PRODUCT_FOR_WOOCOMMERCE_get_nonce($accountAddress, $providerUrl, $eth = null) {
    if (!$eth) {
        $requestManager = new \Web3\RequestManagers\HttpRequestManager($providerUrl, 10/* seconds */);
        $web3 = new \Web3\Web3(new \Web3\Providers\HttpProvider($requestManager));
        $eth = $web3->eth;
    }
    $nonce = 0;
    $eth->getTransactionCount($accountAddress, function ($err, $transactionCount) use(&$nonce) {
        if ($err !== null) {
            CRYPTOCURRENCY_PRODUCT_FOR_WOOCOMMERCE_log("Failed to getTransactionCount: " . $err);
            $nonce = null;
            return;
        }
        $nonce = intval($transactionCount->toString());
    });
    return $nonce;
}

function CRYPTOCURRENCY_PRODUCT_FOR_WOOCOMMERCE_refund_ether_deposit($post_id) {
    global $CRYPTOCURRENCY_PRODUCT_FOR_WOOCOMMERCE_options;
    
    $providerUrl = CRYPTOCURRENCY_PRODUCT_FOR_WOOCOMMERCE_getWeb3Endpoint();
    $chainId = CRYPTOCURRENCY_PRODUCT_FOR_WOOCOMMERCE_getChainId();
    if (null === $chainId) {
        WC_Admin_Meta_Boxes::add_error( __( 'Configuration error. Last action was not completed.', 'cryptocurrency-product-for-woocommerce' ) );
        return false;
    }
    $blockchainNetwork = CRYPTOCURRENCY_PRODUCT_FOR_WOOCOMMERCE_getBlockchainNetwork();
    $thisWalletAddress = esc_attr($CRYPTOCURRENCY_PRODUCT_FOR_WOOCOMMERCE_options['wallet_address']);
    $requestManager = new \Web3\RequestManagers\HttpRequestManager($providerUrl, 10/* seconds */);
    $web3 = new \Web3\Web3(new \Web3\Providers\HttpProvider($requestManager));
    $eth = $web3->eth;
    $nonce = CRYPTOCURRENCY_PRODUCT_FOR_WOOCOMMERCE_get_nonce($thisWalletAddress, $providerUrl, $eth);
    if (null === $nonce) {
        WC_Admin_Meta_Boxes::add_error( __( 'Network problems detected. Last action was not completed.', 'cryptocurrency-product-for-woocommerce' ) );
        return false;
    }
    $data = CRYPTOCURRENCY_PRODUCT_FOR_WOOCOMMERCE_get_refund_data($providerUrl, $blockchainNetwork);
    $gasLimit = intval(CRYPTOCURRENCY_PRODUCT_FOR_WOOCOMMERCE_get_payToken_gas('', $post_id, $providerUrl, $blockchainNetwork, '', 0));
    $gasPrice = CRYPTOCURRENCY_PRODUCT_FOR_WOOCOMMERCE_get_gas_price_wei();

    $thisWalletPrivKey = esc_attr($CRYPTOCURRENCY_PRODUCT_FOR_WOOCOMMERCE_options['wallet_private_key']);
    
    $contractAddress = CRYPTOCURRENCY_PRODUCT_FOR_WOOCOMMERCE_getGatewayContractAddress($blockchainNetwork);
    $to = $contractAddress;
    $nonce = \BitWasp\Buffertools\Buffer::int($nonce);
    $gasPrice = \BitWasp\Buffertools\Buffer::int($gasPrice);
    $gasLimit = \BitWasp\Buffertools\Buffer::int($gasLimit);

    $transaction = new \Web3p\EthereumTx\Transaction([
        'nonce' => '0x' . $nonce->getHex(),
        'to' => strtolower($to),
        'gas' => '0x' . $gasLimit->getHex(),
        'gasPrice' => '0x' . $gasPrice->getHex(),
        'value' => '0x0',
        'chainId' => $chainId,
        'data' => '0x' . $data
    ]);
    $signedTransaction = "0x" . $transaction->sign($thisWalletPrivKey);

    $txHash = null;
    $eth->sendRawTransaction((string)$signedTransaction, function ($err, $transaction) use(&$txHash) {
        if ($err !== null) {
            CRYPTOCURRENCY_PRODUCT_FOR_WOOCOMMERCE_log("Failed to sendRawTransaction: " . $err);
            return;
        }
        $txHash = $transaction;
    });
    
    if (null === $txHash) {
        WC_Admin_Meta_Boxes::add_error( __( 'Network problems detected. Last action was not completed.', 'cryptocurrency-product-for-woocommerce' ) );
        return false;
    }
    update_post_meta( $post_id, 'txhash' . $chainId, sanitize_text_field( $txHash ) );
    update_post_meta( $post_id, 'txhashtime' . $chainId, time() );

    return true;
}

/**
 * Log information using the WC_Logger class.
 *
 * Will do nothing unless debug is enabled.
 *
 * @param string $msg   The message to be logged.
 */
function CRYPTOCURRENCY_PRODUCT_FOR_WOOCOMMERCE_log( $msg ) {
    static $logger = false;
    // Create a logger instance if we don't already have one.
    if ( false === $logger ) {
        $logger = new WC_Logger();
    }
    $logger->add( 'cryptocurrency-product-for-woocommerce', $msg );
}

/**
 * Check if order is not processed yet and process it in this case:
 * sends Ether or ERC20 tokens to the customer Ethereum address
 * 
 * @param int $order_id The order id
 */
function CRYPTOCURRENCY_PRODUCT_FOR_WOOCOMMERCE_process_order($order_id) {
    global $CRYPTOCURRENCY_PRODUCT_FOR_WOOCOMMERCE_options;
    $_billing_cryptocurrency_ethereum_address = get_post_meta( $order_id, '_billing_cryptocurrency_ethereum_address', true );
    
    $providerUrl = CRYPTOCURRENCY_PRODUCT_FOR_WOOCOMMERCE_getWeb3Endpoint();
    $blockchainNetwork = CRYPTOCURRENCY_PRODUCT_FOR_WOOCOMMERCE_getBlockchainNetwork();
    $marketAddress = $_billing_cryptocurrency_ethereum_address;

    $paymentInfo = CRYPTOCURRENCY_PRODUCT_FOR_WOOCOMMERCE_getPaymentInfo($order_id, $providerUrl, $blockchainNetwork, $marketAddress);
    if ($paymentInfo) {
        // already payed
        CRYPTOCURRENCY_PRODUCT_FOR_WOOCOMMERCE_log("Payment found for order $order_id. Skip payment.");
        return;
    }

    // do the payment
    $order = new WC_Order($order_id);
    $order_items = $order->get_items();
    foreach( $order_items as $product ) {
        $product_id = $product['product_id'];
        if (!_CRYPTOCURRENCY_PRODUCT_FOR_WOOCOMMERCE_is_cryptocurrency($product_id)) {
            // skip non-cryptocurrency products
            continue;
        }
        $product_quantity = $product['qty'];
        $_product = wc_get_product($product_id);
        if (!$_product) {
            CRYPTOCURRENCY_PRODUCT_FOR_WOOCOMMERCE_log("process_order($product_id) not a product");
            continue;
        }
        $minimumValue = apply_filters( 'woocommerce_quantity_input_min', 0, $_product );
        if (empty($minimumValue) || 0 == $minimumValue) {
            $minimumValue = CRYPTOCURRENCY_PRODUCT_FOR_WOOCOMMERCE_woocommerce_quantity_input_min( 0.01, $_product );
        }

        if (floatval($product_quantity) < floatval($minimumValue)) {
            // Place the order to failed.
            $res = $order->update_status('failed', 
                sprintf(
                    __('Product quantity %1$s less then the minimum allowed: %2$s.', 'cryptocurrency-product-for-woocommerce')
                    , $product_quantity
                    , $minimumValue
                )
            );
            if (!$res) {
                // failed to complete order
                CRYPTOCURRENCY_PRODUCT_FOR_WOOCOMMERCE_log("Failed to fail order: " . $order_id);
            }
            continue;
        }

        $cryptocurrency_option = get_post_meta( $product_id, '_select_cryptocurrency_option', true );
        if (__( 'Ether', 'cryptocurrency-product-for-woocommerce') == $cryptocurrency_option) {
            // send Ether
            CRYPTOCURRENCY_PRODUCT_FOR_WOOCOMMERCE_enqueue_send_ether_task($order_id, $product_id, $marketAddress, $product_quantity, $providerUrl);
        }
    }
}

function CRYPTOCURRENCY_PRODUCT_FOR_WOOCOMMERCE_getWeb3Endpoint() {
    global $CRYPTOCURRENCY_PRODUCT_FOR_WOOCOMMERCE_options;
    $infuraApiKey = esc_attr($CRYPTOCURRENCY_PRODUCT_FOR_WOOCOMMERCE_options['infuraApiKey']);
    $blockchainNetwork = esc_attr($CRYPTOCURRENCY_PRODUCT_FOR_WOOCOMMERCE_options['blockchain_network']);
    if (empty($blockchainNetwork)) {
        $blockchainNetwork = 'mainnet';
    }
    $web3Endpoint = "https://" . esc_attr($blockchainNetwork) . ".infura.io/" . esc_attr($infuraApiKey);
    return $web3Endpoint;
}

function CRYPTOCURRENCY_PRODUCT_FOR_WOOCOMMERCE_getChainId() {
    global $CRYPTOCURRENCY_PRODUCT_FOR_WOOCOMMERCE_options;
    $blockchainNetwork = esc_attr($CRYPTOCURRENCY_PRODUCT_FOR_WOOCOMMERCE_options['blockchain_network']);
    if (empty($blockchainNetwork)) {
        $blockchainNetwork = 'mainnet';
    }
    if ($blockchainNetwork === 'mainnet') {
        return 1;
    }
    if ($blockchainNetwork === 'ropsten') {
        return 3;
    }
    if ($blockchainNetwork === 'rinkeby') {
        return 4;
    }
    CRYPTOCURRENCY_PRODUCT_FOR_WOOCOMMERCE_log("Bad blockchain_network setting:" . $blockchainNetwork);
    return null;
}

function CRYPTOCURRENCY_PRODUCT_FOR_WOOCOMMERCE_getBlockchainNetwork() {
    global $CRYPTOCURRENCY_PRODUCT_FOR_WOOCOMMERCE_options;
    $blockchainNetwork = esc_attr($CRYPTOCURRENCY_PRODUCT_FOR_WOOCOMMERCE_options['blockchain_network']);
    if (empty($blockchainNetwork)) {
        $blockchainNetwork = 'mainnet';
    }
    return $blockchainNetwork;
}

function CRYPTOCURRENCY_PRODUCT_FOR_WOOCOMMERCE_getGatewayContractAddress($blockchainNetwork) {
    switch ($blockchainNetwork) {
        case 'mainnet' :
            return '0x3091d37ef18cb33Af72Cf7Ca63714733172cE724';
        case 'ropsten' :
            return '0x77256b49A9720D85e1672879c1fC3b655749765b';
        case 'rinkeby' :
            return '0x068f8339905e65da559cb6066e0d9f94c3e3b979';
    }
    return __('Unknown network name in configuration settings', 'cryptocurrency-product-for-woocommerce');
}


function CRYPTOCURRENCY_PRODUCT_FOR_WOOCOMMERCE_call_gateway_method($method, $order_id, $providerUrl, $blockchainNetwork, $marketAddress) {
    global $CRYPTOCURRENCY_PRODUCT_FOR_WOOCOMMERCE_gatewayContractABI;
    $abi = $CRYPTOCURRENCY_PRODUCT_FOR_WOOCOMMERCE_gatewayContractABI;
    $contract = new \Web3\Contract(new \Web3\Providers\HttpProvider(new \Web3\RequestManagers\HttpRequestManager($providerUrl, 10/* seconds */)), $abi);

    $contractAddress = CRYPTOCURRENCY_PRODUCT_FOR_WOOCOMMERCE_getGatewayContractAddress($blockchainNetwork);
    $ret = null;
    $callback = function($error, $result) use(&$ret) {
        if ($error !== null) {
            CRYPTOCURRENCY_PRODUCT_FOR_WOOCOMMERCE_log($error);
            WC_Admin_Meta_Boxes::add_error( __( 'Network problems detected. Last action was not completed.', 'cryptocurrency-product-for-woocommerce' ) );
            return;
        }
        foreach ($result as $key => $res) {
            $ret = $res;
            break;
        }
    };
    // call contract function
    $contract->at($contractAddress)->call($method, $marketAddress, $order_id, $callback);
    return $ret;
}

function CRYPTOCURRENCY_PRODUCT_FOR_WOOCOMMERCE_get_payEth_data($order_id, $providerUrl, $blockchainNetwork, $marketAddress, $eth_value_wei) {
    global $CRYPTOCURRENCY_PRODUCT_FOR_WOOCOMMERCE_gatewayContractABI;
    $abi = $CRYPTOCURRENCY_PRODUCT_FOR_WOOCOMMERCE_gatewayContractABI;
    $contract = new \Web3\Contract(new \Web3\Providers\HttpProvider(new \Web3\RequestManagers\HttpRequestManager($providerUrl, 10/* seconds */)), $abi);

    $contractAddress = CRYPTOCURRENCY_PRODUCT_FOR_WOOCOMMERCE_getGatewayContractAddress($blockchainNetwork);
    return $contract->at($contractAddress)->getData('payEth', $marketAddress, $order_id, $eth_value_wei);
}

function CRYPTOCURRENCY_PRODUCT_FOR_WOOCOMMERCE_get_payEth_gas($order_id, $providerUrl, $blockchainNetwork, $marketAddress, $eth_value_wei) {
    global $CRYPTOCURRENCY_PRODUCT_FOR_WOOCOMMERCE_options;
    return $CRYPTOCURRENCY_PRODUCT_FOR_WOOCOMMERCE_options['gas_limit'];
//    global $CRYPTOCURRENCY_PRODUCT_FOR_WOOCOMMERCE_gatewayContractABI;
//    $abi = $CRYPTOCURRENCY_PRODUCT_FOR_WOOCOMMERCE_gatewayContractABI;
//    $contract = new \Web3\Contract(new \Web3\Providers\HttpProvider(new \Web3\RequestManagers\HttpRequestManager($providerUrl, 10/* seconds */)), $abi);
//
//    $contractAddress = CRYPTOCURRENCY_PRODUCT_FOR_WOOCOMMERCE_getGatewayContractAddress($blockchainNetwork);
//    $ret = 200000;
//    $callback = function($error, $result) use(&$ret) {
//        if ($error !== null) {
//            return;
//        }
//        if (is_array($result)) {
//            foreach ($result as $key => $res) {
//                $ret = $res;
//                break;
//            }
//        } else {
//            $ret = $result;
//        }
//    };
//    $contract->at($contractAddress)->estimateGas('payEth', $marketAddress, $order_id, $eth_value_wei, $callback);
//    return $ret;
}

function CRYPTOCURRENCY_PRODUCT_FOR_WOOCOMMERCE_get_refund_data($providerUrl, $blockchainNetwork) {
    global $CRYPTOCURRENCY_PRODUCT_FOR_WOOCOMMERCE_gatewayContractABI;
    $abi = $CRYPTOCURRENCY_PRODUCT_FOR_WOOCOMMERCE_gatewayContractABI;
    $contract = new \Web3\Contract(new \Web3\Providers\HttpProvider(new \Web3\RequestManagers\HttpRequestManager($providerUrl, 10/* seconds */)), $abi);

    $contractAddress = CRYPTOCURRENCY_PRODUCT_FOR_WOOCOMMERCE_getGatewayContractAddress($blockchainNetwork);
    return $contract->at($contractAddress)->getData('refund');
}

function CRYPTOCURRENCY_PRODUCT_FOR_WOOCOMMERCE_get_payToken_gas($tokenAddress, $order_id, $providerUrl, $blockchainNetwork, $marketAddress, $eth_value_wei) {
    global $CRYPTOCURRENCY_PRODUCT_FOR_WOOCOMMERCE_options;
    return $CRYPTOCURRENCY_PRODUCT_FOR_WOOCOMMERCE_options['gas_limit'];
//    
//    global $CRYPTOCURRENCY_PRODUCT_FOR_WOOCOMMERCE_gatewayContractABI;
//    $abi = $CRYPTOCURRENCY_PRODUCT_FOR_WOOCOMMERCE_gatewayContractABI;
//    $contract = new \Web3\Contract(new \Web3\Providers\HttpProvider(new \Web3\RequestManagers\HttpRequestManager($providerUrl, 10/* seconds */)), $abi);
//
//    $contractAddress = CRYPTOCURRENCY_PRODUCT_FOR_WOOCOMMERCE_getGatewayContractAddress($blockchainNetwork);
//    $ret = 200000;
//    $callback = function($error, $result) use(&$ret) {
//        if ($error !== null) {
//            return;
//        }
//        if (is_array($result)) {
//            foreach ($result as $key => $res) {
//                $ret = $res;
//                break;
//            }
//        } else {
//            $ret = $result;
//        }
//    };
//    $contract->at($contractAddress)->estimateGas('payToken', $tokenAddress, $marketAddress, $order_id, $eth_value_wei, $callback);
//    return $ret;
}

function CRYPTOCURRENCY_PRODUCT_FOR_WOOCOMMERCE_getPaymentInfo($order_id, $providerUrl, $blockchainNetwork, $marketAddress) {
    $currencyPayment = CRYPTOCURRENCY_PRODUCT_FOR_WOOCOMMERCE_call_gateway_method("getCurrencyPayment", $order_id, $providerUrl, $blockchainNetwork, $marketAddress);
    if ($currencyPayment === "0x0000000000000000000000000000000000000000" ||
        $currencyPayment === "0x") {
        return null;
    }
    $valuePayment = doubleval(CRYPTOCURRENCY_PRODUCT_FOR_WOOCOMMERCE_call_gateway_method("getValuePayment", $order_id, $providerUrl, $blockchainNetwork, $marketAddress)->toString());
    return [$currencyPayment => $valuePayment];
}

function CRYPTOCURRENCY_PRODUCT_FOR_WOOCOMMERCE_getBalanceEth($providerUrl, $blockchainNetwork) {
    global $CRYPTOCURRENCY_PRODUCT_FOR_WOOCOMMERCE_gatewayContractABI;
    global $CRYPTOCURRENCY_PRODUCT_FOR_WOOCOMMERCE_options;

    $abi = $CRYPTOCURRENCY_PRODUCT_FOR_WOOCOMMERCE_gatewayContractABI;
    $contract = new \Web3\Contract(new \Web3\Providers\HttpProvider(new \Web3\RequestManagers\HttpRequestManager($providerUrl, 10/* seconds */)), $abi);

    $contractAddress = CRYPTOCURRENCY_PRODUCT_FOR_WOOCOMMERCE_getGatewayContractAddress($blockchainNetwork);
    $ret = null;
    $callback = function($error, $result) use(&$ret) {
        if ($error !== null) {
            CRYPTOCURRENCY_PRODUCT_FOR_WOOCOMMERCE_log($error);
            WC_Admin_Meta_Boxes::add_error( __( 'Network problems detected. Last action was not completed.', 'cryptocurrency-product-for-woocommerce' ) );
            return;
        }
        foreach ($result as $key => $res) {
            $ret = $res;
            break;
        }
    };
    $thisWalletAddress = esc_attr($CRYPTOCURRENCY_PRODUCT_FOR_WOOCOMMERCE_options['wallet_address']);
    $contract->at($contractAddress)->call("balances", $thisWalletAddress, $callback);
    return $ret;
}

// TODO: cache it
function CRYPTOCURRENCY_PRODUCT_FOR_WOOCOMMERCE_getFeePercent($providerUrl, $blockchainNetwork) {
    global $CRYPTOCURRENCY_PRODUCT_FOR_WOOCOMMERCE_gatewayContractABI;

    $abi = $CRYPTOCURRENCY_PRODUCT_FOR_WOOCOMMERCE_gatewayContractABI;
    $contract = new \Web3\Contract(new \Web3\Providers\HttpProvider(new \Web3\RequestManagers\HttpRequestManager($providerUrl, 10/* seconds */)), $abi);

    $contractAddress = CRYPTOCURRENCY_PRODUCT_FOR_WOOCOMMERCE_getGatewayContractAddress($blockchainNetwork);
    $ret = null;
    $callback = function($error, $result) use(&$ret) {
        if ($error !== null) {
            CRYPTOCURRENCY_PRODUCT_FOR_WOOCOMMERCE_log($error);
            return;
        }
        foreach ($result as $key => $res) {
            $ret = $res;
            break;
        }
    };
    $contract->at($contractAddress)->call("feePercent", $callback);
    return $ret;
}


//----------------------------------------------------------------------------//
//              Cron job to check for failed payments and redo them           //
//----------------------------------------------------------------------------//


//// @see https://codex.wordpress.org/Function_Reference/wp_schedule_event
//register_activation_hook(__FILE__, 'CRYPTOCURRENCY_PRODUCT_FOR_WOOCOMMERCE_activation');
//
//function CRYPTOCURRENCY_PRODUCT_FOR_WOOCOMMERCE_activation() {
//    if (! wp_next_scheduled ( 'CRYPTOCURRENCY_PRODUCT_FOR_WOOCOMMERCE_hourly_event' )) {
//        wp_schedule_event(time(), 'hourly', 'CRYPTOCURRENCY_PRODUCT_FOR_WOOCOMMERCE_hourly_event');
//    }
//}
//
//add_action('CRYPTOCURRENCY_PRODUCT_FOR_WOOCOMMERCE_hourly_event', 'CRYPTOCURRENCY_PRODUCT_FOR_WOOCOMMERCE_do_this_hourly');
//function CRYPTOCURRENCY_PRODUCT_FOR_WOOCOMMERCE_do_this_hourly() {
//	// do something every hour
//}
//
//register_deactivation_hook(__FILE__, 'CRYPTOCURRENCY_PRODUCT_FOR_WOOCOMMERCE_deactivation');
//
//function CRYPTOCURRENCY_PRODUCT_FOR_WOOCOMMERCE_deactivation() {
//	wp_clear_scheduled_hook('CRYPTOCURRENCY_PRODUCT_FOR_WOOCOMMERCE_hourly_event');
//}


//----------------------------------------------------------------------------//
//                            Enqueue Scripts                                 //
//----------------------------------------------------------------------------//


function CRYPTOCURRENCY_PRODUCT_FOR_WOOCOMMERCE_get_user_wallet() {
    global $CRYPTOCURRENCY_PRODUCT_FOR_WOOCOMMERCE_options;

    $value = '';
    $userWalletMetaKey = esc_attr($CRYPTOCURRENCY_PRODUCT_FOR_WOOCOMMERCE_options['wallet_meta']);
    if (!empty($userWalletMetaKey)) {
        // https://stackoverflow.com/a/19722500/4256005
        $user_id = get_current_user_id(); 
        $key = $userWalletMetaKey; 
        $single = true; 
        $value = get_user_meta( $user_id, $key, $single ); 
    }
    return $value;
}

function CRYPTOCURRENCY_PRODUCT_FOR_WOOCOMMERCE_enqueue_script() {
    global $CRYPTOCURRENCY_PRODUCT_FOR_WOOCOMMERCE_gatewayContractABI;
	global $CRYPTOCURRENCY_PRODUCT_FOR_WOOCOMMERCE_plugin_url_path;
    global $CRYPTOCURRENCY_PRODUCT_FOR_WOOCOMMERCE_options;
	$options = $CRYPTOCURRENCY_PRODUCT_FOR_WOOCOMMERCE_options;

    $min = defined( 'SCRIPT_DEBUG' ) && SCRIPT_DEBUG ? '' : '.min';
	if ( wp_script_is( 'jquery', 'registered' ) ) {
		wp_enqueue_script( 'cryptocurrency-product-for-woocommerce', $CRYPTOCURRENCY_PRODUCT_FOR_WOOCOMMERCE_plugin_url_path . "/cryptocurrency-product-for-woocommerce{$min}.js", array( 'jquery' ), '2.1.2' );
	}
    wp_enqueue_script( 'web3', $CRYPTOCURRENCY_PRODUCT_FOR_WOOCOMMERCE_plugin_url_path . '/web3.min.js', array( 'jquery' ), '0.19.0' );

	$wallet_address = ! empty( $options['wallet_address'] ) ? esc_attr( $options['wallet_address'] ) : 
        '';
    
    $blockchainNetwork = CRYPTOCURRENCY_PRODUCT_FOR_WOOCOMMERCE_getBlockchainNetwork();
    $contractAddress = CRYPTOCURRENCY_PRODUCT_FOR_WOOCOMMERCE_getGatewayContractAddress($blockchainNetwork);

    wp_localize_script(
        'cryptocurrency-product-for-woocommerce', 'cryptocurrency', [
            // variables
            'web3Endpoint' => esc_html(CRYPTOCURRENCY_PRODUCT_FOR_WOOCOMMERCE_getWeb3Endpoint()),
            'walletAddress' => esc_html($wallet_address),
            'gatewayContractAddress' => esc_html($contractAddress),
            'gatewayContractABI' => esc_html($CRYPTOCURRENCY_PRODUCT_FOR_WOOCOMMERCE_gatewayContractABI),
        ]
    );
}

add_action( 'admin_enqueue_scripts', 'CRYPTOCURRENCY_PRODUCT_FOR_WOOCOMMERCE_enqueue_script' );


//----------------------------------------------------------------------------//
//                               Admin Options                                //
//----------------------------------------------------------------------------//


if ( is_admin() ) {
	include_once $CRYPTOCURRENCY_PRODUCT_FOR_WOOCOMMERCE_plugin_dir . '/cryptocurrency-product-for-woocommerce.admin.php';
}

function CRYPTOCURRENCY_PRODUCT_FOR_WOOCOMMERCE_add_menu_link() {
	$page = add_options_page(
		__( 'Cryptocurrency Product Settings', 'cryptocurrency-product-for-woocommerce' ),
		__( 'Cryptocurrency Product', 'cryptocurrency-product-for-woocommerce' ),
		'manage_options',
		'cryptocurrency-product-for-woocommerce',
		'CRYPTOCURRENCY_PRODUCT_FOR_WOOCOMMERCE_options_page'
	);
}

add_filter( 'admin_menu', 'CRYPTOCURRENCY_PRODUCT_FOR_WOOCOMMERCE_add_menu_link' );

// Place in Option List on Settings > Plugins page 
function CRYPTOCURRENCY_PRODUCT_FOR_WOOCOMMERCE_actlinks( $links, $file ) {
	// Static so we don't call plugin_basename on every plugin row.
	static $this_plugin;
	
	if ( ! $this_plugin ) {
		$this_plugin = plugin_basename( __FILE__ );
	}
	
	if ( $file == $this_plugin ) {
		$settings_link = '<a href="options-general.php?page=cryptocurrency-product-for-woocommerce">' . __( 'Settings' ) . '</a>';
		array_unshift( $links, $settings_link ); // before other links
	}
	
	return $links;
}

add_filter( 'plugin_action_links', 'CRYPTOCURRENCY_PRODUCT_FOR_WOOCOMMERCE_actlinks', 10, 2 );


//----------------------------------------------------------------------------//
//                Use decimal in quantity fields in WooCommerce               //
//----------------------------------------------------------------------------//
// @see: http://codeontrack.com/use-decimal-in-quantity-fields-in-woocommerce-wordpress/


add_action( 'plugins_loaded', 'CRYPTOCURRENCY_PRODUCT_FOR_WOOCOMMERCE_plugins_loaded' );
function CRYPTOCURRENCY_PRODUCT_FOR_WOOCOMMERCE_plugins_loaded() {
    // Removes the WooCommerce filter, that is validating the quantity to be an int
    remove_filter('woocommerce_stock_amount', 'intval');

    // Add a filter, that validates the quantity to be a float
    add_filter('woocommerce_stock_amount', 'floatval');
}
 
// Add unit price fix when showing the unit price on processed orders
add_filter('woocommerce_order_amount_item_total', 'CRYPTOCURRENCY_PRODUCT_FOR_WOOCOMMERCE_unit_price_fix', 10, 5);
function CRYPTOCURRENCY_PRODUCT_FOR_WOOCOMMERCE_unit_price_fix($price, $order, $item, $inc_tax = false, $round = true) {
    $qty = (!empty($item['qty']) && $item['qty'] != 0) ? $item['qty'] : 1;
    if($inc_tax) {
        $price = ($item['line_total'] + $item['line_tax']) / $qty;
    } else {
        $price = $item['line_total'] / $qty;
    }
    $price = $round ? round( $price, 2 ) : $price;
    return $price;
}

// define the woocommerce_quantity_input_min callback 
function CRYPTOCURRENCY_PRODUCT_FOR_WOOCOMMERCE_woocommerce_quantity_input_min( $min, $product ) { 
    $product_id = $product->get_id();
    if ( !_CRYPTOCURRENCY_PRODUCT_FOR_WOOCOMMERCE_is_cryptocurrency( $product_id ) ) {
        return $min;
    }
    
    $minimumValue = get_post_meta( $product_id, '_text_input_cryptocurrency_minimum_value', true );
    if (!empty($minimumValue)) {
        return floatval($minimumValue);
    } else {
        $cryptocurrency_option = get_post_meta( $product_id, '_select_cryptocurrency_option', true );
        if (__( 'Ether', 'cryptocurrency-product-for-woocommerce') == $cryptocurrency_option) {
            return 0.001;
        }
    }
}; 
add_filter( 'woocommerce_quantity_input_min', 'CRYPTOCURRENCY_PRODUCT_FOR_WOOCOMMERCE_woocommerce_quantity_input_min', 10, 2 ); 

// define the woocommerce_quantity_input_step callback 
function CRYPTOCURRENCY_PRODUCT_FOR_WOOCOMMERCE_woocommerce_quantity_input_step( $step, $product ) { 
    $product_id = $product->get_id();
    if ( !_CRYPTOCURRENCY_PRODUCT_FOR_WOOCOMMERCE_is_cryptocurrency( $product_id ) ) {
        return $step;
    }
    $step = get_post_meta( $product_id, '_text_input_cryptocurrency_step', true );
    if (!empty($step)) {
        return floatval($step);
    } else {
        $cryptocurrency_option = get_post_meta( $product_id, '_select_cryptocurrency_option', true );
        if (__( 'Ether', 'cryptocurrency-product-for-woocommerce') == $cryptocurrency_option) {
            return 0.00001;
        }
    }
}; 
add_filter( 'woocommerce_quantity_input_step', 'CRYPTOCURRENCY_PRODUCT_FOR_WOOCOMMERCE_woocommerce_quantity_input_step', 10, 2 ); 


//----------------------------------------------------------------------------//
//                                   L10n                                     //
//----------------------------------------------------------------------------//


function CRYPTOCURRENCY_PRODUCT_FOR_WOOCOMMERCE_load_textdomain() {
    /**
     * Localise.
     */
    load_plugin_textdomain( 'cryptocurrency-product-for-woocommerce', FALSE, basename( dirname( __FILE__ ) ) . '/languages/' );
}
add_action('plugins_loaded', 'CRYPTOCURRENCY_PRODUCT_FOR_WOOCOMMERCE_load_textdomain');


//----------------------------------------------------------------------------//
//                      Ethereum address verification                         //
//----------------------------------------------------------------------------//


function CRYPTOCURRENCY_PRODUCT_FOR_WOOCOMMERCE_after_checkout_validation($data,$errors) { 
    if (!_CRYPTOCURRENCY_PRODUCT_FOR_WOOCOMMERCE_is_cryptocurrency_product_in_cart()) {
        return;
    }

    $value = (string) $data['billing_cryptocurrency_ethereum_address'];
    if (\Web3\Utils::isAddress($value)) {
        return;
    }
    // Do your data processing here and in case of an 
    // error add it to the errors array like:
    $errors->add( 'validation', __( 'Please input correct Ethereum address in the form like 0x476Bb28Bc6D0e9De04dB5E19912C392F9a76535d.', 'cryptocurrency-product-for-woocommerce' ));
}
add_action('woocommerce_after_checkout_validation', 'CRYPTOCURRENCY_PRODUCT_FOR_WOOCOMMERCE_after_checkout_validation',10,2);
        
    } // WooCommerce activated
} // PHP version
